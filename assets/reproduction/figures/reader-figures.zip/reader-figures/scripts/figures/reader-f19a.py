"""Compact exact-law F19a layout; saved state/coefficient/report values only."""
from pathlib import Path
import importlib.util,json
from matplotlib.patches import Rectangle
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('reader_matrices',Path(__file__).with_name('reader-matrices.py'))
rm=importlib.util.module_from_spec(spec);spec.loader.exec_module(rm)
rc=rm.rc;C=rc.C;txt=rm.txt
DATA='assets/reproduction/figures/data/scalar-and-common-grade.json'
def draw(mobile):
 d=json.loads((ROOT/DATA).read_text())['common_grade'];reports=[next(r for r in d['selected_reports']if r['g']==g)for g in [[1,2,2,3],[1,1,2,3]]]
 assert d['units']==list('ABCD')and d['M']==6 and d['tau']=='1/5'
 assert d['accepted_optima']['directional']['actions']==[reports[0]['g']] and d['accepted_optima']['composite']['actions']==[reports[1]['g']]
 assert d['criterion_error_weights_w']==['3/5','2/5']and d['composite_magnitude_coefficients_a']==['3/4','1/4']
 w,h=(360,1120)if mobile else(690,600);fig,ax=rm.surface(w,h);checks={'states':[],'coefficients':[],'reports':[],'risks':[]};objects=[]
 txt(ax,18,30,'From target states\nto two common reports'if mobile else'From target states to two common reports',16.5,fontweight='bold')
 txt(ax,18,78 if mobile else 52,'One joint law; w=(3/5,2/5),\na=(3/4,1/4), τ=1/5; M=6.'if mobile else'One joint law; w=(3/5,2/5), a=(3/4,1/4), τ=1/5; M=6.',12.5)
 for i in range(2):
  x,y=(18,122+i*149)if mobile else(20+i*360,78);xs=[x+24,x+99,x+174,x+249]
  txt(ax,x,y,'A'+str(i+1)+'. State '+str(i+1)+': probability '+d['states'][i]['probability'],13,fontweight='bold')
  for xx,label in zip(xs,['Unit',r'$\theta_1$',r'$\theta_2$','Composite c']):txt(ax,xx,y+24,label,12.5,ha='center',fontweight='bold')
  rows=[]
  for j,(unit,theta,c)in enumerate(zip(d['units'],d['states'][i]['theta_unit_by_criterion'],d['composite_by_state'][i])):
   yy=y+44+j*(22 if mobile else 18)
   for xx,v in zip(xs,[unit,*theta,c]):txt(ax,xx,yy,str(v),13,ha='center',fontweight='bold'if v==unit else'normal')
   rows.append({'unit':unit,'theta':theta,'composite':c})
  checks['states'].append({'probability':d['states'][i]['probability'],'rows':rows})
 txt(ax,18,425 if mobile else 202,r'$c_i=(3/4)\theta_{i1}+(1/4)\theta_{i2}$',13)
 txt(ax,18,452 if mobile else 224,'w weights errors; a combines target magnitudes.',12.5)
 ty=489 if mobile else 249;txt(ax,18,ty,'B. Forward error coefficients',13,fontweight='bold')
 xs=[117+42*j for j in range(6)]if mobile else[200+80*j for j in range(6)]
 for j,row in enumerate(d['forward_pair_rows']):
  txt(ax,xs[j],ty+24,row['pair'],12.5,ha='center',fontweight='bold')
  for dy,key in [(49,'directional_error'),(75,'composite_error')]:
   width=37 if mobile else 66;edge=C['ochre']if row['pair']=='AB'else C['teal']if row['pair']=='BC'else C['line']
   p=Rectangle((xs[j]-width/2,ty+dy-11),width,22,facecolor='white',edgecolor=edge,lw=1.5 if row['pair']in['AB','BC']else .7);ax.add_patch(p)
   t=txt(ax,xs[j],ty+dy,row[key],12.5,ha='center');objects.append((p,t))
  checks['coefficients'].append({'pair':row['pair'],'weighted_direction':row['directional_error'],'composite':row['composite_error']})
 txt(ax,18,ty+49,'Weighted\ndirection'if mobile else'Weighted direction',12.5);txt(ax,18,ty+75,'Composite',12.5)
 for i,row in enumerate(reports):
  x,y,cw=(18,614+i*140,324)if mobile else(20+i*350,351,300);code=''.join(map(str,row['g']));col=C['teal']if i==0 else C['ochre']
  txt(ax,x,y,'C. '+('Weighted-direction'if i==0 else'Composite')+' optimum '+code,12.5,fontweight='bold')
  left=x
  for block in row['blocks']:
   bw=cw*len(block)/4;p=Rectangle((left,y+20),bw,23,facecolor=C['light'],edgecolor=col,lw=1.3);ax.add_patch(p);t=txt(ax,left+bw/2,y+31.5,'  '.join(block),13,ha='center',fontweight='bold');objects.append((p,t));left+=bw
  txt(ax,x+cw/2,y+57,'g = ('+','.join(map(str,row['g']))+'); N = 5',12.5,ha='center')
  for j,mask in enumerate(row['pair_masks']):
   px=x+cw*(j+.5)/6;txt(ax,px,y+78,mask['pair'],12,ha='center');ax.scatter([px],[y+95],s=34,facecolor=col if mask['disclosed']else'white',edgecolor=C['ink'],lw=1.1)
  checks['reports'].append({'grades':row['g'],'blocks':row['blocks'],'N':row['N'],'masks':row['pair_masks'],'optimal_for':'weighted direction'if i==0 else'composite'})
 ry=910 if mobile else 465;txt(ax,18,ry,'D. Same N = 5; evaluate each loss',13,fontweight='bold')
 rxs=[48,163,282]if mobile else[100,342,560]
 for x,label in zip(rxs,['Report','Weighted risk','Composite risk']):txt(ax,x,ry+26,label,12.5,ha='center',fontweight='bold')
 for i,row in enumerate(reports):
  yy=ry+51+i*25;code=''.join(map(str,row['g']));txt(ax,rxs[0],yy,code,13,ha='center')
  for j,key in enumerate(['directional','composite']):
   preferred=i==j;bw=101 if mobile else 188;p=Rectangle((rxs[j+1]-bw/2,yy-10.5),bw,21,facecolor=C['light']if preferred else'white',edgecolor=(C['teal']if j==0 else C['ochre'])if preferred else C['line'],lw=1.6 if preferred else .7);ax.add_patch(p)
   t=txt(ax,rxs[j+1],yy,row[key]['R'],13,ha='center',fontweight='bold'if preferred else'normal');objects.append((p,t))
  checks['risks'].append({'g':row['g'],'weighted':row['directional']['R'],'composite':row['composite']['R']})
 if mobile:
  txt(ax,18,877,'Filled: forward direction. Open: withhold.',12.5)
  txt(ax,18,1052,'Both reports disclose five of six pairs.\nRisk uses M=6; error fractions use N.\nCompare minima within each target; loss\nmagnitudes cannot choose the target.',12.5,color=C['muted'])
 else:
  txt(ax,18,577,'Filled: forward direction. Open: withhold. Both disclose five of six pairs.\nRisk uses M=6; compare minima within each target, not between target definitions.',12.5,color=C['muted'])
 rm.verify_cells(fig,objects)
 fig.canvas.draw();ren=fig.canvas.get_renderer();labels=[t for t in ax.texts if t.get_text()]
 for i,t in enumerate(labels):
  for u in labels[i+1:]:
   assert not t.get_window_extent(ren).overlaps(u.get_window_extent(ren)),('text overlap',t.get_text(),u.get_text())
 checks['text_pairwise_nonoverlap']=True
 assert len(checks['states'])==2 and len(checks['coefficients'])==6 and len(checks['reports'])==2 and len(checks['risks'])==2
 checks['all_cell_labels_inside']=True;checks['scientific_recomputation']=False
 return fig,checks
if __name__=='__main__':
 stem='f19a-from-target-states-to-matrices-to-common-grades';inputs=[DATA,'assets/reproduction/figures/generators/F19a/generate.py','scripts/figures/reader-compact.py','scripts/figures/reader-matrices.py']+[f'assets/figures/{stem}{s}.{ext}'for s in['','-mobile']for ext in['svg','pdf']]
 before=[rc.pin(x)for x in inputs];r={'step':'11.148','id':'F19a','status':'GENERATED_PENDING_DIRECT_VISUAL_REVIEW','sourcepins':before,'producer':rc.pin('scripts/figures/reader-f19a.py'),'browser_observed':False}
 for mobile,size in[(False,'normal'),(True,'narrow')]:
  fig,checks=draw(mobile);r[size]=rc.export(fig,'reader-f19a-'+size,'Two complete joint target states, all forward coefficients, matched-disclosure report masks and four exact risks; error weights and composite coefficients remain distinct.');r[size]['checks']=checks
 assert r['normal']['checks']==r['narrow']['checks'];assert before==[rc.pin(x)for x in inputs]
 r['source_assets_unchanged']=True;(ROOT/'evidence/editorial/figure-sizing/compact-f19a.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({s:[r[s]['width'],r[s]['height']]for s in['normal','narrow']}))
