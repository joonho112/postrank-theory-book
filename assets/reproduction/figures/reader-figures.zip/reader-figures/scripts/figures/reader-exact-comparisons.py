"""Compact figures from stored exact-case rows; no search or enumeration."""
from pathlib import Path
import csv, datetime, hashlib, json
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import style_v4 as style

ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/'assets/cases/exact/source-support'
C=style.COLORS


def canvas(w,h):
    fig=style.canvas(h/72);fig.set_size_inches(w/72,h/72)
    ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,w),ylim=(h,0));ax.axis('off')
    return fig,ax


def text(ax,x,y,s,size=13,bold=False,color='ink',ha='left'):
    return ax.text(x,y,s,fontsize=size,fontweight='bold' if bold else 'normal',
                   color=C[color],ha=ha,va='top',linespacing=1.2)


def panel(ax,x,y,w,h,fill='light'):
    ax.add_patch(Rectangle((x,y),w,h,facecolor=C[fill],edgecolor=C['line'],linewidth=.7))


def geometry(fig):
    fig.canvas.draw();ren=fig.canvas.get_renderer();ts=[t for ax in fig.axes for t in ax.texts if t.get_text()]
    bs=[t.get_window_extent(ren) for t in ts]
    bad=[t.get_text() for t,b in zip(ts,bs) if b.x0<0 or b.x1>fig.bbox.width or b.y0<0 or b.y1>fig.bbox.height]
    overlaps=[[ts[i].get_text(),ts[j].get_text()] for i,b in enumerate(bs) for j in range(i+1,len(bs)) if b.overlaps(bs[j])]
    if bad or overlaps:raise ValueError({'outside':bad,'overlap':overlaps})
    return {'text_records':len(ts),'canvas_containment':True,'text_pair_nonoverlap':True}


def load_rows():
    rows=list(csv.DictReader((DATA/'t-scope-dimension.csv').open()))
    selected={r['case_id']:r for r in rows if r['experiment']=='three_domains' and r['objective']=='A'}
    expected={('coincident','direct_joint'):('1/15','3'),('disjoint','direct_joint'):('17/90','1'),
              ('coincident','equal_bonferroni'):('1/4','0'),('disjoint','equal_bonferroni'):('1/4','0'),
              ('coincident','bonferroni'):('17/90','1'),('disjoint','bonferroni'):('17/90','1')}
    for (law,method),values in expected.items():
        r=selected[f'{law}-A-{method}'];assert (r['risk_exact'],r['disclosure_exact'])==values
        assert (r['n'],r['D'],r['original_M'],r['family_size'],r['t_exact'],r['alpha_exact'])==('2','3','1','27','0','1/10')
    free={r['action_id']:r for r in csv.DictReader((DATA/'comparator-free-candidates.csv').open())}
    assert (free['free-021']['risk_exact'],free['free-021']['N'],free['free-021']['J_exact'],free['free-021']['any_error_probability_exact'])==('1/3','3','0','1')
    assert free['free-021']['F_statewise']=='1|1|1' and free['free-021']['grade_representable']=='FALSE'
    assert (free['free-014']['risk_exact'],free['free-014']['N'],free['free-014']['J_exact'],free['free-014']['any_error_probability_exact'])==('1/2','0','0','0')
    return selected,{'cycle':free['free-021'],'all_withheld':free['free-014']}


METHODS=[('direct_joint','Direct joint'),('equal_bonferroni','Equal Bonferroni'),('bonferroni','Optimized Bonferroni')]


def three_domains(rows,mobile=False):
    fig,ax=canvas(360 if mobile else 640,690 if mobile else 420)
    text(ax,16,12,'Three-domain coupling and minimum risk' if not mobile else 'Three-domain coupling\nand minimum risk',18 if not mobile else 17,True)
    if not mobile:
        text(ax,16,44,'n = 2; D = 3; original M = 1; complete family: 27 profiles.',13)
        text(ax,16,66,'Each forward direction has marginal error probability 1/15.',13)
        text(ax,16,88,'w_d = 1/3; τ_d = 1/4; t_d = 0; α = 1/10; no mean constraints.',13)
        text(ax,24,125,'Method',13,True)
        for x,law in [(315,'Coincident errors'),(522,'Disjoint errors')]:text(ax,x,125,law,14,True,ha='center')
        for x in [315,522]:
            text(ax,x-27,148,'Risk',12,ha='center');text(ax,x+43,148,'I',12,ha='center')
        for i,(method,label) in enumerate(METHODS):
            y=177+54*i;panel(ax,16,y,608,50,'light' if i%2==0 else 'white');text(ax,26,y+16,label,13.5,True)
            for x,law in [(315,'coincident'),(522,'disjoint')]:
                r=rows[f'{law}-A-{method}']
                text(ax,x-27,y+14,r['risk_exact'],16,True,'teal' if method=='direct_joint' else 'ink',ha='center')
                text(ax,x+43,y+14,r['disclosure_exact'],16,True,'teal' if method=='direct_joint' else 'ink',ha='center')
        text(ax,16,348,'Risk: minimum expected error–withholding loss.\nI: issued pair-domain directions at a risk minimizer.',13)
        text(ax,16,390,'The joint event is the union across all three domains.',12,False,'muted')
    else:
        text(ax,16,60,'n = 2; D = 3; original M = 1.\nComplete family: 27 profiles.\nEach forward direction has error\nprobability 1/15.',13)
        text(ax,16,130,'w_d = 1/3; τ_d = 1/4; t_d = 0;\nα = 1/10; no mean constraints.',13)
        for law,y in [('coincident',179),('disjoint',369)]:
            panel(ax,16,y,328,176,'white');text(ax,26,y+9,law.capitalize()+' errors',15,True)
            text(ax,262,y+13,'Risk',12,True,ha='center');text(ax,326,y+13,'I',12,True,ha='center')
            for i,(method,label) in enumerate(METHODS):
                yy=y+44+i*41;r=rows[f'{law}-A-{method}']
                text(ax,26,yy,label.replace('Optimized Bonferroni','Optimized\nBonferroni'),12.8,True)
                text(ax,262,yy,r['risk_exact'],14.5,True,'teal' if method=='direct_joint' else 'ink',ha='center')
                text(ax,326,yy,r['disclosure_exact'],14.5,True,ha='center')
        text(ax,16,570,'Risk: minimum expected error–withholding loss.\nI: issued pair-domain directions at a risk\nminimizer.',12.4)
        text(ax,16,634,'The joint event is the union\nacross all three domains.',12.4,False,'muted')
    return fig


def free_cycle(rows,mobile=False):
    fig,ax=canvas(360 if mobile else 640,700 if mobile else 440)
    text(ax,16,12,'A feasible cycle is not an ordered grade' if not mobile else 'A feasible cycle is not\nan ordered grade',18 if not mobile else 17,True)
    if not mobile:
        text(ax,16,43,'n = 3; D = 1; original M = 3; τ = 1/2; q = 1; t = 1/3; α = 0.',13)
        text(ax,16,65,'States (3,2,1), (1,3,2), (2,1,3), each with probability 1/3.',13)
        for x,heading,sub in [(316,'Free pairs','27 pairwise reports'),(522,'Ordered grades','13 ordered partitions')]:
            text(ax,x,103,heading,15,True,ha='center');text(ax,x,127,sub,12.5,ha='center')
        fields=[('Selected action','1 > 2 > 3 > 1','All withheld'),('Minimum risk','risk_exact','risk_exact'),('Issued pairs N','N','N'),('Strict exceedance J','J_exact','J_exact'),('P(any issued error)','any_error_probability_exact','any_error_probability_exact')]
        for i,(label,k1,k2) in enumerate(fields):
            y=157+i*39;panel(ax,16,y,608,37,'light' if i%2==0 else 'white');text(ax,26,y+11,label,13,True)
            for x,key,row in [(316,k1,rows['cycle']),(522,k2,rows['all_withheld'])]:text(ax,x,y+10,row.get(key,key),14,True if i==1 else False,ha='center')
        text(ax,16,369,'Cycle: exactly one error among three directions in every state.',13)
        text(ax,16,392,'Thus F/N = 1/3, so J = P(F/N > 1/3) = 0, although any-error probability is 1.',12.3)
        text(ax,16,415,'The cycle has no grade matrix; with no issued directions, J = 0.',12.2,False,'muted')
    else:
        text(ax,16,60,'n = 3; D = 1; original M = 3.\nτ = 1/2; q = 1; t = 1/3; α = 0.',13)
        text(ax,16,108,'States: (3,2,1), (1,3,2), (2,1,3),\neach with probability 1/3.',13)
        for typ,title,family,action,y in [('cycle','Free pairs','27 pairwise reports','Cycle: 1 > 2 > 3 > 1',164),('all_withheld','Ordered grades','13 ordered partitions','All withheld',359)]:
            row=rows[typ];panel(ax,16,y,328,179,'light' if typ=='cycle' else 'white')
            text(ax,26,y+10,title,15,True);text(ax,26,y+34,family,12.5);text(ax,26,y+57,action,13,True)
            for j,(label,key) in enumerate([('Minimum risk','risk_exact'),('Issued pairs N','N'),('Strict exceedance J','J_exact'),('P(any issued error)','any_error_probability_exact')]):
                text(ax,26,y+84+j*21,label,12.7);text(ax,322,y+84+j*21,row[key],13.2,True,ha='right')
        text(ax,16,559,'Cycle: one error among three directions\nin every state, so F/N = 1/3.\nStrict exceedance J = P(F/N > 1/3) = 0;\nP(any issued error) = 1.',13)
        text(ax,16,647,'The cycle has no grade matrix.\nWith no issued directions, J = 0.',12.5,False,'muted')
    return fig


def main():
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();three,free=load_rows();outputs=[];checks=[]
    inputs=[DATA/'t-scope-dimension.csv',DATA/'comparator-free-candidates.csv',ROOT/'assets/cases/exact/figures/04-three-domain-coupling.svg',ROOT/'assets/cases/exact/figures/05-free-cycle-vs-grade.svg',ROOT/'scripts/figures/style_v4.py']
    pins=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in inputs]
    for stem,fn,rows in [('reader-exact-three-domain',three_domains,three),('reader-exact-free-cycle',free_cycle,free)]:
        for mobile in [False,True]:
            fig=fn(rows,mobile);checks.append({'id':stem,'mobile':mobile,**geometry(fig)})
            outputs+=style.export(fig,stem,mobile=mobile,title=stem,alt='Exact saved comparison values in a compact table; no new enumeration or optimization.')
    assert all(sha(ROOT/x['path'])==x['sha256'] for x in pins)
    source=ROOT/'source-context/chapter-25-exact-examples.txt';lines=source.read_bytes().splitlines(keepends=True)
    # Record the two source paragraphs supplied with the archived figure inputs.
    contexts=[]
    for phrase in [b'With two units and three domains',b'A further example distinguishes grades']:
        i=next(i for i,l in enumerate(lines) if phrase in l);contexts.append({'path':str(source.relative_to(ROOT)),'full_sha256':sha(source),'line_range':[i+1,i+1],'bytes':len(lines[i]),'range_sha256':hashlib.sha256(lines[i]).hexdigest(),'text':lines[i].decode().strip()})
    rec={'step':'11.154','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer':{'path':str(Path(__file__).relative_to(ROOT)),'sha256':sha(Path(__file__))},'inputs':pins,'source_context':contexts,'selected_stored_rows':{'three_domains_A':list(three.values()),'free_cycle_and_all_withheld':free},'data_operations':'CSV parsing, explicit row-ID selection and exact string checks only. No new enumeration, optimization, probability calculation or fitting.','figure_mapping':{'three_domain':'All six exact risk/disclosure values, both coupling labels, method identities, n/D/original M, equal marginal error probabilities, weights, costs, thresholds, alpha and absence of mean constraints retained. Full 27-profile family from the source context is made explicit. Plot-axis ticks are replaced by exact numeric cells.','free_cycle':'Both saved actions retain risk, N, J and any-error probability. All original settings and strict greater-than event remain explicit. Existing source-context law and 27/13 candidate families are displayed; no new family computation.'},'source_reads':{'t_scope':'Header and six full rows selected by experiment=three_domains and objective=A; other rows mechanically parsed only.','free_candidates':'Header and all27 small CSV rows actually read; display uses only free-021 and free-014, without recomputing an optimum.','source_figures':'All native SVG text labels extracted and actual700px offline renders opened.','chapter_context':'Only the two exact-example paragraphs and their figure markup, not a fresh full-chapter reading.'},'geometry_checks':checks,'outputs':outputs,'visual_review':'Pending actual new PDF raster inspection','original_inputs_unchanged':True,'browser_observation':False,'independent_review':'Pending root Step11.155'}
    p=ROOT/'evidence/editorial/figure-sizing/compact-exact-comparisons.json';p.write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({'receipt':str(p.relative_to(ROOT)),'exports':len(outputs),'geometry':checks}))


if __name__=='__main__':main()
