"""Large, deterministic static figure exports for the v4 monograph.

Adapted from the retained P1 figstyle, with native 720/360px reading sizes.
Only plotting: no posterior fitting, selection or package solver imports.
"""
from pathlib import Path
import hashlib, json, textwrap, subprocess
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT = Path(__file__).resolve().parents[2]
COLORS = {'ink':'#20333B', 'muted':'#53636B', 'teal':'#126D76',
          'ochre':'#A1731D', 'rust':'#A54732', 'light':'#EDF3F2',
          'line':'#CAD5D7', 'gray':'#859398', 'white':'#FFFFFF'}

def canvas(height=6, mobile=False, title=None):
    """Return a 720pt or 360pt wide figure; height is inches."""
    plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':14 if mobile else 18,
        'axes.titlesize':16 if mobile else 21, 'axes.labelsize':14 if mobile else 18,
        'xtick.labelsize':13 if mobile else 16, 'ytick.labelsize':13 if mobile else 16,
        'legend.fontsize':13 if mobile else 16, 'text.color':COLORS['ink'],
        'axes.labelcolor':COLORS['ink'], 'xtick.color':COLORS['muted'],
        'ytick.color':COLORS['muted'], 'axes.edgecolor':COLORS['line'],
        'axes.spines.top':False, 'axes.spines.right':False, 'axes.grid':False,
        'figure.facecolor':'white', 'axes.facecolor':'white', 'savefig.facecolor':'white',
        'svg.fonttype':'path', 'svg.hashsalt':'postrank-v4-static-2026',
        'pdf.fonttype':42, 'mathtext.fontset':'dejavusans'})
    fig=plt.figure(figsize=(5 if mobile else 10,height))
    if title: fig.suptitle(title,fontsize=17 if mobile else 23,y=.97,fontweight='bold')
    return fig

def diagram(fig, rect=(.045,.055,.91,.84)):
    ax=fig.add_axes(rect);ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off');return ax

def clean(ax, grid='x'):
    ax.spines[['top','right']].set_visible(False)
    if grid: ax.grid(axis=grid,color=COLORS['line'],linewidth=.7);ax.set_axisbelow(True)
    return ax

def box(ax,x,y,w,h,label,*,color='light',fontsize=None,wrap=None,bold=False):
    if wrap: label='\n'.join(textwrap.fill(line,wrap) for line in label.split('\n'))
    patch=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.008,rounding_size=0.008',
        facecolor=COLORS.get(color,color),edgecolor=COLORS['line'],linewidth=1)
    ax.add_patch(patch)
    ax.text(x+w/2,y+h/2,label,ha='center',va='center',fontsize=fontsize,
        fontweight='bold' if bold else 'normal',linespacing=1.25)
    return patch

def arrow(ax,a,b,*,patchA=None,patchB=None,label=None,fontsize=None):
    ax.add_patch(FancyArrowPatch(a,b,patchA=patchA,patchB=patchB,arrowstyle='-|>',
        mutation_scale=16,linewidth=1.2,color=COLORS['muted'],shrinkA=4,shrinkB=4))
    if label: ax.text((a[0]+b[0])/2,(a[1]+b[1])/2,label,ha='center',va='center',
        fontsize=fontsize,bbox={'facecolor':'white','edgecolor':'none','pad':3})

def note(fig, text, *, mobile=False, y=.025):
    fig.text(.045,y,text,fontsize=12 if mobile else 14,color=COLORS['muted'],va='bottom')

def export(fig, fid, *, mobile=False, title=None, alt=None):
    """SVG/PDF + PNG raster of the PDF itself; return current export receipts.

    PDF raster inspection is not a browser observation or a whole-book print test.
    """
    stem=fid+('-mobile' if mobile else '')
    out=ROOT/'assets/figures';out.mkdir(parents=True,exist_ok=True)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer();bounds=fig.bbox;outside=[]
    for text in fig.findobj(matplotlib.text.Text):
        if not text.get_visible() or not text.get_text().strip():continue
        b=text.get_window_extent(renderer)
        if b.x0<bounds.x0-1 or b.x1>bounds.x1+1 or b.y0<bounds.y0-1 or b.y1>bounds.y1+1:
            outside.append(text.get_text())
    if outside: raise ValueError(f'{stem}: text outside canvas: {outside}')
    files=[]
    for ext in ['svg','pdf']:
        p=out/f'{stem}.{ext}'
        meta=({'Date':None,'Creator':'JoonHo Lee','Title':title or fid,'Description':alt or ''}
              if ext=='svg' else {'CreationDate':None,'ModDate':None,'Creator':'JoonHo Lee',
                                  'Author':'JoonHo Lee','Title':title or fid,'Subject':alt or ''})
        fig.savefig(p,metadata=meta,bbox_inches=None)
    plt.close(fig)
    qa=ROOT/'evidence/figures/rasters';qa.mkdir(parents=True,exist_ok=True)
    subprocess.run(['pdftoppm','-singlefile','-r','72','-png',str(out/f'{stem}.pdf'),str(qa/stem)],check=True)
    for p in [out/f'{stem}.svg',out/f'{stem}.pdf',qa/f'{stem}.png']:
        files.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,
                      'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    return files

def record(fid, outputs, inputs, notes=None):
    p=ROOT/'evidence/figures/builds'/f'{fid}.json';p.parent.mkdir(parents=True,exist_ok=True)
    receipts=[]
    for value in inputs:
        q=ROOT/value
        receipts.append({'path':value,'bytes':q.stat().st_size,
                         'sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
    p.write_text(json.dumps({'id':fid,'outputs':outputs,'inputs':receipts,
        'scope':'Static rendering from declared inputs; no model fit or optimization.',
        'raster_source':'PDF at72dpi; native720px or360px width','notes':notes or []},indent=2)+'\n')
