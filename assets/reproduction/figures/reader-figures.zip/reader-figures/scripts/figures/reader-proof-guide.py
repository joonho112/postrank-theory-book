"""Compact FA reader panels; symbolic proof guide only, no scientific runs."""
from pathlib import Path
import hashlib,json
from importlib.util import spec_from_file_location,module_from_spec
P=Path(__file__).with_name('reader-governance.py')
s=spec_from_file_location('reader_governance',P);g=module_from_spec(s);s.loader.exec_module(g)
ROOT=g.ROOT

def routes(narrow):
    p=g.Page(360,910) if narrow else g.Page(700,480)
    decl='Target, law, loss and feasible family.\nRetain original units and pair count M.'
    weak='Equality counts as wrong.\n'+r'$R^s=[A^s+\tau(M-N)]/M$'
    neutral='Strict error + distinct withholding.\n'+r'$R^s_{\mathrm{TA}}=[A^s_{\mathrm{TA}}+\tau(T-Q)]/M$'
    compare='Own-risk optimum: eligible competitors;\nsame law, loss and feasible family.\nCount hull (N, A): fixed family;\nwhole reports.'
    guard='Guard exists: full at-most G, no extras,\noriginal pairs retained; existence only.\nDistinct-mass hull (Q, A): fixed family;\nwhole reports.'
    weak_half='Complementarity; full '+r'$\mathcal{A}_n$'+'.\nAll strict unit-order children feasible.'
    neutral_half='Full active-profile equality classes.\nAll class-strict children feasible.\nNot guard existence alone.'
    if not narrow:
        p.text(24,16,'A  Selected proof routes',19,True)
        p.panel(24,50,652,68,'Common declaration',decl,size=12.8,color='light')
        for x,title,body in [(24,'Weak-error route',weak),(356,'Equality-neutral route',neutral)]:
            p.panel(x,130,320,78,title,body,size=12.8,title_size=13.6)
        p.panel(24,220,320,106,'Risk → comparison and count hull',compare,size=12.6,title_size=12.8)
        p.panel(356,220,320,106,'Risk → guard and distinct-mass hull',guard,size=12.6,title_size=12.8)
        p.panel(24,338,320,88,'Hull → extra half-cost conditions',weak_half,size=12.8,title_size=12.8,color='light')
        p.panel(356,338,320,88,'Hull → extra half-cost conditions',neutral_half,size=12.8,title_size=12.8,color='light')
        p.text(24,442,'Selected prerequisites only; finite-sum risk needs no criterion independence.\nGuard existence is a separate result: it does not imply the half-cost route.',12.4,color='muted')
    else:
        p.text(16,16,'A  Selected proof routes',17,True)
        p.panel(14,54,332,86,'Common declaration',decl,size=13.3)
        p.panel(14,153,332,82,'Weak-error route',weak,size=13.3,title_size=14)
        p.panel(14,246,332,116,'Risk → comparison and count hull',compare,size=13.0,title_size=13)
        p.panel(14,373,332,92,'Hull → extra half-cost conditions',weak_half,size=13.3,title_size=13,color='light')
        p.panel(14,485,332,82,'Equality-neutral route',neutral,size=13.2,title_size=14)
        p.panel(14,578,332,116,'Risk → guard and distinct-mass hull',guard,size=13.0,title_size=13)
        p.panel(14,705,332,108,'Hull → extra half-cost conditions',neutral_half,size=13.3,title_size=13,color='light')
        p.text(16,834,'Selected prerequisites, not a full proof graph.\nFinite-sum risk needs no criterion\nindependence. Guard existence is separate:\nit does not imply the half-cost route.',13,color='muted')
    return p

def refinement(narrow):
    p=g.Page(360,1030) if narrow else g.Page(700,590)
    weak=r'$\bar e_{ij}+\bar e_{ji}=1$'+'\nFull unrestricted '+r'$\mathcal{A}_n$'+'.\nAll strict unit-order children.\n'+r'$q=M-N(g^*)$'
    neutral=r'$c_{ij}+c_{ji}=\delta_{ij}$'+'\nFull active-profile equality classes.\nAll class-strict children feasible.\nOriginal unit-pair multiplicities.\n'+r'$q=T-Q(g^*)$'
    if not narrow:
        p.text(24,16,'B  Why every required refinement is optimal',18,True)
        p.text(24,43,'Qualified half-cost argument; one fixed law, loss and feasible family',12.3,color='muted')
        p.panel(24,66,652,63,'Required premise',r'$g^*$'+' is an EXACT minimizer at '+r'$\tau=1/2$'+'. EVERY required child is feasible.',size=12.8,color='light')
        p.panel(24,140,320,126,'Weak: full unit refinements',weak,size=12.8,title_size=13.3)
        p.panel(356,140,320,126,'Neutral: full class refinements',neutral,size=12.6,title_size=13.3)
        p.panel(24,277,652,80,'Uniform average over ALL required children',r'Mean added error $=q/2$; half-cost withholding reduction $=q/2$.'+'\n'+r'$\operatorname{Mean} R(r)=R(g^*)=R^*$',size=12.8,title_size=13.3)
        p.panel(24,368,320,72,'Exact optimum + feasible children',r'$R(r)-R^*\geq0$'+' for every child.',size=12.8,title_size=12.6)
        p.panel(356,368,320,72,'Uniform mean of all child gaps',r'$\frac{1}{L}\sum_{\ell=1}^{L}[R(r_\ell)-R^*]=0$',size=13.3,title_size=12.6)
        p.text(350,446,'Both facts together ⇒ every required child has '+r'$R(r)=R^*$',13.5,True,ha='center')
        p.text(24,481,'Endpoints: weak '+r'$N=M$'+'; neutral '+r'$Q=T$'+' (raw '+r'$N$'+' may remain below '+r'$M$'+').\nGuarded '+r'$T=0$'+': one class/all-withhold, point frontier; '+r'$Q/T$'+' undefined.',12.4,color='muted')
        p.text(24,530,'Uniform averaging is a proof device, not a reporting policy. Caps, fixed orders,\nprotections and T11 need separate arguments. No arbitrary-refinement\nguarantee for an approximate optimizer.',12.5,color='muted')
    else:
        p.text(16,16,'B  Why every required\nrefinement is optimal',17,True)
        p.text(16,67,'One fixed law, loss and feasible family',12.7,color='muted')
        p.panel(14,98,332,80,'Required premise',r'$g^*$'+' is an EXACT minimizer at '+r'$\tau=1/2$'+'.\nEVERY required child is feasible.',size=13.3,color='light')
        p.panel(14,190,332,118,'Weak: full unit refinements',weak,size=13.3,title_size=13.7)
        p.panel(14,320,332,133,'Neutral: full class refinements',neutral,size=13.3,title_size=13.7)
        p.panel(14,465,332,115,'Uniform average over ALL children','ALL required children are included.\nMean added error '+r'$=q/2$'+'.\nHalf-cost withholding reduction '+r'$=q/2$'+'.\n'+r'$\operatorname{Mean} R(r)=R(g^*)=R^*$',size=13.3,title_size=13.2)
        p.panel(14,592,332,67,'Exact optimum + feasible children',r'$R(r)-R^*\geq0$'+' for every child.',size=13.3,title_size=13.1)
        p.panel(14,671,332,77,'Uniform mean of all child gaps',r'$\frac{1}{L}\sum_{\ell=1}^{L}[R(r_\ell)-R^*]=0$',size=13.3,title_size=13.1)
        p.panel(14,760,332,67,'Both facts together','Every required child has '+r'$R(r)=R^*$'+'.',size=13.3,title_size=14,color='light')
        p.text(16,849,'Endpoints: weak '+r'$N=M$'+'; neutral '+r'$Q=T$'+'.\nNeutral raw '+r'$N$'+' need not equal '+r'$M$'+'.\nGuarded '+r'$T=0$'+': one class/all-withhold;\npoint frontier; '+r'$Q/T$'+' undefined.',13.0,color='muted')
        p.text(16,934,'Uniform averaging is a proof device,\nnot a reporting policy. Caps, fixed orders,\nprotections and T11 need separate\narguments. No arbitrary-refinement\nguarantee for an approximate optimizer.',13.0,color='muted')
    return p

if __name__=='__main__':
    sources=[ROOT/'assets/reproduction/figures/generators/FA/generate.py',ROOT/'assets/reproduction/figures/generators/FA-route/route_panel.py']
    originals=[ROOT/'assets/figures'/('proof-route-and-refinement'+v+'.'+e) for v in ['','-mobile'] for e in ['svg','pdf','png']]
    original_pins=[g.pin(f) for f in originals]
    exports=[]
    for label,draw in [('routes',routes),('refinement',refinement)]:
        for narrow in [False,True]:exports.append(g.export(draw(narrow),'fa-'+label,'narrow' if narrow else 'normal'))
    assert original_pins==[g.pin(f) for f in originals]
    d={'step':'11.150','author':'theory_migration_audit','scope':'Two compact symbolic reader panels for retained FA; all scientific conditions retained. No numerical proof/model/optimizer execution.','inputs':[g.pin(f) for f in [Path(__file__),P,ROOT/'scripts/figures/style_v4.py']+sources],'actual_read_scope':[{'path':str(f.relative_to(ROOT)),'bytes':f.stat().st_size,'range':'complete bounded source generator/module'} for f in sources],'original_assets_unchanged':original_pins,'exports':exports,'source_mapping':{'route_panel.py labels/common':'routes common declaration; original units and M preserved','labels/weak,neutral':'two separate loss formulas; not an implication from weak to neutral','weak_compare,weak_hull':'weak column comparison/count-hull card, same eligible family/law/loss','guard,neutral_hull':'neutral card: guard existence only, full at-most G/no extras/original pairs; distinct-mass hull fixed family','weak_half,neutral_half':'separate extra half-cost conditions; no edge from guard to half-cost conclusion','generate.py mechanism/premise':'refinement required premise, exact optimum at half cost and ALL required children feasible','mechanism/weak,neutral':'separate full-unit and full-active-profile-class cards with complementarity, q values, original-pair multiplicities','mechanism/average':'uniform average over ALL required children; two q/2 terms cancel, same optimum risk','mechanism/lower,mean,conclusion':'nonnegative gaps plus zero average imply every required child optimal','mechanism/endpoints':'weak N=M; neutral Q=T with raw N possibly below M; guarded T=0 all-withhold point frontier and undefined Q/T','mechanism/scope':'proof device only; caps/fixed orders/protections/T11 separate; no arbitrary-refinement result for approximate optimizer'},'editorial_change':'Selected graph routes expressed as explicit risk→comparison/hull and hull→extra-condition labels; guard existence remains separate. Two individually sized panels replace one tall combined default.','integration_recommendation':{'original_figure_id':'fig-vis-fa','normal_panels':['assets/figures/reader-fa-routes-normal.svg','assets/figures/reader-fa-refinement-normal.svg'],'narrow_panels':['assets/figures/reader-fa-routes-narrow.svg','assets/figures/reader-fa-refinement-narrow.svg'],'complete_conditions_in_images':True,'adjacent_proof_guide_addition_required':False,'canonical_changes_by_author':False},'actual_visual_observation':'pending author viewing all exported PDF/SVG rasters','browser_observed':False,'independent_review':'root11.151 pending'}
    out=ROOT/'evidence/editorial/figure-sizing/compact-fa.json';out.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'receipt':str(out.relative_to(ROOT)),'sizes':[(e['figure'],e['variant'],e['geometry_checks']) for e in exports]},indent=2))
