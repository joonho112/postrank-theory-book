"""Separate legible derivative of retained F14a; no mathematical computation."""
from pathlib import Path
import hashlib, json
import style_v4 as fs
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

FID = 'v4-f14a-action-space'
SOURCE = fs.ROOT / 'assets/figures/action-space-inclusions.svg'
PIN = 'f765fc95a02bdf4e5aad6e325af5a1c5da164bcbd48e79584a4704f91d8c2cd2'
ALT = ('Five action families connected by four arrows pointing from subsets to containing sets. '
       'Coarsenings of score-tie blocks with at most G grades are contained in fixed-order '
       'contiguous reports with at most G grades, which are contained in all at-most-G reports, '
       'which are contained in all ordered partitions. Exactly-G reports also point to all '
       'at-most-G reports. No arrow connects exactly-G reports and fixed-order reports.')

def render(mobile=False):
    width, height = (360, 900) if mobile else (720, 1000)
    fig = fs.canvas(height/72, mobile=mobile)
    ax = fig.add_axes([0, 0, 1, 1]); ax.set(xlim=(0,width),ylim=(height,0)); ax.axis('off')
    c=fs.COLORS; body=14 if mobile else 19
    def text(x,y,s,**kw):
        kw.setdefault('fontsize',body)
        return ax.text(x,y,s,va='center',ha='center',**kw)
    text(width/2,28,'Inclusions among grade-report families' if not mobile else 'Inclusions among\ngrade-report families',fontweight='bold',fontsize=body+2)
    text(width/2,70 if mobile else 66,r'Arrows mean subset ($\subseteq$).')
    text(width/2,91 if mobile else 94,'They point toward the larger set.')
    x, w, h = (20,285,75) if mobile else (48,540,96)
    ys=[125,260,395,530,685] if mobile else [130,290,450,610,790]
    labels=[('All ordered partitions',r'$\mathcal{A}_n$'),
            ('At most G grades',r'$\mathcal{A}_{\leq G}$'),
            (r'Fixed order $\rho$, at most G',r'$\mathcal{A}_\rho\cap\mathcal{A}_{\leq G}$'),
            ('Coarsen score-tie blocks',r'$\mathcal{C}_{\mathrm{score},\leq G}$'),
            ('Exactly G grades',r'$\mathcal{A}_{=G}$')]
    for i,((label,math),y) in enumerate(zip(labels,ys)):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=9',
                     facecolor=c['light'] if i<4 else '#FFF5E6',edgecolor=c['teal'] if i<4 else c['ochre'],linewidth=1.2))
        text(x+w/2,y+h*.31,label,fontweight='bold')
        text(x+w/2,y+h*.72,math,fontsize=20 if mobile else 29)
    cx=x+w/2
    for lower,upper in [(1,0),(2,1),(3,2)]:
        ax.add_patch(FancyArrowPatch((cx,ys[lower]-2),(cx,ys[upper]+h+2),arrowstyle='-|>',mutation_scale=17,linewidth=1.6,color=c['teal']))
        text(cx+25,(ys[lower]+ys[upper]+h)/2,r'$\subseteq$',fontsize=19 if mobile else 28)
    branch=333 if mobile else 650
    ax.plot([x+w,branch,branch],[ys[4]+h/2,ys[4]+h/2,ys[1]+h/2],color=c['teal'],linewidth=1.6)
    ax.add_patch(FancyArrowPatch((branch,ys[1]+h/2),(x+w+1,ys[1]+h/2),arrowstyle='-|>',mutation_scale=17,linewidth=1.6,color=c['teal']))
    text(branch+13,(ys[4]+ys[1]+h)/2,r'$\subseteq$',fontsize=17 if mobile else 26)
    footer=(r'$1\leq G\leq n$; $\rho$ refines the score order.'+'\nInclusion need not be strict.\nExact G is a separate restriction.')
    text(width/2,822 if mobile else 952,footer,fontsize=13 if mobile else 17,linespacing=1.3)
    return fig

if __name__=='__main__':
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==PIN
    outputs=[]
    for mobile in (False,True):
        outputs+=fs.export(render(mobile),FID,mobile=mobile,title='Inclusions among grade-report families',alt=ALT)
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==PIN
    fs.record(FID,outputs,['assets/figures/action-space-inclusions.svg','chapters/19-computing-grades.qmd','scripts/figures/F14a_v4.py','scripts/figures/style_v4.py'],
              ['Step9.50; original unchanged. Separate derivative fixes observed offline CairoSVG glyph/subscript portability, not an observed browser failure.',
               'Four subset arrows preserved; no inclusion asserted between exactly-G and fixed-order families. Same declared objective and score-order refinement conditions.',
               'Mathtext glyph paths replace font-dependent baseline-shift text. No solver, hull, fitting or scientific numerical rerun.'])
