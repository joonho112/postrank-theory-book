"""Compact reader derivatives of retained F21/F22; no scientific computations."""
from pathlib import Path
import ast, hashlib, json, subprocess, textwrap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import style_v4 as style

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'assets/figures'
QA=ROOT/'evidence/editorial/figure-sizing/rasters'
C=style.COLORS

def literal(fid,name):
    p=ROOT/'assets/reproduction/figures/generators'/fid/'generate.py'
    for node in ast.parse(p.read_text()).body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets):
            return ast.literal_eval(node.value)
    raise KeyError((fid,name))

class Page:
    def __init__(self,w,h):
        self.w,self.h=w,h
        self.fig=style.canvas(height=h/72,mobile=w<500)
        self.fig.set_size_inches(w/72,h/72)
        self.ax=self.fig.add_axes([0,0,1,1]);self.ax.set(xlim=(0,w),ylim=(h,0));self.ax.axis('off')
        self.texts=[];self.contained=[]
    def text(self,x,y,s,size=13.4,bold=False,color='ink',ha='left',wrap=None):
        if wrap:s='\n'.join(textwrap.fill(line,wrap) for line in s.split('\n'))
        t=self.ax.text(x,y,s,fontsize=size,fontweight='bold' if bold else 'normal',color=C[color],ha=ha,va='top',linespacing=1.2)
        self.texts.append(t);return t
    def panel(self,x,y,w,h,title,body,*,size=13.4,title_size=14,wrap=None,color='white',title_wrap=None):
        p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=5',facecolor=C[color],edgecolor=C['line'],linewidth=.8);self.ax.add_patch(p)
        t=self.text(x+12,y+10,title,title_size,True,wrap=title_wrap)
        title_lines=t.get_text().count('\n')+1
        b=self.text(x+12,y+12+title_lines*(title_size*1.2)+5,body,size,wrap=wrap)
        self.contained.extend([(p,t),(p,b)]);return p
    def check(self):
        self.fig.canvas.draw();r=self.fig.canvas.get_renderer()
        for t in self.texts:
            b=t.get_window_extent(r);f=self.fig.bbox
            assert b.x0>=f.x0 and b.x1<=f.x1 and b.y0>=f.y0 and b.y1<=f.y1,('outside canvas',t.get_text())
        for p,t in self.contained:
            a=p.get_window_extent(r);b=t.get_window_extent(r)
            assert b.x0>=a.x0+1 and b.x1<=a.x1-1 and b.y0>=a.y0+1 and b.y1<=a.y1-1,('panel overflow',t.get_text())
        for i,t in enumerate(self.texts):
            b=t.get_window_extent(r)
            for u in self.texts[i+1:]:assert not b.overlaps(u.get_window_extent(r)),('text overlap',t.get_text(),u.get_text())
        return {'canvas_text_containment':True,'panel_text_containment':len(self.contained),'text_nonoverlap':True,'width_px':self.w,'height_px':self.h}

def draw_f21(narrow):
    cards=literal('F21','CARDS');routes=literal('F21','ROUTES')
    p=Page(360,990) if narrow else Page(700,550)
    if not narrow:
        p.text(24,16,'A grade report a reader can inspect',19,True)
        p.text(24,44,'ILLUSTRATIVE DESIGN • NO DATA ANALYZED',11.5,True,'teal')
        p.panel(24,68,652,72,'Release fields to complete','Population and period: [declare]     Data/model/policy versions: [record]\nAdopting authority: [name role]',size=12.8,color='light')
        p.text(24,151,'Label convention • schematic only',13.3,True)
        p.panel(24,174,205,52,'A — Earlier','',size=12.5)
        p.panel(229,174,205,52,'B, C — Shared','',size=12.5)
        p.panel(454,174,222,52,'Unassessed','Outside grades',size=12.4,title_size=12.8,color='light')
        for i,(title,body) in enumerate(cards+routes):
            p.panel(24+(i%2)*332,238+(i//2)*101,320,92,title,body,size=12.8,title_size=13.5,color='light' if i>=4 else 'white')
    else:
        p.text(16,14,'A grade report\na reader can inspect',17,True)
        p.text(16,60,'ILLUSTRATIVE DESIGN • NO DATA ANALYZED',10.8,True,'teal')
        p.panel(14,88,332,111,'Release fields to complete','Population and period: [declare]\nData/model/policy versions: [record]\nAdopting authority: [name role]',size=13.3,title_size=14)
        p.text(14,211,'Label convention • schematic only',13.1,True)
        p.panel(14,235,102,64,'A','Earlier',size=13.5,title_size=14)
        p.panel(116,235,102,64,'B, C','Shared',size=13.5,title_size=14)
        p.panel(232,235,114,64,'Unassessed','Outside\ngrades',size=12.4,title_size=12.0,color='light')
        for i,(title,body) in enumerate(cards+routes):
            p.panel(14,314+i*110,332,101,title,body,size=13.4,title_size=14,wrap=40,color='light' if i>=4 else 'white')
    return p

def draw_f22(narrow):
    layers=literal('F22','LAYERS');layers[3]=('Prospective empirical evaluation',layers[3][1],layers[3][2])
    p=Page(360,1020) if narrow else Page(700,590)
    if not narrow:
        p.text(24,16,'Established results and future evidence',19,True)
        p.text(24,44,'Different claim roles; no implied empirical completion',12.2,color='muted')
        p.panel(24,69,652,72,'Keep both targets visible','Composite magnitudes: coefficients a.\nCriterion-direction errors: weights w.',size=12.8,color='light')
        for i,(title,body,scope) in enumerate(layers):
            x=24+(i%2)*332;y=153+(i//2)*143
            panel=p.panel(x,y,320,132,title,body,size=12.8,title_size=13.2)
            t=p.text(x+12,y+96,scope,12.2,color='rust' if i==3 else 'teal');p.contained.append((panel,t))
        p.panel(24,440,652,92,'Bounded illustrations','Exact finite examples show possibilities under declared laws.\nTwo KRW action reconstructions support bounded consistency,\nnot a superior frontier or producer validation.',size=12.8,color='light')
        p.text(24,547,'Measurement validity • authorized preferences • causal benefit:\nfurther evidence required.',12.2,color='muted')
    else:
        p.text(16,14,'Established results\nand future evidence',17,True)
        p.text(16,62,'Different claim roles;\nno implied empirical completion',13.1,color='muted')
        p.panel(14,105,332,94,'Keep both targets visible','Composite magnitudes: coefficients a.\nCriterion-direction errors: weights w.',size=13.3,title_size=14)
        for i,(title,body,scope) in enumerate(layers):
            y=211+i*153
            panel=p.panel(14,y,332,143,title,body,size=13.3,title_size=13.6,wrap=40)
            t=p.text(26,y+105,scope,12.8,color='rust' if i==3 else 'teal');p.contained.append((panel,t))
        p.panel(14,825,332,126,'Bounded illustrations','Exact examples: possibilities\nunder declared finite laws.\nTwo KRW actions: bounded consistency,\nnot a superior frontier or\nproducer validation.',size=13.3,title_size=14,color='light')
        p.text(16,964,'Measurement validity, authorized preferences\nand causal benefit still need their own evidence.',12.2,color='muted')
    return p

def pin(path):return {'path':str(path.relative_to(ROOT)),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def export(page,fid,variant):
    checks=page.check();stem=f'reader-{fid}-{variant}';OUT.mkdir(exist_ok=True);QA.mkdir(parents=True,exist_ok=True)
    files=[]
    for ext in ['svg','pdf']:
        target=OUT/f'{stem}.{ext}'
        metadata={'Date':None,'Creator':'JoonHo Lee','Title':stem} if ext=='svg' else {'CreationDate':None,'ModDate':None,'Creator':'JoonHo Lee','Title':stem}
        page.fig.savefig(target,metadata=metadata);files.append(target)
    plt.close(page.fig)
    subprocess.run(['pdftoppm','-singlefile','-r','72','-png',str(OUT/f'{stem}.pdf'),str(QA/stem)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    files.append(QA/f'{stem}.png')
    # SVG is rasterized independently; this observes the actual exported format.
    import cairosvg
    target=QA/f'{stem}-svg.png';cairosvg.svg2png(url=str(OUT/f'{stem}.svg'),write_to=str(target),output_width=page.w);files.append(target)
    return {'figure':fid,'variant':variant,'geometry_checks':checks,'outputs':[pin(x) for x in files]}

if __name__=='__main__':
    results=[]
    for fid,draw in [('f21',draw_f21),('f22',draw_f22)]:
        for narrow in [False,True]:results.append(export(draw(narrow),fid,'narrow' if narrow else 'normal'))
    receipt={'scope':'Compact visual derivatives only; source labels preserved with recorded F22 reader terminology change. No scientific runs.','inputs':[pin(Path(__file__)),pin(ROOT/'scripts/figures/style_v4.py')]+[pin(ROOT/'assets/reproduction/figures/generators'/f/'generate.py') for f in ['F21','F22']],
        'reader_terminology_changes':[{'source':'Prospective P1 evidence','derivative':'Prospective empirical evaluation','preserved_status':'The main empirical study remains prospective.'},{'source':'Established results and the P1 research agenda','derivative':'Established results and future evidence'}],
        'layout_changes':['F21: tighter release and schematic-grade bands above the same six communication/action cards.','F22: four equally sized claim-role cards in a2×2 normal grid; no evidence ranking or inference arrows. Narrow version stacks the same roles.'],
        'source_preservation':'Original generators and their SVG/PDF/PNG assets are read-only and unchanged. Exact scientific clauses are imported from original literal CARDS/ROUTES/LAYERS.','exports':results,'actual_visual_observation':'pending author inspection of all final PDF and SVG rasters','browser_observed':False}
    p=ROOT/'evidence/editorial/figure-sizing/compact-f21-f22.json';p.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'receipt':str(p.relative_to(ROOT)),'exports':[(r['figure'],r['variant'],r['geometry_checks']) for r in results]},indent=2))
