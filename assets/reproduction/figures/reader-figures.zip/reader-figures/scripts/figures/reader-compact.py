"""Compact reader exports of F14a/F16a/F19b. Saved data only; plotting, not fitting.

Original and Phase9 figures remain untouched. Native PDF rasters are static checks.
"""
from pathlib import Path
from fractions import Fraction as Q
import hashlib,json,subprocess,importlib.util
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from matplotlib.lines import Line2D
from matplotlib.ticker import PercentFormatter
from PIL import Image,ImageOps

ROOT=Path(__file__).resolve().parents[2]
QA=ROOT/'evidence/editorial/figure-sizing/rasters'
C={'ink':'#20333B','muted':'#53636B','teal':'#126D76','ochre':'#A1731D','rust':'#A54732','light':'#EDF3F2','line':'#CAD5D7','gray':'#859398'}
INPUTS=['assets/figures/action-space-inclusions.svg','assets/figures/matched-disclosure-frontier.svg','assets/figures/objective-contrast.svg',
 'assets/reproduction/figures/data/f16a-frontier.json','assets/reproduction/figures/data/f19b-objective-contrast.json',
 'scripts/figures/F14a_v4.py','scripts/figures/F16a_v4.py','scripts/figures/F19b_v4.py','scripts/figures/style_v4.py']
for stem in ['v4-f14a-action-space','v4-f16a-matched-disclosure','v4-f19b-objective-contrast']:
 for suffix in ['', '-mobile']:
  for ext in ['svg','pdf']:INPUTS.append(f'assets/figures/{stem}{suffix}.{ext}')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(rel):
 p=ROOT/rel;return {'path':rel,'sha256':sha(p),'bytes':p.stat().st_size}
def canvas(w,h):
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'text.color':C['ink'],'axes.labelcolor':C['ink'],
  'xtick.color':C['muted'],'ytick.color':C['muted'],'axes.edgecolor':C['line'],'svg.fonttype':'path',
  'svg.hashsalt':'postrank-reader-compact-2026','pdf.fonttype':42,'mathtext.fontset':'dejavusans','figure.facecolor':'white'})
 return plt.figure(figsize=(w/72,h/72))
def text(fig,w,h,x,y,s,size=13,**kw):return fig.text(x/w,1-y/h,s,ha=kw.pop('ha','left'),va='top',fontsize=size,linespacing=1.2,**kw)
def plot(fig,w,h,left,top,width,height):
 ax=fig.add_axes([left/w,1-(top+height)/h,width/w,height/h]);ax.spines[['top','right']].set_visible(False)
 ax.grid(axis='y',color=C['line'],linewidth=.65);ax.set_axisbelow(True);ax.tick_params(labelsize=12,pad=3)
 return ax
def key(fig,w,h,x,y,label,color,style='-',marker='o',size=12.5):
 fig.add_artist(Line2D([(x)/w,(x+28)/w],[1-(y+6)/h]*2,transform=fig.transFigure,color=color,linestyle=style,marker=marker,markersize=3.5,linewidth=1.7))
 text(fig,w,h,x+37,y,label,size)
def read_data(name):return json.loads((ROOT/f'assets/reproduction/figures/data/{name}.json').read_text())

def f14(mobile):
 w,h=(360,550) if mobile else (660,400);fig=canvas(w,h)
 ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,w),ylim=(h,0));ax.axis('off')
 text(fig,w,h,w/2,15,'Inclusions among grade-report families' if not mobile else 'Inclusions among\ngrade-report families',16.5,ha='center',fontweight='bold')
 text(fig,w,h,w/2,62 if mobile else 46,r'Arrows point to containing sets ($\subseteq$).',12.5,ha='center')
 if mobile:
  boxes={'all':(16,100,220,60),'cap':(16,195,220,60),'order':(16,290,220,60),'score':(16,385,220,60),'exact':(250,310,96,88)}
 else:
  boxes={'score':(20,222,185,80),'order':(20,95,185,80),'cap':(237,95,185,80),'all':(454,95,185,80),'exact':(237,222,185,80)}
 labels={'all':('All ordered partitions',r'$\mathcal{A}_n$'),'cap':('At most G grades',r'$\mathcal{A}_{\leq G}$'),
  'order':(r'Fixed order $\rho$, at most G',r'$\mathcal{A}_\rho\cap\mathcal{A}_{\leq G}$'),
  'score':('Coarsen score-tie blocks',r'$\mathcal{C}_{\mathrm{score},\leq G}$'),
  'exact':('Exactly\nG grades' if mobile else 'Exactly G grades',r'$\mathcal{A}_{=G}$')}
 for name,(x,y,bw,bh) in boxes.items():
  edge=C['ochre'] if name=='exact' else C['teal'];fill='#FFF5E6' if name=='exact' else C['light']
  ax.add_patch(FancyBboxPatch((x,y),bw,bh,boxstyle='round,pad=0,rounding_size=5',facecolor=fill,edgecolor=edge,lw=1))
  title,math=labels[name]
  if not mobile and name=='order':title='Fixed order $\\rho$,\nat most G'
  if not mobile and name=='score':title='Coarsen score-tie\nblocks'
  ax.text(x+bw/2,y+(22 if not(mobile and name=='exact') else 27),title,ha='center',va='center',fontsize=12.5 if mobile else 13,fontweight='bold')
  ax.text(x+bw/2,y+bh-19,math,ha='center',va='center',fontsize=18)
 def arrow(a,b):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=13,lw=1.5,color=C['teal'],shrinkA=3,shrinkB=3))
 if mobile:
  for low,high in [('cap','all'),('order','cap'),('score','order')]:
   x,y,bw,bh=boxes[low];X,Y,BW,BH=boxes[high];arrow((x+bw/2,y),(X+BW/2,Y+BH))
  ax.plot([298,298],[310,225],color=C['teal'],lw=1.5);arrow((298,225),(236,225))
  text(fig,w,h,18,474,r'$1\leq G\leq n$; $\rho$ refines the score order.'+'\nInclusions need not be strict. Exact G is\na separate restriction. Same declared risk.',12.5)
 else:
  for low,high in [('score','order'),('exact','cap')]:
   x,y,bw,bh=boxes[low];X,Y,BW,BH=boxes[high];arrow((x+bw/2,y),(X+BW/2,Y+BH))
  arrow((205,135),(237,135));arrow((422,135),(454,135))
  text(fig,w,h,465,230,'Exact G and fixed order\nare not generally nested.',12.5,color=C['muted'])
  text(fig,w,h,20,334,r'$1\leq G\leq n$; $\rho$ refines the score order. Inclusions need not be strict.',13)
  text(fig,w,h,20,360,'All families are compared under the same declared risk.',13,color=C['muted'])
 return fig

def f16(mobile):
 d=read_data('f16a-frontier');w,h=(360,920) if mobile else (660,575);fig=canvas(w,h)
 text(fig,w,h,18,14,'Matched disclosure under one exact law' if not mobile else 'Matched disclosure\nunder one exact law',16.5,fontweight='bold')
 text(fig,w,h,18,58 if mobile else 44,'Four units; weights (3/5, 2/5); M = 6.\nBoth axes use expected raw counts.',12.5)
 positions=[(76,126,264,165),(76,452,264,165)] if mobile else [(62,120,238,190),(406,120,238,190)]
 heads=[(18,100),(18,426)] if mobile else [(62,92),(406,92)]
 axes=[];plotted={}
 for i,(pos,(tx,ty)) in enumerate(zip(positions,heads)):
  text(fig,w,h,tx,ty,['A. Report families: A = 0–5','B. Enlarged scale: A = 0–1.1'][i],13,fontweight='bold')
  ax=plot(fig,w,h,*pos);axes.append(ax)
  if i==0:
   points=d['gray_distinct_coordinates'];assert len(points)==55 and sum(p['source_reports_at_coordinate']for p in points)==75
   ax.scatter([p['N'] for p in points],[float(Q(p['A']))for p in points],s=12,color='#AAB6BC',zorder=2)
  families=[('unrestricted','teal','-'),('order_DCBA','rust','--')] if i==0 else [('unrestricted','teal','-'),('sparse_endpoints','ochre',':')]
  for name,col,style in families:
   vertices=d['families'][name]['vertices'];x=[v[0]for v in vertices];y=[float(Q(v[1]))for v in vertices]
   line,=ax.plot(x,y,color=C[col],linestyle=style,marker='o',ms=3.5,lw=1.8,zorder=3)
   assert list(line.get_xdata())==x and list(line.get_ydata())==y;plotted[name]=vertices
  ax.set(xlim=(-.16,6.16),ylim=(-.12,5.12) if i==0 else(-.03,1.12),xticks=range(7),yticks=range(6)if i==0 else[0,.25,.5,.75,1])
  ax.set_xlabel('Expected disclosed count, N',fontsize=12.5,labelpad=7)
  ax.set_ylabel('Expected weighted\nwrong-count, A',fontsize=12.5,labelpad=7)
 axes[1].scatter([4],[float(Q(d['matched_N4']['best_deterministic_A_at_N4']))],marker='s',s=34,color=C['ink'],zorder=5)
 axes[1].scatter([4],[float(Q(d['matched_N4']['mean_A']))],marker='D',s=34,color=C['ink'],zorder=5)
 if mobile:
  key(fig,w,h,18,342,'Exact frontier: all 75 reports',C['teal']);key(fig,w,h,18,366,'Imposed reverse order DCBA',C['rust'],'--')
  text(fig,w,h,18,391,'Grey: 55 distinct coordinates; equal sizes.',12)
  key(fig,w,h,18,670,'Exact frontier',C['teal']);key(fig,w,h,18,694,'Two-endpoint candidate hull',C['ochre'],':')
  text(fig,w,h,18,730,'■  N = 4: best deterministic A = 7/10.\n◆  Mean N = 4: mixture A = 19/40.',12.5)
  text(fig,w,h,18,776,'Mix (1,1,1,2) and (1,2,2,3) equally,\nindependently of the latent state.\nMix whole reports, never pair decisions.',12.5)
  text(fig,w,h,18,836,'N = 5: sparse A = 7/8; exact A = 13/20;\ngap = 9/40. Sparse hull omits reports\nand lies on or above the exact frontier.',12.5)
 else:
  key(fig,w,h,62,362,'Exact frontier: 75 reports',C['teal'],size=12);key(fig,w,h,62,386,'Reverse order DCBA',C['rust'],'--',size=12)
  key(fig,w,h,406,362,'Exact frontier',C['teal'],size=12);key(fig,w,h,406,386,'Two-endpoint hull',C['ochre'],':',size=12)
  text(fig,w,h,18,418,'Grey: 55 distinct coordinates, equal sizes. Panel vertical scales differ.',12.5)
  text(fig,w,h,18,444,'■  N = 4 deterministic: A = 7/10; ◆  mean N = 4 mixture: A = 19/40.',12.5)
  text(fig,w,h,18,474,'Mix (1,1,1,2) and (1,2,2,3) equally, independently of the latent state.\nRandomize whole reports, never pair decisions.',12.5)
  text(fig,w,h,18,518,'N = 5: sparse A = 7/8; exact A = 13/20; gap = 9/40.\nThe sparse hull omits reports and lies on or above the exact frontier.',12.5)
 return fig

def f19(mobile):
 d=read_data('f19b-objective-contrast');w,h=(360,850)if mobile else(660,485);fig=canvas(w,h)
 text(fig,w,h,18,14,'Three units, two objective contrasts'if not mobile else'Three units,\ntwo objective contrasts',16.5,fontweight='bold')
 text(fig,w,h,18,58 if mobile else 44,'One exact synthetic law; larger targets have higher priority.'if not mobile else'One exact synthetic law; larger targets\nhave higher priority.',12.5)
 heads=[(18,104),(18,449)]if mobile else[(62,88),(406,88)]
 poses=[(64,130,276,175),(64,477,276,190)]if mobile else[(62,116,238,190),(406,116,238,190)]
 for (x,y),label in zip(heads,['A. Coherent reports','B. Select one unit']):text(fig,w,h,x,y,label,13,fontweight='bold')
 ax=plot(fig,w,h,*poses[0]);bx=plot(fig,w,h,*poses[1])
 for name,col,style in [('unrestricted','teal','-'),('mean_order_ABC','ochre','--')]:
  points=d['families'][name]['hull'];x=[p[0]for p in points];y=[float(Q(p[1]))for p in points];line,=ax.plot(x,y,color=C[col],ls=style,marker='o',ms=4,lw=1.8)
  assert list(line.get_xdata())==x and list(line.get_ydata())==y
 ax.set(xlim=(-.06,3.06),ylim=(0,1.5),xticks=[0,1,2,3],yticks=[0,.3,.6,.9,1.2,1.5])
 ax.set_xlabel('Expected disclosed pairs',fontsize=12.5,labelpad=7);ax.set_ylabel('Expected wrong count',fontsize=12.5,labelpad=7)
 for row in d['allocation_singletons']+[dict(d['added_AB_lottery'],unit='A–B lottery')]:
  x=float(Q(row['expected_selected_value']));y=float(Q(row['probability_select_best']));lottery=row['unit']=='A–B lottery'
  mark=bx.scatter([x],[y],s=40,marker='D'if lottery else'o',color=C['gray']if lottery else C['teal'],edgecolor=C['ink'],lw=.6,zorder=3)
  assert list(mark.get_offsets()[0])==[x,y]
  bx.annotate(row['unit'],(x,y),xytext=(0,7),textcoords='offset points',ha='center',fontsize=12.5,fontweight='bold')
 bx.set(xlim=(2.7,6.3),ylim=(-.02,.85),xticks=[3,4,5,6],yticks=[0,.2,.4,.6,.8]);bx.yaxis.set_major_formatter(PercentFormatter(1,decimals=0))
 bx.set_xlabel('Expected selected target value',fontsize=12.5,labelpad=7);bx.set_ylabel('Chance of selecting the best',fontsize=12.5,labelpad=7)
 if mobile:
  key(fig,w,h,18,354,'All coherent reports',C['teal']);key(fig,w,h,18,378,'Mean-order reports',C['ochre'],'--')
  text(fig,w,h,18,407,'Segments mix whole reports;\nN = 1 is not deterministic.',12.5)
  text(fig,w,h,18,716,'Circles select one named unit. The diamond\nadds a uniform A–B lottery to report 112,\nindependently of the latent state.',12.5)
  text(fig,w,h,18,780,'A reported tie does not select a unit.\nDifferent objectives; no causal policy effect.\nNo fit, simulation or solver is shown.',12.5)
 else:
  key(fig,w,h,62,356,'All coherent reports',C['teal'],size=12);key(fig,w,h,62,380,'Mean-order reports',C['ochre'],'--',size=12)
  text(fig,w,h,406,350,'Circles: one named unit.\nDiamond: uniform A–B lottery.',12)
  text(fig,w,h,18,411,'Segments mix whole reports; N = 1 is not deterministic. The A–B lottery adds\nselection to report 112 independently of the latent state; a tie selects no unit.',12.5)
  text(fig,w,h,18,452,'Different objectives; no causal policy effect, fitting, simulation or solver.',12.5,color=C['muted'])
 return fig

ALTS={'f14a':'Five action families with four inclusion arrows. Score-tie coarsenings are contained in fixed-order capped reports, then all capped reports, then all ordered partitions. Exact-G reports are also contained in capped reports; they are not generally nested with fixed-order reports. The order refines the score order, and inclusion need not be strict.',
 'f16a':'Two panels use different vertical scales under one exact four-unit law. All 55 distinct report coordinates and exact, imposed reverse-order and sparse-endpoint frontiers are retained. At mean disclosure four the whole-report mixture has wrong-count 19/40 versus deterministic 7/10; at disclosure five the sparse gap is 9/40. Mixing is independent of the latent state.',
 'f19b':'Reporting hulls and budget-one selection under the same three-unit synthetic law. A, B and C have expected selected values 6, 4 and 3 and best-unit probabilities 30%, 70% and 0%. An independent uniform A–B lottery gives 5 and 50%. Whole-report mixtures differ from allocation, and a reported tie does not select a unit.'}
def export(fig,stem,alt):
 fig.canvas.draw();renderer=fig.canvas.get_renderer();bounds=fig.bbox;outside=[]
 for txt in fig.findobj(matplotlib.text.Text):
  if txt.get_visible()and txt.get_text().strip():
   box=txt.get_window_extent(renderer)
   if box.x0<bounds.x0-1 or box.x1>bounds.x1+1 or box.y0<bounds.y0-1 or box.y1>bounds.y1+1:outside.append(txt.get_text())
 if outside:raise ValueError((stem,'text outside canvas',outside))
 out=ROOT/'assets/figures';QA.mkdir(parents=True,exist_ok=True)
 for ext in ['svg','pdf']:
  meta={'Date':None,'Creator':'JoonHo Lee','Title':stem,'Description':alt}if ext=='svg'else{'CreationDate':None,'ModDate':None,'Creator':'JoonHo Lee','Author':'JoonHo Lee','Title':stem,'Subject':alt}
  fig.savefig(out/f'{stem}.{ext}',metadata=meta)
 plt.close(fig);subprocess.run(['pdftoppm','-singlefile','-r','72','-png',str(out/f'{stem}.pdf'),str(QA/stem)],check=True)
 im=Image.open(QA/f'{stem}.png');ImageOps.grayscale(im).save(QA/f'{stem}-gray.png')
 return {'width':im.width,'height':im.height,'outputs':[pin(str(p.relative_to(ROOT)))for p in [out/f'{stem}.svg',out/f'{stem}.pdf',QA/f'{stem}.png',QA/f'{stem}-gray.png']],'text_inside_canvas':True}
if __name__=='__main__':
 before=[pin(x)for x in INPUTS];result=[]
 for id,fn in [('f14a',f14),('f16a',f16),('f19b',f19)]:
  item={'id':id,'normal':export(fn(False),f'reader-{id}-normal',ALTS[id]),'narrow':export(fn(True),f'reader-{id}-narrow',ALTS[id])};result.append(item)
 assert before==[pin(x)for x in INPUTS]
 r={'step':'11.116','status':'GENERATED_PENDING_DIRECT_VISUAL_REVIEW','sourcepins':before,'source_assets_unchanged':True,'producer':pin('scripts/figures/reader-compact.py'),'figures':result,'browser_observed':False,'method':'Only saved exact coordinates and inclusion relations. No hull reconstruction, report enumeration, fit, solver, simulation or scientific replay. PNGs are actual PDF rasters at 72 dpi.','observed_images':[]}
 (ROOT/'evidence/editorial/figure-sizing/compact-derivatives.json').write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps([{'id':x['id'],'normal':[x['normal']['width'],x['normal']['height']],'narrow':[x['narrow']['width'],x['narrow']['height']]}for x in result]))
