"""Readable F16a derivatives from saved exact coordinates; no hull/enumeration."""
from pathlib import Path
from fractions import Fraction as Q
import hashlib, json
import style_v4 as fs
from matplotlib.lines import Line2D

FID='v4-f16a-matched-disclosure'
DATA=fs.ROOT/'assets/reproduction/figures/data/f16a-frontier.json'
SOURCE=fs.ROOT/'assets/figures/matched-disclosure-frontier.svg'
PIN='e2142c73904554c36930d81f063283c43e774dd1bf9d014c8cc86a024aa92391'
DATA_PIN='da859be26bf2d0968afa651c3b55d415385afb93bb29b8d9809458fe275b1cc3'
ALT='Two vertically stacked panels show an exact lower frontier, a worse imposed reverse-order frontier, and a sparse endpoint chord above the exact frontier. An equal mixture of reports with three and five disclosures attains mean disclosure four and wrong-count nineteen fortieths. Panel vertical scales differ.'

def values(v): return [float(Q(str(p[0]))) for p in v],[float(Q(str(p[1]))) for p in v]

def draw(d,mobile=False):
    height=1700 if mobile else 1580; width=360 if mobile else 720
    fig=fs.canvas(height/72,mobile=mobile);c=fs.COLORS
    body=14 if mobile else 18; heading=16 if mobile else 22
    def text(x,y,s,**kw):
        kw.setdefault('fontsize',body)
        return fig.text(x/width,1-y/height,s,ha='left',va='top',linespacing=1.25,**kw)
    def key(y,label,color,style='-',marker='o'):
        fig.add_artist(Line2D([24/width,61/width],[1-(y+8)/height]*2,transform=fig.transFigure,color=color,linestyle=style,marker=marker,markersize=4,linewidth=2))
        text(72,y,label)
    def plot(top,bottom,ylim,yticks,families,gray=False):
        left=88 if mobile else 118;right=340 if mobile else 685
        ax=fig.add_axes([left/width,1-bottom/height,(right-left)/width,(bottom-top)/height]);fs.clean(ax,'y')
        if gray:
            points=d['gray_distinct_coordinates'];ax.scatter([p['N'] for p in points],[float(Q(p['A'])) for p in points],s=22,color='#AAB6BC',zorder=2)
        for name,color,style in families:
            x,y=values(d['families'][name]['vertices']);ax.plot(x,y,color=c[color],linestyle=style,marker='o',markersize=4.5,linewidth=2,zorder=3)
        ax.set(xlim=(-.15,6.15),ylim=ylim,xticks=range(7),yticks=yticks)
        ax.tick_params(labelsize=13 if mobile else 16)
        ax.set_xlabel('Expected disclosed count, N',fontsize=13 if mobile else 18,labelpad=10)
        ax.set_ylabel('Expected weighted\nwrong-count, A',fontsize=14 if mobile else 18,labelpad=10)
        return ax
    text(24,22,'Matched disclosure: one exact law' if not mobile else 'Matched disclosure:\none exact law',fontsize=heading,fontweight='bold')
    text(24,72 if mobile else 65,'Four units; six unordered pairs.\nAxes show expected raw counts.\nFixed law: weights (3/5, 2/5); M = 6.')
    text(24,155,'A. Same law, different report families' if not mobile else 'A. Same law,\ndifferent report families',fontsize=heading,fontweight='bold')
    text(24,204 if mobile else 190,'Full vertical scale: A = 0 to 5')
    plot(250 if mobile else 235,555 if mobile else 535,(-.12,5.12),range(6),[('unrestricted','teal','-'),('order_DCBA','rust','--')],True)
    key(620 if mobile else 600,'Exact frontier: all 75 reports',c['teal'])
    key(650 if mobile else 635,'Imposed reverse order DCBA',c['rust'],'--')
    text(24,688 if mobile else 675,'Grey points: 55 distinct coordinates\nfrom 75 reports; equal point sizes.',color=c['muted'])
    text(24,760 if mobile else 755,'B. Whole-report mixing and a sparse hull' if not mobile else 'B. Whole-report mixing\nand a sparse hull',fontsize=heading,fontweight='bold')
    text(24,810 if mobile else 790,'Enlarged vertical scale: A = 0 to 1.1')
    ax=plot(855 if mobile else 835,1155 if mobile else 1135,(-.03,1.12),[0,.25,.5,.75,1],[('unrestricted','teal','-'),('sparse_endpoints','ochre',':')])
    ax.scatter([4],[float(Q(d['matched_N4']['best_deterministic_A_at_N4']))],color=c['ink'],marker='s',s=55,zorder=5)
    ax.scatter([4],[float(Q(d['matched_N4']['mean_A']))],color=c['ink'],marker='D',s=55,zorder=5)
    key(1220 if mobile else 1200,'Exact frontier',c['teal'])
    key(1250 if mobile else 1235,'Two-endpoint candidate hull',c['ochre'],':')
    key(1288 if mobile else 1275,'Best deterministic report at N = 4:\nA = 7/10',c['ink'],'None','s')
    key(1345 if mobile else 1330,'Whole-report mixture at mean N = 4:\nmean A = 19/40' if not mobile else 'Whole-report mixture at mean N = 4:\nmean A = 19/40',c['ink'],'None','D')
    text(24,1404 if mobile else 1390,'Choose g = (1,1,1,2) or (1,2,2,3),\neach with probability 1/2, independently\nof the latent state. Do not mix pairs.')
    text(24,1478 if mobile else 1470,'At N = 5: sparse A = 7/8;\nexact A = 13/20; gap = 9/40.' if mobile else 'At N = 5: sparse A = 7/8; exact A = 13/20; gap = 9/40.')
    text(24,1540 if mobile else 1512,'Panel vertical scales differ. The sparse\nhull omits feasible reports and lies\non or above this exact frontier.' if mobile else 'Panel vertical scales differ. The sparse hull omits feasible\nreports and lies on or above this exact frontier.',color=c['muted'])
    return fig

if __name__=='__main__':
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==PIN
    assert hashlib.sha256(DATA.read_bytes()).hexdigest()==DATA_PIN
    d=json.loads(DATA.read_text());assert len(d['gray_distinct_coordinates'])==55
    assert sum(p['source_reports_at_coordinate'] for p in d['gray_distinct_coordinates'])==75
    assert d['matched_N4']['mean_A']=='19/40' and d['sparse_N5']['gap']=='9/40'
    outputs=[]
    for mobile in (False,True): outputs+=fs.export(draw(d,mobile),FID,mobile=mobile,title='Matched disclosure under one exact law',alt=ALT)
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==PIN
    fs.record(FID,outputs,['assets/reproduction/figures/data/f16a-frontier.json','assets/reproduction/figures/generators/F16a/generate.py','assets/figures/matched-disclosure-frontier.svg','scripts/figures/F16a_v4.py','scripts/figures/style_v4.py'],
              ['Step9.52. Separate derivatives; retained normal/mobile originals unchanged.',
               'All vertices and55grey coordinates read directly from saved rational fields; multiplicities do not change point sizes. No hull, enumeration, solver or empirical computation.',
               'Two vertical scales explicitly stated; report mixtures are whole-report randomization independent of the latent state. Native720body18/axis16+; native360body14/axis13+.'])
