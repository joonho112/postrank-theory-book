"""Reader derivatives of FB/FC and a label-only F08 derivative.

Existing generators/assets are inputs only. No statistical calculation is run.
"""
from pathlib import Path
import ast, datetime, hashlib, importlib.util, json, sys, textwrap
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import style_v4 as style

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'assets/reproduction/figures/generators'
C = style.COLORS


def literals(tag, names):
    tree = ast.parse((SOURCE / tag / 'generate.py').read_text())
    result = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in names:
                    result[target.id] = ast.literal_eval(node.value)
    return result


PRED = literals('FB', {'PRED'})['PRED']
LANES = literals('FC', {'LANES'})['LANES']


def canvas(w, h):
    fig = style.canvas(h / 72)
    fig.set_size_inches(w / 72, h / 72)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set(xlim=(0, w), ylim=(h, 0)); ax.axis('off')
    return fig, ax


def text(ax, x, y, s, size=13, bold=False, color='ink', **kwargs):
    return ax.text(x, y, s, fontsize=size, fontweight='bold' if bold else 'normal',
                   color=C[color], ha='left', va='top', linespacing=1.2, **kwargs)


def panel(ax, x, y, w, h, fill='light'):
    ax.add_patch(Rectangle((x, y), w, h, facecolor=C[fill], edgecolor=C['line'], linewidth=.7))


def geometry(fig):
    fig.canvas.draw(); renderer = fig.canvas.get_renderer(); ts=[]
    for ax in fig.axes:
        ts.extend(t for t in ax.texts if t.get_text())
    ts.extend(t for t in fig.texts if t.get_text())
    boxes=[t.get_window_extent(renderer) for t in ts]
    outside=[t.get_text() for t,b in zip(ts,boxes) if b.x0 < -.2 or b.y0 < -.2 or b.x1 > fig.bbox.width+.2 or b.y1 > fig.bbox.height+.2]
    overlaps=[]
    for i,b in enumerate(boxes):
        for j,c in enumerate(boxes[i+1:],i+1):
            if b.overlaps(c): overlaps.append([ts[i].get_text(),ts[j].get_text()])
    if outside or overlaps: raise ValueError({'outside':outside,'overlaps':overlaps})
    return {'text_records':len(ts),'canvas_containment':True,'text_pair_nonoverlap':True}


def fb(mobile=False):
    fig,ax=canvas(360 if mobile else 640,1220 if mobile else 650)
    if not mobile:
        text(ax,16,12,'Counts, laws and denominators',18,True)
        text(ax,16,40,'Fix report g and information y; use nonnegative weights summing to one.',12)
        text(ax,16,58,'Choose ν = s (supplied) or P (evaluation).',12)
        panel(ax,16,84,608,63)
        text(ax,26,91,r'$M=\binom{n}{2}>0,\quad x_{ij}=\mathbf{1}\{g_i<g_j\},\quad N(g)=\sum_{i\ne j}x_{ij}$',13.5)
        text(ax,26,126,r'$N(g)/M$ is raw disclosure; it is fixed by g.',12)
        for x,s in [(24,'Realized count'),(257,'Average under ν at y'),(445,'Rate and condition')]:text(ax,x,158,s,12,True)
        rows=[('weak','Weak error (≤)',182),('strict','Strict reversal (<)',269),('distinct','Distinct opportunity (≠)',356)]
        for key,title,y in rows:
            panel(ax,16,y,608,80,'white'); text(ax,24,y+7,title,12.5,True)
            if key=='weak':
                text(ax,24,y+26,r'$D_k(g,\Theta)=$',12.5); text(ax,24,y+47,PRED[key],13)
                text(ax,257,y+29,r'$E_k^\nu(g)=\mathbb{E}_\nu[D_k\mid y]$',12.5)
                text(ax,445,y+28,r'$E_k^\nu(g)/N(g)$',13)
                text(ax,445,y+51,r'$N(g)>0$',12.5)
            elif key=='strict':
                text(ax,24,y+36,PRED[key],13)
                text(ax,257,y+27,r'$E_k^{b,\nu}(g)$',13)
                text(ax,257,y+50,'Expected strict-error count',11.2)
                text(ax,445,y+26,r'$E_k^{b,\nu}(g)/N(g),\ N(g)>0$',11.9)
                text(ax,445,y+51,r'$E_k^{b,\nu}(g)/Q_k^\nu(g)$',12.3)
                text(ax,569,y+51,r'$Q_k^\nu(g)>0$',10.6)
            else:
                text(ax,24,y+36,PRED[key],13)
                text(ax,257,y+27,r'$Q_k^\nu(g)$',13)
                text(ax,257,y+50,'Expected distinct mass',11.5)
                text(ax,445,y+28,r'$Q_w^\nu(g)/T_w^\nu$',13)
                text(ax,445,y+51,r'$T_w^\nu>0$',12.5)
        panel(ax,16,442,608,100)
        text(ax,26,449,'Weighting and total opportunity',13,True)
        text(ax,26,470,r'$Q_w^\nu(g)=\sum_k w_kQ_k^\nu(g),\quad T_w^\nu=\sum_{i<j}\sum_k w_kd_{ij,k}^\nu$',13)
        text(ax,26,510,r'$d_{ij,k}^\nu=\Pr_\nu(\theta_{ik}\ne\theta_{jk}\mid y)$',12.5)
        text(ax,322,513,'T: all original pairs; Q: disclosed directions.',11.5)
        panel(ax,16,554,608,67,'white')
        text(ax,26,561,'Inspected tie_aware_v1 field names',13,True)
        text(ax,26,583,'API D ↔ '+r'$Q_w^s(g)$'+'; API T ↔ '+r'$T_w^s$',13)
        text(ax,294,583,'Supplied-law aliases; book '+r'$D_k$'+' remains\na realized weak wrong-count.',11.5)
        text(ax,16,631,'Zero-denominator and varying-report qualifications follow in the text.',11.8,False,'muted')
    else:
        text(ax,16,12,'Counts, laws and denominators',17,True)
        text(ax,16,44,'Fix report g and information y.\nWeights are nonnegative and sum to one.\nν = s (supplied) or P (evaluation).',12.5)
        panel(ax,16,111,328,98)
        text(ax,25,120,r'$M=\binom{n}{2}>0,\quad x_{ij}=\mathbf{1}\{g_i<g_j\}$',13.5)
        text(ax,25,145,r'$N(g)=\sum_{i\ne j}x_{ij}$',13.5)
        text(ax,25,188,'Raw disclosure N/M is fixed by g.',12)
        for key,title,y,h in [('weak','Weak error (≤)',223,190),('strict','Strict reversal (<)',425,210),('distinct','Distinct opportunity (≠)',647,190)]:
            panel(ax,16,y,328,h,'white');text(ax,26,y+10,title,14,True)
            prefix=r'$D_k(g,\Theta)=$' if key=='weak' else ''
            if prefix:text(ax,26,y+35,prefix,13)
            py=y+(58 if key=='weak' else 39);text(ax,26,py,PRED[key],14)
            ey=py+43;text(ax,26,ey,'Average under ν at fixed y:',12)
            if key=='weak':
                text(ax,26,ey+23,r'$E_k^\nu(g)=\mathbb{E}_\nu[D_k\mid y]$',14)
                text(ax,26,ey+49,r'$E_k^\nu(g)/N(g),\quad N(g)>0$',14)
            elif key=='strict':
                text(ax,26,ey+23,r'$E_k^{b,\nu}(g)$'+'  expected strict-error count',12.5)
                text(ax,26,ey+49,r'$E_k^{b,\nu}(g)/N(g),\quad N(g)>0$',14)
                text(ax,26,ey+76,r'$E_k^{b,\nu}(g)/Q_k^\nu(g),\quad Q_k^\nu(g)>0$',14)
            else:
                text(ax,26,ey+23,r'$Q_k^\nu(g)$'+'  expected distinct mass',13)
                text(ax,26,ey+49,r'$Q_w^\nu(g)/T_w^\nu,\quad T_w^\nu>0$',14)
        panel(ax,16,849,328,174)
        text(ax,26,859,'Weighting and total opportunity',14,True)
        text(ax,26,886,r'$Q_w^\nu(g)=\sum_k w_kQ_k^\nu(g)$',14)
        text(ax,26,927,r'$T_w^\nu=\sum_{i<j}\sum_k w_kd_{ij,k}^\nu$',14)
        text(ax,26,971,r'$d_{ij,k}^\nu=\Pr_\nu(\theta_{ik}\ne\theta_{jk}\mid y)$',13.5)
        text(ax,26,1000,'T: all original pairs; Q: disclosed directions.',11.5)
        panel(ax,16,1037,328,114,'white')
        text(ax,26,1048,'Inspected tie_aware_v1 field names',13.2,True)
        text(ax,26,1073,'API D ↔ '+r'$Q_w^s(g)$'+'; API T ↔ '+r'$T_w^s$',14)
        text(ax,26,1102,'Supplied-law aliases; book '+r'$D_k$'+' remains\na realized weak wrong-count.',12.5)
        text(ax,16,1167,'Zero-denominator and varying-report\nqualifications follow in the text.',12.5,False,'muted')
    return fig


def wrap(s,n):return textwrap.fill(s.replace('\n',' '),n)


def fc(mobile=False):
    fig,ax=canvas(360 if mobile else 640,950 if mobile else 490)
    text(ax,16,12,'What each evidence type supports' if not mobile else 'What each evidence\ntype supports',18 if not mobile else 17,True)
    text(ax,16,43 if not mobile else 60,'Discovery locates sources; inspected primary passages\nsupport substantive attribution.' if not mobile else 'Discovery locates sources. Inspected primary\npassages support substantive attribution.',12.5)
    if not mobile:
        for x,s in [(24,'Evidence'),(162,'Supports'),(402,'Does not establish')]:text(ax,x,87,s,13,True)
        for i,(name,support,limit) in enumerate(LANES):
            y=111+i*62;panel(ax,16,y,608,61,'light' if i%2==0 else 'white')
            text(ax,24,y+14,name,12.5,True)
            text(ax,162,y+9,wrap(support,30),12.3)
            text(ax,402,y+9,wrap(limit,29),12.3)
        text(ax,16,438,'Keep editions, assumptions, pinned inputs and actual execution dates attached.\nNo lane establishes unperformed empirical work.',12.2,False,'muted')
    else:
        for i,(name,support,limit) in enumerate(LANES):
            y=115+i*151;panel(ax,16,y,328,145,'light' if i%2==0 else 'white')
            text(ax,26,y+9,name.replace('\n',' '),14,True)
            text(ax,26,y+34,'Supports: '+wrap(support,39),12.7)
            text(ax,26,y+88,'Does not establish:\n'+wrap(limit,40),12.7)
        text(ax,16,885,'Keep editions, assumptions, pinned inputs\nand actual execution dates attached.\nNo lane establishes unperformed empirical work.',12,False,'muted')
    return fig


def f08_figures():
    """Compile only the existing draw definition; capture instead of exporting."""
    spec=importlib.util.spec_from_file_location('source_figstyle',ROOT/'assets/reproduction/figures/figstyle.py')
    fs=importlib.util.module_from_spec(spec);spec.loader.exec_module(fs)
    captured=[]
    fs.export=lambda fig,stem,mobile:captured.append(fig) or []
    tree=ast.parse((SOURCE/'F08/generate.py').read_text())
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='draw']
    ns={'fs':fs,'CARDS':literals('F08',{'CARDS'})['CARDS'],'STEM':'never-export-source'}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'frozen F08 draw definition','exec'),ns)
    out=[]
    for mobile in [False,True]:
        ns['draw'](mobile);fig=captured[-1];texts=[t for ax in fig.axes for t in ax.texts]+list(fig.texts)
        before=[t.get_text() for t in texts];changed=0
        for t in texts:
            if t.get_text()=='P1 displayed error rate':t.set_text('Reported error rate');changed+=1
        assert changed==1
        assert [t.get_text() for t in texts]==[s.replace('P1 displayed error rate','Reported error rate') for s in before]
        out.append((mobile,fig))
    return out


def main():
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    inputs=[SOURCE/tag/'generate.py' for tag in ['FB','FC','F08']]
    inputs+=[ROOT/'assets/reproduction/figures/figstyle.py',ROOT/'scripts/figures/style_v4.py']
    inputs+=[ROOT/'assets/figures'/name for name in [
        'fb-counts-laws-denominators-and-the-api-crosswalk.svg',
        'fc-what-each-evidence-type-supports.svg',
        'f08-the-denominator-and-law-determine-the-guarantee.svg']]
    pins=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in inputs]
    outputs=[];checks=[]
    for stem,func in [('reader-fb-counts-laws',fb),('reader-fc-evidence-types',fc)]:
        for mobile in [False,True]:
            fig=func(mobile);g=geometry(fig);checks.append({'id':stem,'mobile':mobile,**g})
            outputs+=style.export(fig,stem,mobile=mobile,title=stem,alt='Reader layout derivative; original scientific conditions retained, with mapped FB qualifications in adjoining prose.')
    for mobile,fig in f08_figures():
        checks.append({'id':'reader-f08-error-rate','mobile':mobile,**geometry(fig),'only_text_change':['P1 displayed error rate','Reported error rate']})
        outputs+=style.export(fig,'reader-f08-error-rate',mobile=mobile,title='Denominator and averaging law',alt='Original law diagram with Reported error rate reader label.')
    assert all(sha(ROOT/x['path'])==x['sha256'] for x in pins)
    proposed=r'''For a fixed report, zero denominators remain undefined. If $N=0$, all disclosed counts are zero, rates with denominator $N$ are undefined, and raw disclosure is $N/M=0$; $Q_w^\nu/T_w^\nu=0$ only when $T_w^\nu>0$. If $Q_k^\nu=0$, the ratio $E_k^{b,\nu}/Q_k^\nu$ is undefined and no conditional-distinct accuracy is assigned. If $T_w^\nu=0$, the ratio $Q_w^\nu/T_w^\nu$ is undefined, while equality-neutral risk and $R_0^\nu$ are zero. Raw $N$ can nevertheless be positive outside a guarded family.

When reports or datasets vary, let $A=\sum_k w_kD_k$. The summaries $\mathbb{E}[A]/\mathbb{E}[N]$ and $\mathbb{E}[A/N\mid N>0]$ generally differ. Their interpretation requires the averaging law and a positive denominator to be named. Quantities of different types can have equal numerical values.'''
    rec={'step':'11.142','generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Static reader derivatives only; no source/canonical/style mutation or statistical execution.','producer':{'path':str(Path(__file__).relative_to(ROOT)),'sha256':sha(Path(__file__))},'inputs':pins,'outputs':outputs,'geometry_checks':checks,'source_reads':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p),'line_range':[1,len(p.read_text().splitlines())],'byte_range':[0,p.stat().st_size]} for p in inputs[:3]],'source_to_destination':[
        {'source':'FB raw frame, three event rows, weighting/total opportunity and API aliases','destination':'reader-fb-counts-laws normal/mobile; all formulas, named laws, rate-positive-denominator conditions and guard-independent API naming retained'},
        {'source':'FB N=0, Q_k=0 and T_w=0 cards; varying reports/datasets paragraph','destination':'Exact proposed appendix prose below; must be inserted adjacent to the new figure before integration approval','omission_from_book_authorized':False},
        {'source':'FC LANES, discovery statement and footer','destination':'reader-fc-evidence-types normal/mobile; same five complete supports/limits, rewrapped'},
        {'source':'F08 draw definition','destination':'reader-f08-error-rate normal/mobile; same layout and scientific labels except one reader-only title correction'}],
        'proposed_adjacent_prose':{'chapter':'appendices/B-notation.qmd','placement':'Immediately after the FB figure/caption; root integrates, author does not edit canonical.','qmd':proposed},
        'f08_exact_edit':{'old':'P1 displayed error rate','new':'Reported error rate','count_each_layout':1},
        'original_inputs_unchanged':True,'visual_review':'pending actual PNG views','browser_observation':False,'independent_review':'Pending root Step11.143'}
    p=ROOT/'evidence/editorial/figure-sizing/compact-fb-fc.json';p.write_text(json.dumps(rec,indent=2)+'\n')
    print(json.dumps({'receipt':str(p.relative_to(ROOT)),'exports':len(outputs),'geometry':checks}))


if __name__=='__main__':main()
