"""Readable F19b derivatives from accepted saved fields; plotting only."""
from fractions import Fraction as Q
import hashlib,json
import style_v4 as fs
from matplotlib.lines import Line2D
from matplotlib.ticker import PercentFormatter

FID='v4-f19b-objective-contrast'
DATA=fs.ROOT/'assets/reproduction/figures/data/f19b-objective-contrast.json'
SOURCE=fs.ROOT/'assets/figures/objective-contrast.svg'
PIN='5cb224934e9fe4d19d3bbc7451969402b34dcd332af979c49bb3e992f8375894'
DATA_PIN='5d1bca203a6da4ecb32e05aa15313b4e29d8ecd8b93e70c6180f75b594aba1ae'
ALT='Two panels contrast reporting and selecting one unit under one three-unit exact synthetic law. The unrestricted report hull lies below the mean-order hull. Expected selected targets for A, B, C are 6, 4, 3 and best-unit probabilities 30%, 70%, 0%; a separate uniform A-B selection lottery gives 5 and 50%. A reported tie does not itself allocate.'

def draw(d,mobile=False):
    height=1400 if mobile else 1320;width=360 if mobile else 720
    fig=fs.canvas(height/72,mobile=mobile);c=fs.COLORS
    body=14 if mobile else 18;head=16 if mobile else 22
    def text(x,y,s,**kw):
        kw.setdefault('fontsize',body)
        return fig.text(x/width,1-y/height,s,ha='left',va='top',linespacing=1.25,**kw)
    def axes(top,bottom):
        left=84 if mobile else 115;right=338 if mobile else 682
        ax=fig.add_axes([left/width,1-bottom/height,(right-left)/width,(bottom-top)/height]);fs.clean(ax,'y');ax.tick_params(labelsize=13 if mobile else 16);return ax
    def key(y,label,color,style):
        fig.add_artist(Line2D([24/width,62/width],[1-(y+8)/height]*2,transform=fig.transFigure,color=color,linestyle=style,marker='o',markersize=4,linewidth=2))
        text(72,y,label)
    text(24,23,'Three units, two objective contrasts' if not mobile else 'Three units,\ntwo objective contrasts',fontsize=head,fontweight='bold')
    text(24,82 if mobile else 70,'One exact synthetic law; larger targets\nhave higher priority. No causal effect\nor empirical policy benefit is shown.' if mobile else 'One exact synthetic law; larger targets have higher priority.\nNo causal effect or empirical policy benefit is shown.')
    text(24,180 if mobile else 155,'A. Reporting under one conditional law' if not mobile else 'A. Reporting under\none conditional law',fontsize=head,fontweight='bold')
    ax=axes(240 if mobile else 210,525 if mobile else 495)
    for name,col,style in [('unrestricted','teal','-'),('mean_order_ABC','ochre','--')]:
        h=d['families'][name]['hull'];ax.plot([p[0] for p in h],[float(Q(p[1])) for p in h],color=c[col],linestyle=style,marker='o',markersize=5,linewidth=2)
    s=d['panel_specs']['reporting'];ax.set(xlim=(-.06,3.06),ylim=(0,1.5),xticks=s['x_ticks'],yticks=[float(Q(v)) for v in s['y_ticks']])
    ax.set_xlabel('Expected number of\ndisclosed pairs' if mobile else 'Expected number of disclosed pairs',fontsize=14 if mobile else 18,labelpad=10)
    ax.set_ylabel('Expected wrong count',fontsize=14 if mobile else 18,labelpad=10)
    key(610 if mobile else 565,'All coherent reports',c['teal'],'-')
    key(642 if mobile else 600,'Mean-order reports',c['ochre'],'--')
    text(24,680 if mobile else 645,'Segments mix whole reports.\nN = 1 is not a deterministic report.')
    text(24,755 if mobile else 735,'B. A budget of one: different objectives' if not mobile else 'B. A budget of one:\ndifferent objectives',fontsize=head,fontweight='bold')
    bx=axes(825 if mobile else 800,1105 if mobile else 1080)
    for r in d['allocation_singletons']:
        x=float(Q(r['expected_selected_value']));y=float(Q(r['probability_select_best']))
        bx.scatter([x],[y],s=65,color=c['teal'],edgecolor=c['ink'],lw=.7,zorder=3)
        bx.annotate(r['unit'],(x,y),xytext=(0,9),textcoords='offset points',ha='center',va='bottom',fontsize=14 if mobile else 18,fontweight='bold')
    r=d['added_AB_lottery'];x=float(Q(r['expected_selected_value']));y=float(Q(r['probability_select_best']))
    bx.scatter([x],[y],marker='D',s=65,color=c['gray'],edgecolor=c['ink'],lw=.7,zorder=3)
    bx.annotate('A-B lottery',(x,y),xytext=(0,9),textcoords='offset points',ha='center',va='bottom',fontsize=14 if mobile else 18,fontweight='bold')
    s=d['panel_specs']['allocation'];bx.set(xlim=tuple(float(Q(v)) for v in s['x_limits']),ylim=tuple(float(Q(v)) for v in s['y_limits']),xticks=s['x_ticks'],yticks=[float(Q(v)) for v in s['y_ticks']]);bx.yaxis.set_major_formatter(PercentFormatter(1,decimals=0))
    bx.set_xlabel('Expected selected target value',fontsize=13 if mobile else 18,labelpad=10)
    bx.set_ylabel('Probability of selecting the best',fontsize=13 if mobile else 18,labelpad=10)
    text(24,1180 if mobile else 1155,'Circles select one named unit.\nThe diamond adds an independent, uniform\nA-B selection lottery to report 112.\nA reported tie does not select a unit.' if mobile else 'Circles select one named unit. The diamond adds an\nindependent, uniform A-B selection lottery to report 112.\nA reported tie does not select a unit.')
    text(24,1290 if mobile else 1255,'Reporting and allocation use different objectives.\nNo fitted model, simulation or solver is shown.' if not mobile else 'Reporting and allocation use\ndifferent objectives. No fitted model,\nsimulation or solver is shown.',color=c['muted'],fontsize=13 if mobile else 17)
    return fig

if __name__=='__main__':
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==PIN
    assert hashlib.sha256(DATA.read_bytes()).hexdigest()==DATA_PIN
    d=json.loads(DATA.read_text());assert (d['n'],d['K'],d['M'])==(3,2,3)
    assert [r['expected_selected_value'] for r in d['allocation_singletons']]==['6','4','3']
    assert [r['probability_select_best'] for r in d['allocation_singletons']]==['3/10','7/10','0']
    assert d['added_AB_lottery']['expected_selected_value']=='5'
    assert d['added_AB_lottery']['probability_select_best']=='1/2'
    outputs=[]
    for mobile in (False,True):outputs+=fs.export(draw(d,mobile),FID,mobile=mobile,title='Three units, two objective contrasts',alt=ALT)
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==PIN
    fs.record(FID,outputs,['assets/reproduction/figures/data/f19b-objective-contrast.json','assets/reproduction/figures/generators/F19b-mobile/generate.py','assets/figures/objective-contrast.svg','scripts/figures/F19b_v4.py','scripts/figures/style_v4.py'],
              ['Step9.54. Separate derivatives; retained normal/mobile originals unchanged.',
               'All6hull vertices and4allocation coordinates read directly from accepted saved rational fields. No13-report enumeration, hull construction, solver, fit or simulation.',
               'Reporting segments mix complete reports; budget-one allocation is a separate action. Percentage axis represents probabilities, not sampling-calibration claims.'])
