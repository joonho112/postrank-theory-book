"""Compact F14b/F15a reader figures from saved tables; no DP or solver execution."""
from pathlib import Path
from fractions import Fraction as Q
import importlib.util,json,hashlib
from matplotlib.patches import Rectangle,FancyArrowPatch

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('reader_compact',Path(__file__).with_name('reader-compact.py'))
rc=importlib.util.module_from_spec(spec);spec.loader.exec_module(rc)
C=rc.C
def surface(w,h):
 fig=rc.canvas(w,h);ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,w),ylim=(h,0));ax.axis('off');return fig,ax
def txt(ax,x,y,label,size=12.5,ha='left',**kw):return ax.text(x,y,label,fontsize=size,ha=ha,va='center',linespacing=1.22,**kw)
def cell(ax,x,y,w,h,value,selected=False,invalid=False):
 v=Q(value)if value is not None else None
 face=C['light']if v is not None and v>0 else'#FBF4F1'if v is not None and v<0 else'white'
 patch=Rectangle((x,y),w,h,facecolor=face,edgecolor=C['teal']if selected else C['line'],lw=2 if selected else .7,hatch='///'if invalid else None)
 ax.add_patch(patch)
 label='—'if invalid else r'$-\infty$'if value is None else('+'if v>0 else'')+str(v).replace('-','−')
 t=txt(ax,x+w/2,y+h/2,label,12.5,ha='center',fontweight='bold'if selected else'normal',color=C['muted']if invalid or v is None else C['rust']if v<0 else C['ink'])
 return patch,t
def verify_cells(fig,objects):
 fig.canvas.draw();ren=fig.canvas.get_renderer()
 for patch,t in objects:
  box=patch.get_window_extent(ren);b=t.get_window_extent(ren)
  assert b.x0>=box.x0+1 and b.x1<=box.x1-1 and b.y0>=box.y0+1 and b.y1<=box.y1-1,('cell clipping',t.get_text())
def matrix(ax,data,x,y,w,h,kind):
 rows,cols=(4,4)if kind=='W'else(5,5);objects=[];mapping=[]
 values={(r['a']-1,r['b']):r['W']for r in data['block_savings']}if kind=='W'else{(r['h'],r['r']):r['maximum_saving']for r in data['dp_states']}
 selected={(0,1),(1,3),(3,4)}if kind=='W'else{(0,0),(1,1),(2,3),(3,4)}
 for row in range(rows):
  for col in range(cols):
   key=(row,col+1)if kind=='W'else(row,col);invalid=kind=='W'and key not in values
   objects.append(cell(ax,x+col*w/cols,y+row*h/rows,w/cols,h/rows,values.get(key),key in selected,invalid))
   mapping.append({'index':list(key),'value':values.get(key),'invalid_interval':invalid,'selected':key in selected})
 for j in range(cols):txt(ax,x+(j+.5)*w/cols,y+h+14,str(j+1 if kind=='W'else j),12,ha='center')
 for i in range(rows):txt(ax,x-12,y+(i+.5)*h/rows,str(i),12,ha='right')
 txt(ax,x+w/2,y+h+37,r'Right cut boundary $b$'if kind=='W'else r'Prefix length $c$',12.5,ha='center')
 txt(ax,x-38,y+h/2,r'Left cut boundary $a$'if kind=='W'else r'Nonempty blocks $h$',12.5,ha='center',rotation=90)
 return objects,mapping
def recovery(ax,x,y,w):
 # Saved backtracking path: positions, not time or a continuous report path.
 cuts=[0,1,3,4];positions=[x+w*c/4 for c in cuts]
 for i,(cut,px)in enumerate(zip(cuts,positions)):
  ax.add_patch(Rectangle((px-10,y-10),20,20,facecolor='white',edgecolor=C['teal'],lw=1))
  txt(ax,px,y,str(cut),12.5,ha='center')
  if i:ax.add_patch(FancyArrowPatch((positions[i-1]+11,y),(px-11,y),arrowstyle='-|>',mutation_scale=11,color=C['muted'],lw=1))
 for grade,(l,r,units)in enumerate(zip(positions,positions[1:],['A','B  C','D']),1):
  ax.add_patch(Rectangle((l,y+28),r-l,24,facecolor=C['light'],edgecolor=C['teal'],lw=1));txt(ax,(l+r)/2,y+40,units,12.5,ha='center',fontweight='bold');txt(ax,(l+r)/2,y+64,'Grade '+str(grade),12,ha='center')
def guard(ax,x,y,w,mobile):
 txt(ax,x,y,'D. Guarded neutral extension',13,fontweight='bold')
 left,right=x+23,x+w-23;bar=y+43
 ax.plot([left,right],[bar,bar],color=C['line'],lw=1.8)
 ax.scatter([left,right],[bar,bar],s=70,facecolor='white',edgecolor=C['ink'],zorder=3)
 txt(ax,left,bar-15,'first H',12,ha='center');txt(ax,right,bar-15,'last H',12,ha='center')
 ax.plot([x+w/2-5,x+w/2+5],[bar-5,bar+5],color=C['rust'],lw=1.8);ax.plot([x+w/2-5,x+w/2+5],[bar+5,bar-5],color=C['rust'],lw=1.8)
 txt(ax,x+w/2,bar+20,r'No cut: firstpos$(H)\leq t<$lastpos$(H)$',11.8,ha='center',color=C['rust'])
 note=('Full active-profile equality class H\nstays in one grade. Neutral loss/baseline;\noriginal units and pair multiplicities.\nSymbolic: not this tie-free example;\nno package DP support is asserted.')
 txt(ax,x,bar+70,note,12)
def f14b(mobile):
 d=json.loads((ROOT/'assets/reproduction/figures/data/fixed-order-dp.json').read_text());assert d['units_and_fixed_order']==list('ABCD')and len(d['block_savings'])==10 and len(d['dp_states'])==25
 assert d['full_disclosure_risk']=='7/40'and d['exact_and_capped_optima'][-1]['at_most_minimum_risk']=='3/20'
 w,h=(360,1160)if mobile else(690,570);fig,ax=surface(w,h)
 txt(ax,18,29,'A dynamic program chooses\ngrade boundaries'if mobile else'A dynamic program chooses grade boundaries',16.5,fontweight='bold')
 txt(ax,18,77 if mobile else 58,'Fixed order A, B, C, D.\nw = (3/5, 2/5), τ = 1/4; M = 6.'if mobile else'Fixed order A, B, C, D; w = (3/5, 2/5), τ = 1/4; M = 6.',12.5)
 coords=[(75,142,244,176),(75,444,244,185)]if mobile else[(65,112,222,169),(416,112,244,169)]
 titles=[(18,116),(18,418)]if mobile else[(42,89),(382,89)]
 objects=[];mappings={}
 for kind,pos,(x,y),label in zip(['W','V'],coords,titles,[r'A. Signed savings $W(a,b)$',r'B. Prefix savings $V_h(c)$']):
  txt(ax,x,y,label,13,fontweight='bold');ob,ma=matrix(ax,d,*pos,kind);objects+=ob;mappings[kind]=ma
 if mobile:
  txt(ax,18,382,'W covers positions a+1 through b;\nsigned savings may be negative.',12.5)
  txt(ax,18,688,'−∞ is infeasible; V₀(0)=0 is auxiliary.\nOutlines select the three-block solution.',12.5)
  txt(ax,180,730,r'$V_h(c)=\max_b\{V_{h-1}(b)+W(b,c)\}$',14,ha='center')
  txt(ax,180,755,r'$h-1\leq b<c$; unnormalized maximum saving.',12.5,ha='center')
  txt(ax,18,789,'C. Recover the three-block report',13,fontweight='bold');recovery(ax,38,820,280)
  txt(ax,18,912,'g = (1,2,2,3); N = 5. Saving = 3/20.\nRisk reduction = 1/40; R = 7/40 − (3/20)/6 = 3/20.',11.8)
  txt(ax,18,955,'Exactly 4: risk 7/40. At most 4: risk 3/20.',12.5)
  guard(ax,18,997,320,True)
 else:
  txt(ax,45,342,'W covers positions a+1 through b;\nsigned savings may be negative.',12)
  txt(ax,385,342,'−∞ is infeasible; V₀(0)=0 is auxiliary.\nOutlines select the three-block solution.',12)
  txt(ax,345,376,r'$V_h(c)=\max_{h-1\leq b<c}\{V_{h-1}(b)+W(b,c)\}$  (unnormalized saving)',13.5,ha='center')
  txt(ax,20,407,'C. Recover the three-block report',13,fontweight='bold');recovery(ax,40,436,272)
  txt(ax,20,521,'g = (1,2,2,3); N = 5. Saving = 3/20.\nRisk reduction 1/40; R = 7/40 − (3/20)/6 = 3/20.',11.8)
  txt(ax,20,554,'Exactly 4: risk 7/40; at most 4: risk 3/20.',12)
  guard(ax,370,407,292,False)
 verify_cells(fig,objects)
 return fig,{'W_cells':mappings['W'],'V_cells':mappings['V'],'cell_text_containment':True,'recurrence_rerun':False,'selected_saved_path':[[0,0],[1,1],[2,3],[3,4]],'recovered_cuts':[0,1,3,4]}

def yesno(ax,x,y,w,h,value):
 p=Rectangle((x-w/2,y-h/2),w,h,facecolor=C['light']if value else'white',edgecolor=C['teal']if value else C['line'],lw=1 if value else .7);ax.add_patch(p)
 t=txt(ax,x,y,'Yes'if value else'No',12.5,ha='center',fontweight='bold'if value else'normal',color=C['teal']if value else C['muted']);return p,t
def f15a(mobile):
 cases=json.loads((ROOT/'assets/reproduction/figures/data/transformations-protections.json').read_text())['coefficient_protection'];assert len(cases)==2
 w,h=(360,900)if mobile else(690,570);fig,ax=surface(w,h)
 txt(ax,18,30,'Approximate feasibility can miss\nthe intended constraint'if mobile else'Approximate feasibility can miss the intended constraint',16 if mobile else 16.5,fontweight='bold')
 txt(ax,18,80 if mobile else 62,'One pair, one criterion; M = 1.\nExact forward error t+1/10; approximate t.',12.5)
 allcells=[];maps=[];counts=[]
 for ci,c in enumerate(cases):
  y=(124+263*ci)if mobile else(111+156*ci)
  txt(ax,w/2,y,'t = '+c['t']+'; q = '+c['q']+'; ε = '+c['epsilon'],13,ha='center',fontweight='bold')
  txt(ax,w/2,y+23,'q − ε = '+c['inner_threshold']+'; q + ε = '+c['outer_threshold'],12.5,ha='center',color=C['rust']if ci==0 else C['ink'])
  if mobile:
   countx=[47,135,215,300];memx=[34,105,169,238,310]
   for x,label in zip(countx,['Report','N',r'$\widehat E$',r'$E$']):txt(ax,x,y+55,label,12.5,ha='center',fontweight='bold')
   for j,row in enumerate(c['actions']):
    for x,v in zip(countx,['Hold'if row['action']=='withhold'else row['action'],row['N'],row['estimated_error'],row['exact_error']]):txt(ax,x,y+79+j*23,str(v),12.5,ha='center')
   for x,label in zip(memx,['Report','Inner','Exact','Nominal','Outer']):txt(ax,x,y+156,label,12,ha='center',fontweight='bold')
   for j,row in enumerate(c['actions']):
    txt(ax,memx[0],y+180+j*23,'Hold'if row['action']=='withhold'else row['action'],12,ha='center')
    for x,kind in zip(memx[1:],['inner','exact','nominal','outer']):allcells.append(yesno(ax,x,y+180+j*23,53,20,row[kind]));maps.append({'t':c['t'],'action':row['action'],'kind':kind,'member':row[kind]})
  else:
   xs=[56,138,203,271,353,440,533,628]
   for x,label in zip(xs,['Report','N',r'$\widehat E$',r'$E$','Inner','Exact','Nominal','Outer']):txt(ax,x,y+54,label,12.5,ha='center',fontweight='bold')
   for j,row in enumerate(c['actions']):
    for x,v in zip(xs[:4],['Hold'if row['action']=='withhold'else row['action'],row['N'],row['estimated_error'],row['exact_error']]):txt(ax,x,y+81+j*23,str(v),12.5,ha='center')
    for x,kind in zip(xs[4:],['inner','exact','nominal','outer']):allcells.append(yesno(ax,x,y+81+j*23,69,20,row[kind]));maps.append({'t':c['t'],'action':row['action'],'kind':kind,'member':row[kind]})
  counts.extend([{'t':c['t'],'action':row['action'],'N':row['N'],'estimated_count':row['estimated_error'],'exact_count':row['exact_error']}for row in c['actions']])
 if mobile:
  definitions=[r'Inner: $\widehat E\leq(q-\varepsilon)N$',r'Exact: $E\leq qN$',r'Nominal: $\widehat E\leq qN$',r'Outer: $\widehat E\leq(q+\varepsilon)N$']
  for i,line in enumerate(definitions):txt(ax,18,650+i*22,line,13)
  txt(ax,18,774,'At t=0, A>B has N=1. Inner 0 ≤ −1/20 fails.\nClipping to zero wrongly admits it;\nexact 1/10 > q=1/20 still fails.',12.5,color=C['rust'])
  txt(ax,18,851,'Hold: N=0, all count rows are 0 ≤ 0;\nits error fraction is undefined. Exact means\nthe intended supplied law; tests are separate.',12.5,color=C['muted'])
 else:
  txt(ax,18,432,r'Inner: $\widehat E\leq(q-\varepsilon)N$     Exact: $E\leq qN$     Nominal: $\widehat E\leq qN$     Outer: $\widehat E\leq(q+\varepsilon)N$',12.5)
  txt(ax,18,477,'At t=0, A>B fails the inner test 0 ≤ −1/20. Clipping to zero wrongly admits it.\nIts exact error 1/10 > q=1/20 still violates the intended protection.',12.5,color=C['rust'])
  txt(ax,18,533,'Hold (N=0): all count rows are 0 ≤ 0; the error fraction is undefined.\nExact refers to the intended supplied law; membership columns are separate tests.',12.5,color=C['muted'])
 assert len(maps)==24 and len(counts)==6;verify_cells(fig,allcells)
 return fig,{'membership_cells':maps,'count_rows':counts,'cell_text_containment':True,'source_membership_booleans_copied_without_recomputation':True}

if __name__=='__main__':
 inputs=['assets/reproduction/figures/data/fixed-order-dp.json','assets/reproduction/figures/data/transformations-protections.json','assets/reproduction/figures/generators/F14b/generate.py','assets/reproduction/figures/generators/F14b-costs/cost_panel.py','assets/reproduction/figures/generators/F15a/generate.py','scripts/figures/reader-compact.py']
 for stem in ['fixed-order-segmentation','f15a-approximate-and-intended-protection-feasibility']:
  for size in ['','-mobile']:
   for ext in ['svg','pdf']:inputs.append('assets/figures/'+stem+size+'.'+ext)
 before=[rc.pin(x)for x in inputs];figures=[]
 for id,fn in [('f14b',f14b),('f15a',f15a)]:
  rec={'id':id}
  for mobile,size in [(False,'normal'),(True,'narrow')]:
   fig,checks=fn(mobile);rec[size]=rc.export(fig,f'reader-{id}-{size}','Compact reader layout preserving all saved table values and scientific conditions.');rec[size]['checks']=checks
  assert rec['normal']['checks']==rec['narrow']['checks'];figures.append(rec)
 assert before==[rc.pin(x)for x in inputs]
 record={'step':'11.146','status':'GENERATED_PENDING_DIRECT_VISUAL_REVIEW','sourcepins':before,'producer':rc.pin('scripts/figures/reader-matrices.py'),'figures':figures,'source_assets_unchanged':True,'browser_observed':False,'scope':'Saved-table and condition transfer with compact static layout; no recurrence, exact membership, solver, model or simulation rerun. Actual PDF rasters at72dpi.'}
 dest=ROOT/'evidence/editorial/figure-sizing/compact-f14b-f15a.json';dest.write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps([{'id':x['id'],'normal':[x['normal']['width'],x['normal']['height']],'narrow':[x['narrow']['width'],x['narrow']['height']]}for x in figures]))
