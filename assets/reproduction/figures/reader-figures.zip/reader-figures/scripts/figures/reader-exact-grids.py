"""Readable exact-result tables from stored grid rows; no optimization or refit."""
from pathlib import Path
from fractions import Fraction
import csv,json,hashlib,subprocess
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'assets/cases/exact/source-support/comparator-frontiers.csv'
OUT=ROOT/'assets/figures';QA=ROOT/'evidence/editorial/figure-sizing/rasters'
METHODS=[('direct_joint','Direct joint'),('equal_bonferroni','Equal Bonferroni'),('bonferroni','Optimized Bonferroni'),('common_grade_joint','Common grades + joint')]
BUDGETS=['0','1/40','1/20','2/25','1/10']
LAWS=[('moderate_coincident','Coincident errors'),('moderate_disjoint','Disjoint errors')]
INK='#20333B';TEAL='#126D76';LINE='#CAD5D7';LIGHT='#EDF3F2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return {'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size}

def draw(obj,mobile,lookup):
 w,h=(360,650) if mobile else (660,510)
 plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'path','svg.hashsalt':'postrank-reader-exact-grid','pdf.fonttype':42,'text.color':INK})
 fig=plt.figure(figsize=(w/72,h/72));ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,w),ylim=(h,0));ax.axis('off')
 def txt(x,y,s,size=13,**kw):return ax.text(x,y,s,fontsize=size,ha=kw.pop('ha','left'),va='top',linespacing=1.2,**kw)
 title='Minimum risk at five joint budgets' if obj=='A' else 'Maximum disclosure at five joint budgets'
 if mobile:title='Minimum risk at\nfive joint budgets' if obj=='A' else 'Maximum disclosure at\nfive joint budgets'
 txt(14 if mobile else 20,14,title,16.5,fontweight='bold')
 if mobile:
  txt(14,64,'n = 4; D = 2; M = 6 per domain.\nw = (1/2, 1/2); τ = (1/10, 1/10).',12)
  starts=[122,350];method_x=14;centres=[147,192,237,282,327];rowheight=38
 else:
  txt(20,44,'n = 4; D = 2; M = 6 per domain; w = (1/2, 1/2); τ = (1/10, 1/10).',12)
  starts=[84,270];method_x=20;centres=[250,335,420,505,590];rowheight=29
 texts=[]
 for (law,label),top in zip(LAWS,starts):
  txt(method_x,top,label,14,fontweight='bold')
  header=top+25
  txt(method_x,header,'Joint budget α',12.5,fontweight='bold')
  for x,b in zip(centres,BUDGETS):txt(x,header,b,12.5,ha='center',fontweight='bold')
  y0=header+27
  for j,(method,name) in enumerate(METHODS):
   y=y0+j*rowheight
   if j%2==0:ax.add_patch(Rectangle((10 if mobile else 15,y-3),w-(20 if mobile else 30),rowheight,facecolor=LIGHT,edgecolor='none',zorder=0))
   if mobile:name={'direct_joint':'Direct joint','equal_bonferroni':'Equal\nBonferroni','bonferroni':'Optimized\nBonferroni','common_grade_joint':'Common grades\n+ joint'}[method]
   txt(method_x,y,name,12 if mobile else 12.5)
   for x,b in zip(centres,BUDGETS):
    row=lookup[(law,obj,method,b)];value=row['optimum_exact']
    txt(x,y+5 if mobile else y,value,12.5 if mobile else 14,ha='center',fontweight='bold' if method=='direct_joint' else 'normal',color=TEAL if method=='direct_joint' else INK)
    texts.append({'law':law,'objective':obj,'method':method,'alpha_exact':b,'value_exact':value,'case_id':row['case_id']})
  ax.plot([10 if mobile else 15,w-(10 if mobile else 15)],[y0+4*rowheight-3]*2,color=LINE,lw=.8)
 if mobile:
  txt(14,580,'Mean limits q = (1/20, 1/20); full-domain\nstrict failures F > 0; inclusive joint cap J ≤ α.',11.5)
  txt(14,614,'Stored exact optima; no interpolated budgets.' if obj=='A' else 'Separate objective B: total domain disclosures.',11.5)
 else:
  txt(20,450,'Mean limits q = (1/20, 1/20); full-domain strict failures F > 0; J ≤ α.',12)
  txt(20,474,'Stored exact risk optima; no lines or interpolated budgets.' if obj=='A' else 'Separate objective B: maximize the unweighted sum of domain disclosures.',12)
 fig.canvas.draw();renderer=fig.canvas.get_renderer();outside=[]
 for t in fig.findobj(matplotlib.text.Text):
  if t.get_visible() and t.get_text().strip():
   b=t.get_window_extent(renderer);f=fig.bbox
   if b.x0<f.x0-1 or b.x1>f.x1+1 or b.y0<f.y0-1 or b.y1>f.y1+1:outside.append(t.get_text())
 assert not outside,outside
 stem='reader-exact-'+('risk' if obj=='A' else 'disclosure')+('-narrow' if mobile else '-normal')
 for ext in ['svg','pdf']:
  meta={'Date':None,'Creator':'JoonHo Lee','Title':title} if ext=='svg' else {'CreationDate':None,'ModDate':None,'Creator':'JoonHo Lee','Title':title}
  fig.savefig(OUT/f'{stem}.{ext}',metadata=meta)
 plt.close(fig);QA.mkdir(parents=True,exist_ok=True)
 subprocess.run(['pdftoppm','-singlefile','-r','72','-png',str(OUT/f'{stem}.pdf'),str(QA/stem)],check=True)
 return {'objective':obj,'mode':'narrow' if mobile else 'normal','width':w,'height':h,'drawn_cells':texts,'exports':[pin(OUT/f'{stem}.{ext}') for ext in ['svg','pdf']]+[pin(QA/f'{stem}.png')],'text_inside_canvas':True}

if __name__=='__main__':
 before=pin(SOURCE)
 with SOURCE.open() as f:allrows=list(csv.DictReader(f))
 rows=[r for r in allrows if r['spec_group']=='baseline_matched' and r['law'] in [x[0] for x in LAWS] and r['objective'] in ['A','B'] and r['method'] in [x[0] for x in METHODS] and r['alpha_exact'] in BUDGETS]
 lookup={(r['law'],r['objective'],r['method'],r['alpha_exact']):r for r in rows}
 assert len(rows)==len(lookup)==80
 for r in rows:
  assert (r['n'],r['D'],r['original_M'],r['weights_exact'],r['tau_exact'],r['mean_q_exact'],r['t_exact'],r['configured_H'])==('4','2','6','1/2|1/2','1/10|1/10','1/20|1/20','0|0','2')
  assert r['family_size']==('75' if r['method']=='common_grade_joint' else '5625')
  assert Fraction(r['optimum_exact'])>=0
 exports=[draw(o,m,lookup) for o in ['A','B'] for m in [False,True]]
 assert pin(SOURCE)==before
 record={'step':'11.152','status':'GENERATED_PENDING_DIRECT_VISUAL_REVIEW','source':before,'source_read':'CSV schema, fixed scientific fields and all80 selected value rows inspected; other source columns retained read-only.','source_unchanged':True,'declared_common_settings':{'n':4,'D':2,'M_each':6,'weights':['1/2','1/2'],'tau':['1/10','1/10'],'q':['1/20','1/20'],'t':['0','0'],'profile_family_size':5625,'common_family_size':75},'figures':exports,'scientific_operation':'Project saved exact optimum strings into complete two-law tables. No new solver, enumeration, fit or interpolation.','actual_browser_observed':False}
 (ROOT/'evidence/editorial/figure-sizing/compact-exact-grids.json').write_text(json.dumps(record,indent=2)+'\n')
 print('Exported four complete saved-grid tables: two objectives × normal/narrow.')
