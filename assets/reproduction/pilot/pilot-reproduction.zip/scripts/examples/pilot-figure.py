#!/usr/bin/env python3
# Author: JoonHo Lee (jlee296@ua.edu)
"""Draw the crossed-law pilot with ReportLab vector primitives.

This is a presentation script, not an independent decision oracle. It reads only
the finite fixture specification. Run with ReportLab and Poppler.
"""
from pathlib import Path
import json
import subprocess

from reportlab import rl_config
from reportlab.graphics.shapes import Drawing, Rect, String, Line
from reportlab.graphics import renderPDF, renderSVG
from reportlab.lib.colors import HexColor, white
from reportlab.pdfgen.canvas import Canvas

BOOK = Path(__file__).resolve().parents[2]
OUT = BOOK / 'assets/figures'
FIGURE_SUBJECT = 'Exact crossed-law example in Chapter 14'
rl_config.invariant = 1

spec = json.loads((BOOK / 'evidence/pilot/fixture-spec.json').read_text())
crossed = next(f for f in spec['fixtures'] if f['id'] == 'crossed')
assert spec['units'] == ['Alder', 'Birch']
assert spec['candidate_columns'] == {'W': [1, 1], 'AB': [1, 2], 'BA': [2, 1]}
assert crossed['mass'] == ['4/5', '1/5']
assert crossed['states'] == [[[1, -1], [0, 0]], [[-1, 1], [0, 0]]]
assert crossed['t'] == ['0', '0'] and crossed['alpha'] == '1/4'
assert spec['tau'] == ['1/3', '1/3'] and spec['weights'] == ['1/2', '1/2']

WIDTH, HEIGHT = 490, 302
ink = HexColor('#202A35')
muted = HexColor('#4B5563')
rule = HexColor('#BCC4CC')
accent = HexColor('#146273')
tint = HexColor('#E9F2F3')
neutral = HexColor('#F5F6F7')
d = Drawing(WIDTH, HEIGHT)
d.add(Rect(0, 0, WIDTH, HEIGHT, fillColor=white, strokeColor=None))

def text(x, y, s, size=10.5, align='start', bold=False, color=ink):
    d.add(String(x, y, s, fontName='Helvetica-Bold' if bold else 'Helvetica',
                 fontSize=size, textAnchor=align, fillColor=color))

def line(x1, y1, x2, y2, color=rule, width=0.6):
    d.add(Line(x1, y1, x2, y2, strokeColor=color, strokeWidth=width))

text(WIDTH/2, 285, 'Same joint law for both reporting formats', 11, 'middle', True)
text(WIDTH/2, 268, 'Probability 4/5: Alder leads in Domain 1; Birch leads in Domain 2.', 10, 'middle')
text(WIDTH/2, 253, 'Probability 1/5: both directions reverse.', 10, 'middle')
line(12, 242, WIDTH-12, 242)

PANELS = [
    dict(x=12, name='(a) Best common card', subtitle='Identical columns: W / W',
         grades=[[1, 1], [1, 1]], description=['Both comparisons withheld', 'Same grade does not assert equality'],
         risk='1/3', joint='0'),
    dict(x=258, name='(b) Best profile card', subtitle='Crossed columns: AB / BA',
         grades=[[1, 2], [2, 1]], description=['Domain 1: Alder leads', 'Domain 2: Birch leads'],
         risk='1/5', joint='1/5'),
]
for p in PANELS:
    x, pw = p['x'], 220
    text(x+pw/2, 222, p['name'], 12, 'middle', True)
    text(x+pw/2, 205, p['subtitle'], 10, 'middle', color=muted)
    table_y, row_h = 112, 25
    # Unit names are outside the two domain columns; colors supplement numbers.
    text(x+10, table_y+2*row_h+10, 'Unit', 10, bold=True)
    colx = [x+120, x+183]
    for j, label in enumerate(['Domain 1', 'Domain 2']):
        text(colx[j], table_y+2*row_h+10, label, 10, 'middle', True)
    line(x+6, table_y+2*row_h+3, x+pw-4, table_y+2*row_h+3)
    for i, unit in enumerate(spec['units']):
        cy = table_y+(1-i)*row_h+row_h/2
        text(x+10, cy-3.6, unit, 11)
        for j, grade in enumerate(p['grades'][i]):
            d.add(Rect(colx[j]-25, cy-11, 50, 22,
                       fillColor=tint if grade == 1 else neutral, strokeColor=None))
            text(colx[j], cy-4, str(grade), 12, 'middle', True)
    for k, desc in enumerate(p['description']):
        text(x+pw/2, 97-k*14, desc, 9.8, 'middle', color=muted)
    line(x+6, 73, x+pw-4, 73)
    text(x+pw/2, 55, 'Risk = '+p['risk']+'     Joint error J = '+p['joint'], 11, 'middle', True,
         color=accent if p['joint']!='0' else ink)

line(245, 47, 245, 230, HexColor('#D5DADE'), 0.6)
text(WIDTH/2, 31, 'Smaller grade = higher reported priority.', 10, 'middle')
text(WIDTH/2, 14, 'Cap = 1/4; threshold t = 0; withholding cost = 1/3; domain weights = 1/2, 1/2.', 9.2, 'middle', color=muted)

OUT.mkdir(exist_ok=True)
svg = OUT / 'v4-pilot.svg'
pdf = OUT / 'v4-pilot.pdf'
renderSVG.drawToFile(d, str(svg), title='Common and profile cards under a fixed crossed law')
canvas = Canvas(str(pdf), pagesize=(WIDTH, HEIGHT), invariant=1)
canvas.setAuthor('JoonHo Lee (jlee296@ua.edu)')
canvas.setCreator('JoonHo Lee (jlee296@ua.edu)')
canvas.setTitle('Common and profile cards under a fixed crossed law')
canvas.setSubject(FIGURE_SUBJECT)
renderPDF.draw(d, canvas, 0, 0)
canvas.showPage()
canvas.save()
subprocess.run(['pdftoppm', '-singlefile', '-r', '180', '-png', str(pdf), str(OUT/'v4-pilot')], check=True)
print('Created SVG, PDF, and PDF-rendered PNG:', OUT / 'v4-pilot')
