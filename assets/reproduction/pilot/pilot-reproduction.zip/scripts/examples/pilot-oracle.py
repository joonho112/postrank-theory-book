#!/usr/bin/env python3
# Author: JoonHo Lee (jlee296@ua.edu)
"""Exact finite pilot oracle; reads only the finite-law fixture.

No R code, R output, package implementation, or previous numerical result is
an input. The nine cards exhaust two-unit ordered partitions in two domains.
"""
from __future__ import annotations

import csv
import hashlib
import itertools
import json
from datetime import datetime, timezone
from fractions import Fraction as Q
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SPEC = ROOT / "evidence/pilot/fixture-spec.json"
OUT = ROOT / "results/pilot"
FIELDS = ["fixture", "column1", "column2", "risk_exact", "J_exact",
          "feasible", "optimal_full", "optimal_common", "common"]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def counts(column, domain_state):
    """Count issued and false directions, including equality as false."""
    issued = false = 0
    for i, j in itertools.combinations(range(len(column)), 2):
        if column[i] == column[j]:
            continue
        high, low = (i, j) if column[i] < column[j] else (j, i)
        issued += 1
        false += int(domain_state[high] <= domain_state[low])
    return issued, false


def evaluate(fixture, card, columns, weights, tau):
    n = len(next(iter(columns.values())))
    m = Q(n * (n - 1), 2)
    risk = joint = Q(0)
    state_records = []
    for mass_text, state in zip(fixture["mass"], fixture["states"]):
        mass = Q(mass_text)
        domain_counts = [counts(columns[label], [row[d] for row in state])
                         for d, label in enumerate(card)]
        loss = sum((weights[d] * (false + tau[d] * (m - issued)) / m
                    for d, (issued, false) in enumerate(domain_counts)), Q(0))
        events = [false > Q(fixture["t"][d]) * issued
                  for d, (issued, false) in enumerate(domain_counts)]
        # Evaluate the union once per complete state. N=0 implies F=0.
        risk += mass * loss
        joint += mass * int(any(events))
        state_records.append({"mass": mass, "counts": domain_counts,
                              "loss": loss, "events": events})
    return {"risk": risk, "J": joint,
            "feasible": joint <= Q(fixture["alpha"]),
            "common": card[0] == card[1], "states": state_records}


def solve(evaluations, common=False):
    feasible = {card: v for card, v in evaluations.items()
                if v["feasible"] and (not common or v["common"])}
    minimum = min(v["risk"] for v in feasible.values())
    optima = {card for card, v in feasible.items() if v["risk"] == minimum}
    return minimum, optima


def main():
    started = datetime.now(timezone.utc).isoformat()
    spec = json.loads(SPEC.read_text())
    columns = spec["candidate_columns"]
    assert len(spec["units"]) == len(spec["domains"]) == 2
    assert columns == {"W": [1, 1], "AB": [1, 2], "BA": [2, 1]}
    assert spec["mean_constraints"] is None
    weights, tau = [Q(x) for x in spec["weights"]], [Q(x) for x in spec["tau"]]
    assert sum(weights) == 1 and all(w >= 0 for w in weights)
    assert all(0 < t <= Q(1, 2) for t in tau)
    fixtures = {f["id"]: f for f in spec["fixtures"]}
    for variant in spec["boundary_variants"]:
        fixtures[variant["id"]] = {**fixtures[variant["base"]], **variant}
    cards = list(itertools.product(columns, repeat=2))
    checks = []

    def check(name, condition, detail):
        checks.append({"name": name, "pass": bool(condition), "detail": detail})
        assert condition, name

    all_values, summaries, rows = {}, {}, []
    for name, fixture in fixtures.items():
        assert len(fixture["mass"]) == len(fixture["states"])
        assert sum(Q(x) for x in fixture["mass"]) == 1
        assert all(Q(x) >= 0 for x in fixture["mass"])
        assert all(0 <= Q(t) <= 1 for t in fixture["t"])
        assert 0 <= Q(fixture["alpha"]) <= 1
        assert all(len(state) == 2 and all(len(row) == 2 for row in state)
                   for state in fixture["states"])
        values = {card: evaluate(fixture, card, columns, weights, tau) for card in cards}
        all_values[name] = values
        full_min, full = solve(values)
        common_min, common = solve(values, common=True)
        summaries[name] = {
            "minimum_full": str(full_min), "optimal_full": [list(c) for c in sorted(full)],
            "minimum_common": str(common_min), "optimal_common": [list(c) for c in sorted(common)],
            "feasible_profiles": sum(v["feasible"] for v in values.values()),
            "feasible_common": sum(v["feasible"] and v["common"] for v in values.values()),
        }
        for card, v in values.items():
            rows.append({"fixture": name, "column1": card[0], "column2": card[1],
                         "risk_exact": str(v["risk"]), "J_exact": str(v["J"]),
                         "feasible": v["feasible"], "optimal_full": card in full,
                         "optimal_common": card in common, "common": v["common"]})
            # Separate additive computation from domain marginal error rates.
            marginal_risk = Q(0)
            for d, label in enumerate(card):
                col = columns[label]
                issued = int(col[0] != col[1])
                if issued:
                    high, low = (0, 1) if col[0] < col[1] else (1, 0)
                    error = sum((Q(p) for p, state in zip(fixture["mass"], fixture["states"])
                                 if state[high][d] <= state[low][d]), Q(0))
                else:
                    error = Q(0)
                marginal_risk += weights[d] * (error + tau[d] * (1 - issued))
            assert marginal_risk == v["risk"]
            if v["common"]:
                for sr in v["states"]:
                    ns = [n for n, f in sr["counts"]]
                    assert ns[0] == ns[1]
                    assert sr["loss"] == sum(weights[d] * sr["counts"][d][1]
                                              for d in range(2)) + sum(weights[d] * tau[d]
                                              for d in range(2)) * (1 - ns[0])

    check("complete-enumeration", len(rows) == 63 and len(fixtures) == 7 and len(cards) == 9,
          "Seven fixed fixtures, all nine profiles each, including each diagonal card.")
    check("additive-risk-and-diagonal-state-identity", True,
          "Every risk agrees with marginal error computation; every diagonal state loss agrees with matched common-column identity.")
    check("N-zero-event-false", all(v[("W", "W")]["J"] == 0 and
          v[("W", "W")]["risk"] == Q(1, 3) and v[("W", "W")]["feasible"] and
          all(not any(sr["events"]) for sr in v[("W", "W")]["states"])
          for v in all_values.values()), "N=F=0 gives a false event; F/N is undefined (display NA), while withholding loss remains 1/3.")
    expected = {
        "crossed": (Q(1, 5), {("AB", "BA")}, Q(1, 3), {("W", "W")}),
        "aligned": (Q(1, 5), {("AB", "AB")}, Q(1, 5), {("AB", "AB")}),
        "independent": (Q(13, 60), {("AB", "W"), ("W", "AB")}, Q(1, 3), {("W", "W")}),
        "equality": (Q(1, 3), {("W", "W")}, Q(1, 3), {("W", "W")}),
        "cap_equal": (Q(1, 5), {("AB", "BA")}, Q(1, 3), {("W", "W")}),
        "cap_below": (Q(1, 3), {("W", "W")}, Q(1, 3), {("W", "W")}),
        "t_one": (Q(1, 5), {("AB", "BA")}, Q(1, 3), {("W", "W")}),
    }
    for name, (fm, fs, cm, cs) in expected.items():
        check(name + "-all-optima", solve(all_values[name]) == (fm, fs) and
              solve(all_values[name], common=True) == (cm, cs),
              f"All ties retained: full minimum {fm}; common minimum {cm}.")
    check("joint-union-counted-once", all_values["crossed"][("AB", "BA")]["J"] == Q(1, 5)
          and all_values["crossed"][("AB", "AB")]["J"] == 1
          and all_values["aligned"][("AB", "AB")]["J"] == Q(1, 5),
          "Coincident domain failures are not summed; crossed common AB has a failure in every state.")
    independent = fixtures["independent"]
    marginals = []
    for d in range(2):
        law = {}
        for p, state in zip(independent["mass"], independent["states"]):
            key = tuple(row[d] for row in state)
            law[key] = law.get(key, Q(0)) + Q(p)
        marginals.append(law)
    check("independent-input-law", all(Q(p) == marginals[0][tuple(row[0] for row in state)] *
          marginals[1][tuple(row[1] for row in state)] for p, state in zip(independent["mass"], independent["states"])),
          "Every supplied joint atom equals its two complete-domain marginal masses' product.")
    iv = all_values["independent"]
    check("independence-not-product-feasibility", iv[("AB", "W")]["feasible"] and
          iv[("W", "AB")]["feasible"] and not iv[("AB", "AB")]["feasible"] and
          iv[("AB", "AB")]["J"] == Q(19, 100),
          "AB is in both feasible projections, but their AB/AB combination violates alpha=3/20.")
    check("inclusive-cap", all_values["cap_equal"][("AB", "BA")]["feasible"] and
          not all_values["cap_below"][("AB", "BA")]["feasible"] and
          all_values["cap_equal"][("AB", "BA")]["J"] == Q(1, 5),
          "J=1/5 is feasible at alpha=1/5, excluded at alpha=199/1000.")
    check("strict-threshold-t-one", all(v["J"] == 0 and v["feasible"]
          for v in all_values["t_one"].values()), "F<=N implies F>1*N is always false; all nine cards satisfy alpha=0.")
    ev = all_values["equality"]
    check("weak-error-at-equality", ev[("AB", "AB")]["risk"] == Q(1, 2) and
          ev[("AB", "AB")]["J"] == Q(1, 2) and
          all(f == n for v in ev.values() for n, f in v["states"][1]["counts"]),
          "At the equality atom every issued direction is false; equality has mass 1/2, not an almost-sure identity.")
    # Bounded algebra checks reuse declared fixtures with an explicit weight
    # override. They are not extra parity rows or unreported primary fixtures.
    zero_product = {c: evaluate(fixtures["t_one"], c, columns, [Q(1), Q(0)], tau) for c in cards}
    check("zero-weight-product-argmin", solve(zero_product) ==
          (Q(1, 5), {("AB", "W"), ("AB", "AB"), ("AB", "BA")}),
          "Derived t_one check with weights (1,0): every zero-weight column occurs in the full optimum; feasible family is all nine cards.")
    zero_coupled = {c: evaluate(fixtures["crossed"], c, columns, [Q(1), Q(0)], tau) for c in cards}
    check("zero-weight-keeps-protection", zero_coupled[("AB", "BA")]["feasible"] and
          not zero_coupled[("AB", "AB")]["feasible"] and
          zero_coupled[("AB", "BA")]["risk"] == zero_coupled[("AB", "AB")]["risk"],
          "Derived crossed check with weights (1,0): the zero-weight domain still enters the unchanged protection event.")

    OUT.mkdir(parents=True, exist_ok=True)
    table = OUT / "oracle-candidates.csv"
    with table.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    inputs = [SPEC]
    receipt = {"status": "pass", "started_at_utc": started,
               "completed_at_utc": datetime.now(timezone.utc).isoformat(),
               "arithmetic": "Python standard-library fractions.Fraction; no floating-point arithmetic",
               "independence": "Implementation and expected checks derived from fixture and mathematical contracts; no R code/output or package implementation read.",
               "claim_scope": "Exact finite-law risks, joint probabilities and all minimizers in the declared nine-card family. No empirical, iid, MCMC or unrestricted-n claim.",
               "input_manifest": [{"path": str(p), "sha256": digest(p), "bytes": p.stat().st_size} for p in inputs],
               "script": {"path": str(Path(__file__).resolve()), "sha256": digest(Path(__file__))},
               "output_csv": {"path": str(table), "sha256": digest(table), "rows": len(rows), "schema": FIELDS},
               "summaries": summaries, "checks": checks,
               "derived_checks_not_parity_rows": ["zero-weight-product-argmin", "zero-weight-keeps-protection"],
               "findings": [], "unperformed": ["R parity comparison (compare-pilot.py)"]}
    (OUT / "oracle-checks.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"rows": len(rows), "checks_passed": len(checks), "summaries": summaries}, indent=2))


if __name__ == "__main__":
    main()
