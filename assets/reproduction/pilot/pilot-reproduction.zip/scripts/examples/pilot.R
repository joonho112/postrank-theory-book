#!/usr/bin/env Rscript
# Author: JoonHo Lee (jlee296@ua.edu)
# Run from the book root with POSTRANK_LIB pointing to a postrank 1.2.0 library.
# All input states are synthetic complete finite laws. No empirical model is fit.
# This script does not import the independent reference implementation.
options(stringsAsFactors = FALSE, warn = 1)
started <- Sys.time()
library_root <- Sys.getenv("POSTRANK_LIB", unset = "")
if (!nzchar(library_root) || !dir.exists(library_root)) {
  stop("Set POSTRANK_LIB to an existing library containing postrank 1.2.0.")
}
library_root <- normalizePath(library_root, mustWork = TRUE)
if ("postrank" %in% loadedNamespaces()) {
  stop("Start a fresh R process; postrank must not already be loaded.")
}
if (as.character(utils::packageVersion("postrank", lib.loc = library_root)) != "1.2.0") {
  stop("This pilot requires exactly postrank 1.2.0; no fallback is permitted.")
}
suppressPackageStartupMessages(library(postrank, lib.loc = library_root))
package_path <- normalizePath(getNamespaceInfo(asNamespace("postrank"), "path"))
stopifnot(identical(package_path, normalizePath(file.path(library_root, "postrank"))))
for (dependency in c("gmp", "jsonlite", "digest")) {
  if (!requireNamespace(dependency, quietly = TRUE)) stop("Missing dependency: ", dependency)
}
public_api <- c("postrank_mdomain_input", "postrank_mdomain_decision",
  "postrank_mdomain_family", "postrank_mdomain_solve",
  "postrank_mdomain_evaluate", "postrank_mdomain_assess")
stopifnot(all(public_api %in% getNamespaceExports("postrank")))

fixture_path <- "evidence/pilot/fixture-spec.json"
script_path <- "scripts/examples/pilot.R"
output_path <- "results/pilot/r-candidates.csv"
runtime_path <- "results/pilot/r-runtime.json"
if (!file.exists(fixture_path) || !file.exists(script_path)) {
  stop("Run this script from the book root.")
}
dir.create(dirname(output_path), recursive = TRUE, showWarnings = FALSE)
sha256 <- function(path) digest::digest(file = path, algo = "sha256", serialize = FALSE)
package_files <- file.path(package_path,
  c("DESCRIPTION", "NAMESPACE", "R/postrank.rdb", "R/postrank.rdx"))
stopifnot(all(file.exists(package_files)))
package_before <- setNames(vapply(package_files, sha256, ""), package_files)
spec_hash <- sha256(fixture_path)
spec <- jsonlite::fromJSON(fixture_path, simplifyVector = FALSE)
stopifnot(identical(spec$schema, "postrank-v4-pilot-fixtures-1"))
units <- unlist(spec$units, use.names = FALSE)
domains <- unlist(spec$domains, use.names = FALSE)
stopifnot(length(units) == 2L, length(domains) == 2L)
columns <- lapply(spec$candidate_columns, function(g) {
  setNames(as.integer(unlist(g, use.names = FALSE)), units)
})
stopifnot(identical(names(columns), c("W", "AB", "BA")))
targets <- setNames(lapply(domains, function(domain) list(
  definition = paste("Synthetic priority coordinate in", domain),
  units = "arbitrary priority units", orientation = "larger_is_higher",
  transformations = list(), equality_classes = setNames(units, units),
  equality_provenance = paste("Alder and Birch are distinct modeled targets;",
    "a statewise numerical tie is not a structural identity."))), domains)

fixtures <- spec$fixtures
names(fixtures) <- vapply(fixtures, function(f) f$id, "")
main_ids <- names(fixtures)
for (variant in spec$boundary_variants) {
  f <- fixtures[[variant$base]]
  stopifnot(!is.null(f))
  f$id <- variant$id
  f$title <- paste("Boundary variant of", variant$base)
  f$base <- variant$base
  if (!is.null(variant$t)) f$t <- variant$t
  if (!is.null(variant$alpha)) f$alpha <- variant$alpha
  fixtures[[f$id]] <- f
}

make_input <- function(f) {
  x <- array(0, c(length(f$states), length(units), length(domains)),
    dimnames = list(paste0(f$id, "-state-", seq_along(f$states)), units, domains))
  for (s in seq_along(f$states)) for (u in seq_along(units)) {
    for (d in seq_along(domains)) x[s, u, d] <- f$states[[s]][[u]][[d]]
  }
  postrank_mdomain_input(x, targets = targets,
    provenance = list(input_id = paste0("pilot-", f$id),
      law_id = paste0("pilot-law-", if (is.null(f$base)) f$id else f$base),
      proper_law = TRUE, producer = "Authored synthetic monograph pilot",
      joint_generation = paste("Each state lists both units in both domains;",
        "the listed masses define a complete joint law."),
      sampling_assumptions = list(finite_support_origin = paste(
        "All support states and exact masses are explicitly listed in",
        "evidence/pilot/fixture-spec.json; no sampling or posterior fit is used."))),
    representation = "exact_finite_law",
    masses = unlist(f$mass, use.names = FALSE))
}
make_decision <- function(f) postrank_mdomain_decision(
  weights = setNames(unlist(spec$weights, use.names = FALSE), domains),
  tau = setNames(unlist(spec$tau, use.names = FALSE), domains),
  scope = "all_pairs", q = NULL,
  t = setNames(unlist(f$t, use.names = FALSE), domains), alpha = f$alpha)
column_label <- function(g) {
  matches <- vapply(columns, function(column) identical(as.integer(g), as.integer(column)), TRUE)
  stopifnot(sum(matches) == 1L)
  names(columns)[matches]
}
exact_equal <- function(a, b) isTRUE(gmp::as.bigq(a) == gmp::as.bigq(b))
minimum_rows <- function(risk, eligible) {
  result <- rep(FALSE, length(risk))
  indexes <- which(eligible)
  if (!length(indexes)) return(result)
  values <- gmp::as.bigq(risk[indexes])
  result[indexes] <- as.logical(values == min(values))
  result
}

run_fixture <- function(f) {
  input <- make_input(f)
  decision <- make_decision(f)
  family <- postrank_mdomain_family(input,
    columns = setNames(rep(list(columns), length(domains)), domains), max_actions = 9L)
  fit <- postrank_mdomain_solve(input, family, decision, max_actions = 9L)
  tab <- fit$candidate_table
  stopifnot(nrow(tab) == 9L, !anyDuplicated(tab$action_id))
  actions <- fit$solution$actions[tab$action_id]
  d1 <- vapply(actions, function(g) column_label(g[, domains[1L]]), "")
  d2 <- vapply(actions, function(g) column_label(g[, domains[2L]]), "")
  stable_id <- paste(d1, d2, sep = "__")
  stopifnot(!anyDuplicated(stable_id))
  common <- d1 == d2
  stopifnot(sum(common) == 3L)
  risk <- as.character(tab$risk_exact)
  joint <- as.character(tab$J_exact)
  feasible <- as.logical(tab$feasible_for_represented_measure)
  optimal_full <- as.logical(tab$optimal)
  stopifnot(!anyNA(c(risk, joint, feasible, optimal_full)),
    identical(optimal_full, minimum_rows(risk, feasible)),
    setequal(tab$action_id[optimal_full], fit$optimizer_ids))
  # The public family constructor exposes a product, not a diagonal restriction.
  # Common-column optimality is an external exact filter of this SAME table.
  optimal_common <- minimum_rows(risk, common & feasible)
  evaluations <- lapply(actions, function(g) postrank_mdomain_evaluate(input, g, decision))
  assessments <- lapply(actions, function(g) postrank_mdomain_assess(
    input, g, decision, method = "exact"))
  for (i in seq_len(nrow(tab))) {
    e <- evaluations[[i]]
    a <- assessments[[i]]
    stopifnot(exact_equal(e$risk_exact, risk[i]), exact_equal(e$J_exact, joint[i]),
      identical(e$feasible_for_represented_measure, feasible[i]),
      exact_equal(a$risk_exact, risk[i]), exact_equal(a$J_exact, joint[i]),
      identical(a$evaluation$feasible_for_represented_measure, feasible[i]),
      identical(a$method, "exact"),
      identical(a$status, "evaluated_declared_finite_law"),
      identical(e$status$arithmetic, "exact_represented_measure_arithmetic"))
  }
  result <- data.frame(fixture = f$id, candidate_id = stable_id,
    Domain1 = unname(d1), Domain2 = unname(d2), risk_exact = risk,
    J_exact = joint, feasible = feasible, optimal_full = optimal_full,
    optimal_common = optimal_common, common = common,
    package_action_id = tab$action_id, check.names = FALSE)
  result <- result[order(match(result$Domain1, names(columns)),
    match(result$Domain2, names(columns))), ]
  rownames(result) <- NULL
  cat(sprintf("%s: %d candidates; %d feasible; full optima [%s]; common optima [%s]\n",
    f$id, nrow(result), sum(feasible), paste(stable_id[optimal_full], collapse = ", "),
    paste(stable_id[optimal_common], collapse = ", ")))
  cat("  Full risk:", paste(unique(risk[optimal_full]), collapse = ","),
    "; common risk:", paste(unique(risk[optimal_common]), collapse = ","), "\n")
  list(rows = result, receipt = list(
    fixture = f$id, kind = if (f$id %in% main_ids) "main" else "boundary",
    state_count = length(f$states), mass_exact = unlist(f$mass, use.names = FALSE),
    t_exact = unlist(f$t, use.names = FALSE), alpha_exact = f$alpha,
    candidates = nrow(tab), common_candidates = sum(common), feasible_count = sum(feasible),
    full_optimizer_ids = unname(stable_id[optimal_full]),
    full_optimum_risk_exact = unique(risk[optimal_full]),
    common_optimizer_ids = unname(stable_id[optimal_common]),
    common_optimum_risk_exact = unique(risk[optimal_common]),
    public_solver_status = fit$status,
    public_search_scope = fit$search_scope,
    fixed_evaluations_compared = length(evaluations),
    exact_assessments_compared = length(assessments),
    assessment_status = unique(vapply(assessments, function(a) a$status, "")),
    public_api_internal_consistency = "PASS"))
}

cat("postrank pilot started", format(started, tz = "UTC", usetz = TRUE), "\n")
cat("R:", R.version.string, "\npostrank:", as.character(packageVersion("postrank")),
  "\nlibrary:", library_root, "\n")
runs <- lapply(fixtures, run_fixture)
all_rows <- do.call(rbind, lapply(runs, function(run) run$rows))
rownames(all_rows) <- NULL
stopifnot(nrow(all_rows) == 9L * length(fixtures),
  !anyDuplicated(paste(all_rows$fixture, all_rows$candidate_id)))
stopifnot(identical(spec_hash, sha256(fixture_path)),
  identical(package_before, setNames(vapply(package_files, sha256, ""), package_files)))
utils::write.csv(all_rows, output_path, row.names = FALSE, na = "NA")
finished <- Sys.time()
runtime <- list(schema = "postrank-v4-pilot-r-runtime-1", status = "PASS",
  started_at_utc = format(started, "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
  finished_at_utc = format(finished, "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
  elapsed_seconds = as.numeric(difftime(finished, started, units = "secs")),
  R_version = R.version.string, Rscript = Sys.which("Rscript"),
  platform = R.version$platform, working_directory = normalizePath("."),
  postrank_version = as.character(packageVersion("postrank")),
  POSTRANK_LIB = library_root, loaded_package_path = package_path,
  dependencies = setNames(lapply(c("gmp", "jsonlite", "digest"), function(p) list(
    version = as.character(packageVersion(p)), path = find.package(p))),
    c("gmp", "jsonlite", "digest")),
  installed_package_files_before = as.list(package_before),
  installed_package_files_after_unchanged = TRUE,
  fixture_spec = list(path = fixture_path, sha256 = spec_hash),
  script = list(path = script_path, sha256 = sha256(script_path)),
  output = list(path = output_path, sha256 = sha256(output_path), rows = nrow(all_rows),
    main_rows = sum(all_rows$fixture %in% main_ids),
    boundary_rows = sum(!all_rows$fixture %in% main_ids)),
  public_api_exercised = public_api,
  exact_arithmetic = "Rational strings retained by postrank; gmp compares returned rational risks exactly.",
  common_family_method = paste("External exact diagonal filtering of the same public-solver candidate table;",
    "no public common-restricted solver is claimed or called."),
  optimizer_ties = "All exact minimizing feasible rows retained; no secondary objective.",
  empirical_fit_or_sampling = FALSE, independent_oracle_accessed = FALSE,
  scope = paste("Complete synthetic finite laws, represented-measure feasibility, and specified",
    "nine-card candidate-family optimality only; no iid/MCMC or empirical posterior assurance."),
  fixtures = unname(lapply(runs, function(run) run$receipt)),
  session_info = capture.output(sessionInfo()))
jsonlite::write_json(runtime, runtime_path, auto_unbox = TRUE, pretty = TRUE, null = "null")
cat("PASS:", nrow(all_rows), "candidate rows written to", output_path, "\n")
cat("Runtime receipt:", runtime_path, "\n")
