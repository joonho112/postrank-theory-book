#!/usr/bin/env python3
# Author: JoonHo Lee (jlee296@ua.edu)
"""Draw the mobile companion at a native width of 360 SVG/CSS pixels.

Presentation only: reuses the verified crossed fixture and displayed results.
No R/decision-oracle imports. The desktop figure and generator stay unchanged.
The chapter supplies fixed cost, weight and threshold settings.
"""
from pathlib import Path
import json
import subprocess
from reportlab import rl_config
from reportlab.graphics.shapes import Drawing, Rect, String, Line
from reportlab.graphics import renderPDF, renderSVG
from reportlab.lib.colors import HexColor, white
from reportlab.pdfgen.canvas import Canvas
from reportlab.pdfbase.pdfmetrics import stringWidth

BOOK = Path(__file__).resolve().parents[2]
OUT = BOOK / 'assets/figures'
rl_config.invariant = 1
spec = json.loads((BOOK / 'evidence/pilot/fixture-spec.json').read_text())
crossed = next(f for f in spec['fixtures'] if f['id'] == 'crossed')
assert spec['units'] == ['Alder', 'Birch']
assert spec['candidate_columns'] == {'W': [1, 1], 'AB': [1, 2], 'BA': [2, 1]}
assert crossed['mass'] == ['4/5', '1/5']
assert crossed['states'] == [[[1, -1], [0, 0]], [[-1, 1], [0, 0]]]
assert crossed['t'] == ['0', '0'] and crossed['alpha'] == '1/4'
assert spec['tau'] == ['1/3', '1/3'] and spec['weights'] == ['1/2', '1/2']

WIDTH, HEIGHT = 360, 666
ink, muted = HexColor('#202A35'), HexColor('#4B5563')
rule, accent = HexColor('#BCC4CC'), HexColor('#146273')
tint, neutral = HexColor('#E9F2F3'), HexColor('#F5F6F7')
d = Drawing(WIDTH, HEIGHT)
d.add(Rect(0, 0, WIDTH, HEIGHT, fillColor=white, strokeColor=None))

def text(x, y, s, size=14, align='start', bold=False, color=ink):
    font = 'Helvetica-Bold' if bold else 'Helvetica'
    width = stringWidth(s, font, size)
    left = x-width/2 if align == 'middle' else x-width if align == 'end' else x
    assert left >= 11 and left+width <= WIDTH-11, (s, left, width)
    d.add(String(x, y, s, fontName=font, fontSize=size, textAnchor=align, fillColor=color))

def line(y):
    d.add(Line(18, y, WIDTH-18, y, strokeColor=rule, strokeWidth=0.7))

text(180, 642, 'Same joint law in both panels', 17, 'middle', True)
text(180, 619, 'Crossed priorities (4/5); both reverse (1/5).', 14, 'middle')
line(603)

panels = [
    dict(top=578, title='(a) Best common card', subtitle='W / W: identical columns',
         grades=[[1, 1], [1, 1]], risk='1/3', joint='0',
         notes=['Both comparisons withheld', 'Same grade does not assert equality.']),
    dict(top=330, title='(b) Best profile card', subtitle='AB / BA: crossed columns',
         grades=[[1, 2], [2, 1]], risk='1/5', joint='1/5',
         notes=['Domain 1: Alder leads', 'Domain 2: Birch leads']),
]
for p in panels:
    top = p['top']
    text(180, top, p['title'], 17, 'middle', True)
    text(180, top-24, p['subtitle'], 14, 'middle', color=muted)
    y = top-53
    text(24, y, 'Unit', 15, bold=True)
    for x, name in [(188, 'Domain 1'), (292, 'Domain 2')]:
        text(x, y, name, 15, 'middle', True)
    line(y-9)
    for i, unit in enumerate(spec['units']):
        cy = y-36-36*i
        text(24, cy-5, unit, 16)
        for j, x in enumerate([188, 292]):
            grade = p['grades'][i][j]
            d.add(Rect(x-31, cy-15, 62, 30, fillColor=tint if grade==1 else neutral, strokeColor=None))
            text(x, cy-6, str(grade), 18, 'middle', True)
    for k, note in enumerate(p['notes']):
        text(180, top-153-21*k, note, 14, 'middle', color=muted)
    color = accent if p['joint']!='0' else ink
    text(24, top-204, 'Risk = '+p['risk'], 16, bold=True, color=color)
    text(336, top-204, 'Joint error J = '+p['joint'], 16, 'end', True, color=color)
line(357)
line(109)
text(180, 86, 'Both cards satisfy J <= 1/4.', 15, 'middle', True)
text(180, 64, 'J: chance of any false issued direction.', 14, 'middle')
text(180, 42, 'Smaller grade = higher reported priority.', 14, 'middle')
text(180, 20, 'Fixed settings are given in the chapter.', 14, 'middle', color=muted)

OUT.mkdir(exist_ok=True)
svg, pdf = OUT/'v4-pilot-stacked.svg', OUT/'v4-pilot-stacked.pdf'
renderSVG.drawToFile(d, str(svg), title='Mobile common and profile card comparison')
canvas=Canvas(str(pdf), pagesize=(WIDTH, HEIGHT), invariant=1)
canvas.setAuthor('JoonHo Lee (jlee296@ua.edu)')
canvas.setCreator('JoonHo Lee (jlee296@ua.edu)')
canvas.setTitle('Mobile common and profile card comparison')
canvas.setSubject('Same verified crossed fixture as desktop figure; layout-only companion')
renderPDF.draw(d, canvas, 0, 0)
canvas.showPage()
canvas.save()
# 72 dpi makes the QA raster exactly 360 pixels wide, matching intended CSS width.
subprocess.run(['pdftoppm','-singlefile','-r','72','-png',str(pdf),str(OUT/'v4-pilot-stacked')],check=True)
print('Created stacked SVG/PDF plus 360-pixel-wide PDF raster.')
