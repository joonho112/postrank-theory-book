# Author: JoonHo Lee (jlee296@ua.edu)
from pathlib import Path
from fractions import Fraction
import csv,json,hashlib
R=Path(__file__).resolve().parents[2]
p=R/'results/pilot'
a=list(csv.DictReader((p/'oracle-candidates.csv').open()));b=list(csv.DictReader((p/'r-candidates.csv').open()))
def bit(v):
 assert v.lower() in ['true','false'],v
 return v.lower()=='true'
def row(r,cols):
 return {'key':(r['fixture'],r[cols[0]],r[cols[1]]),'risk_exact':Fraction(r['risk_exact']),'J_exact':Fraction(r['J_exact']),**{k:bit(r[k]) for k in ['feasible','optimal_full','optimal_common','common']}}
x={v['key']:v for r in a for v in [row(r,['column1','column2'])]};y={v['key']:v for r in b for v in [row(r,['Domain1','Domain2'])]}
assert len(x)==len(y)==63 and x.keys()==y.keys()
diffs=[{'key':list(k),'fields':[f for f in x[k] if x[k][f]!=y[k][f]]} for k in x if x[k]!=y[k]]
report={'status':'pass' if not diffs else 'fail','independent_rows':len(x),'fixtures':sorted({k[0] for k in x}),'compared_fields':['risk_exact','J_exact','feasible','optimal_full','optimal_common','common'],'mismatches':diffs,'scope':'All9candidate cards per7stipulated finite laws; exact rational values and complete optimalsets compared. No empirical posterior fit or statistical assurance test.','independence':'R used postrank 1.2.0. The Python oracle used Fraction arithmetic and did not read the R code or results.','inputs':{f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in ['r-candidates.csv','oracle-candidates.csv','r-runtime.json','oracle-checks.json']}}
(p/'parity.json').write_text(json.dumps(report,indent=2)+'\n');assert not diffs,diffs
print('63 rows x6 fields: exact parity PASS')
