# Small exact examples

**JoonHo Lee (jlee296@ua.edu)**

This review-candidate archive accompanies *Decisions from Noisy Multidimensional Indicators: Theory, Evidence, and Posterior Grading*. It supplies four existing finite calculations and two figure scripts. It contains no empirical data, fitted posterior, optimizer, postrank package, source PDFs, or historical KRW inputs. The project license and public release remain subject to author review; see RIGHTS.md.

Extract the archive and run these commands from the `p1-small-examples` directory:

```sh
python3 verify.py
python3 examples/fixed-order-dp.py --check
python3 examples/exact-common-grade.py --check
python3 examples/objective-contrast.py --check
python3 examples/matched-disclosure.py --check
```

Python uses only its standard library. The checked environment was CPython 3.13.2; other versions were not independently checked for this release candidate. Each `--check` recomputes and compares the entire saved object without overwriting it. Running without `--check` deliberately regenerates outputs. The four-unit worked example and frontier use the included fixed-order result as their upstream input; retain its exact bytes.

The four checks cover a four-unit finite law, its common-grade objectives, a three-unit objective contrast, and matched disclosure under selected report families. They enumerate small sets of canonical reports and use rational arithmetic. They are not a parameter sweep or a test of empirical calibration.

To recreate the two figures from saved results, use R with the packages listed in environment.json:

```sh
mkdir -p assets/figures
Rscript --vanilla examples/plot-objective-contrast.R
Rscript --vanilla examples/plot-matched-disclosure.R
```

These commands write SVG and PNG outputs under `assets/figures/`; they do not recompute the enumerations. Run them from this directory. The `_quarto.yml` file is an existence marker required by the unchanged frontier plot script, not a book configuration. Figure bytes may depend on package, font and graphics versions. The documented local verification reproduced all four canonical figure files byte for byte; that is not a cross-platform guarantee.

`checksums.json` identifies every supplied file other than itself. `verify.py` checks those paths and bytes, not scientific validity. The archive's own SHA-256 is supplied alongside its download. The environment record reports the environment actually checked, not an automatic installer or a hermetic environment lock.
