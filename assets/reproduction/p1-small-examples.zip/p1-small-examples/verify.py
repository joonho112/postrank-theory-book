#!/usr/bin/env python3
# Author: JoonHo Lee (jlee296@ua.edu)
"""Verify the supplied files against their relative-path checksum inventory."""
from pathlib import Path
import hashlib, json
root = Path(__file__).resolve().parent
inventory = json.loads((root / 'checksums.json').read_text())
for item in inventory['files']:
    path = (root / item['path']).resolve()
    if not path.is_relative_to(root):
        raise SystemExit('Inventory path escapes archive root')
    data = path.read_bytes()
    if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
        raise SystemExit('Checksum mismatch: ' + item['path'])
print('Verified', len(inventory['files']), 'supplied files.')
