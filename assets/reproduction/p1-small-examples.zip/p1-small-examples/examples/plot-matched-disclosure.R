# Author: JoonHo Lee (jlee296@ua.edu)
# Render the one exact fixture; numerical enumeration is in matched-disclosure.py.
library(jsonlite)
library(ggplot2)
root <- normalizePath(".")
stopifnot(file.exists(file.path(root, "_quarto.yml")))
fixture <- fromJSON(file.path(root, "examples/matched-disclosure-results.json"),
                    simplifyVector = FALSE)
fraction <- function(x) {
  p <- strsplit(as.character(x), "/", fixed = TRUE)[[1]]
  as.numeric(p[1]) / if (length(p) == 2) as.numeric(p[2]) else 1
}
panels <- c("Same law, different feasible reports", "Randomization and sparse-path limits")
vertex <- function(name, panel, label) {
  v <- fixture$families[[name]]$vertices
  data.frame(N = vapply(v, function(z) as.numeric(z[[1]]), numeric(1)),
             A = vapply(v, function(z) fraction(z[[2]]), numeric(1)),
             panel = panel, rule = label)
}
lines <- rbind(vertex("unrestricted", panels[1], "Exact frontier"),
               vertex("order_DCBA", panels[1], "Imposed reverse order"),
               vertex("unrestricted", panels[2], "Exact frontier"),
               vertex("sparse_endpoints", panels[2], "Two-endpoint candidate hull"))
points <- unique(data.frame(N = vapply(fixture$all_reports, function(z) z$N, numeric(1)),
                            A = vapply(fixture$all_reports, function(z) fraction(z$A), numeric(1)),
                            panel = panels[1]))
special <- data.frame(N = c(4,4), A = c(7/10,19/40), panel = panels[2],
                      label = c("Best deterministic report at N = 4", "Whole-report mixture at mean N = 4"))
for (d in c("lines", "points", "special")) {
  value <- get(d); value$panel <- factor(value$panel, levels = panels); assign(d,value)
}
p <- ggplot() +
  geom_point(data = points, aes(N,A), color = "#ccd3d7", size = 1.8) +
  geom_line(data = lines, aes(N,A,color = rule, linetype = rule), linewidth = 0.85) +
  geom_point(data = lines, aes(N,A,color = rule), size = 2.1) +
  geom_point(data = special, aes(N,A,shape = label), color = "#202c36", size = 2.7) +
  geom_text(data = special[2,], aes(N,A,label = "A = 19/40"),
            nudge_y = -0.07, hjust = 0.4, size = 3.5) +
  facet_wrap(~panel, nrow = 1, scales = "free_y") +
  scale_color_manual(values = c("Exact frontier" = "#096b76", "Imposed reverse order" = "#a14530",
                                "Two-endpoint candidate hull" = "#8c6b27")) +
  scale_linetype_manual(values = c("Exact frontier" = "solid", "Imposed reverse order" = "dashed",
                                   "Two-endpoint candidate hull" = "dotted")) +
  scale_shape_manual(values = c("Best deterministic report at N = 4" = 15,
                                "Whole-report mixture at mean N = 4" = 18)) +
  scale_x_continuous(breaks = 0:6, expand = expansion(mult = c(.02,.03))) +
  labs(x = "Expected disclosed count, N", y = "Expected weighted wrong-count, A",
       color = NULL, linetype = NULL, shape = NULL) +
  guides(color = guide_legend(order = 1), linetype = guide_legend(order = 1),
         shape = guide_legend(order = 2)) +
  theme_minimal(base_size = 12, base_family = "sans") +
  theme(panel.grid.minor = element_blank(), panel.grid.major = element_line(color = "#e5e8ea"),
        panel.spacing = grid::unit(1.2,"lines"), strip.text = element_text(face = "bold",size = 12),
        legend.position = "bottom", legend.box = "vertical", legend.text = element_text(size = 10),
        plot.margin = margin(12,15,8,10))
dir.create(file.path(root,"assets/figures"), recursive = TRUE, showWarnings = FALSE)
ggsave(file.path(root,"assets/figures/matched-disclosure-frontier.svg"), p,
       width = 12, height = 5.5, device = svglite::svglite, bg = "white")
ggsave(file.path(root,"assets/figures/matched-disclosure-frontier.png"), p,
       width = 12, height = 5.5, dpi = 180, bg = "white")
cat("Rendered exact JSON coordinates to SVG and PNG; no new enumeration or simulation.\n")
