# Author: JoonHo Lee (jlee296@ua.edu)
# Plot one saved exact design. No scientific probabilities are recomputed here.
library(jsonlite)
library(ggplot2)
library(grid)

args <- commandArgs(trailingOnly = FALSE)
script <- sub('^--file=', '', args[grepl('^--file=', args)])
root <- normalizePath(file.path(dirname(script), '..'))
x <- fromJSON(file.path(root, 'fixtures/objective-contrast.json'), simplifyVector = FALSE)
rational <- function(z) {
  p <- strsplit(as.character(z), '/', fixed = TRUE)[[1]]
  as.numeric(p[1]) / if (length(p) == 2) as.numeric(p[2]) else 1
}
curves <- do.call(rbind, lapply(names(x$families), function(nm) {
  h <- x$families[[nm]]$hull
  data.frame(N = vapply(h, function(z) as.numeric(z[[1]]), 0.0),
             A = vapply(h, function(z) rational(z[[2]]), 0.0),
             family = if(nm == 'unrestricted') 'All coherent reports' else 'Mean-order reports')
}))
moments <- do.call(rbind, lapply(x$moments, function(z) {
  data.frame(label = z$unit, value = rational(z$mean), probability = rational(z$top1_probability))
}))
lottery_row <- Filter(function(z) identical(as.integer(unlist(z$g)), c(1L,1L,2L)), x$selected_reports)[[1]]
lottery_values <- lottery_row$added_top_grade_uniform_allocation
lottery <- data.frame(label = 'AB lottery', value = rational(lottery_values$expected_value),
                      probability = rational(lottery_values$probability_select_best))
palette <- c('All coherent reports' = '#176A70', 'Mean-order reports' = '#B36B35')
base <- theme_minimal(base_size = 12, base_family = 'Helvetica') +
  theme(panel.grid.minor = element_blank(), plot.title = element_text(face='bold',size=14),
        plot.subtitle = element_text(size=10), plot.margin=margin(12,16,12,12),
        legend.position='bottom',legend.title=element_blank())
p1 <- ggplot(curves, aes(N,A,color=family,linetype=family)) +
  geom_line(linewidth=.9) + geom_point(size=2.6) +
  scale_color_manual(values=palette) + scale_linetype_manual(values=c('solid','dashed')) +
  scale_x_continuous(breaks=0:3) + scale_y_continuous(breaks=seq(0,1.5,.3),limits=c(0,1.5)) +
  labs(title='A. Disclosure under one conditional law',
       subtitle='Vertices are complete reports; segments mix whole reports.',
       x='Expected number of disclosed pairs',y='Expected wrong count') + base
p2 <- ggplot(moments,aes(value,probability)) +
  geom_point(size=3,color='#176A70') +
  geom_text(aes(label=label),vjust=-.85,size=4,color='#173F45') +
  geom_point(data=lottery,shape=18,size=3,color='#666666') +
  geom_text(data=lottery,aes(label=label),vjust=-.9,size=3.3,color='#555555') +
  scale_x_continuous(breaks=3:6,limits=c(2.7,6.3)) +
  scale_y_continuous(breaks=seq(0,.8,.2),limits=c(-.02,.85),labels=function(z)paste0(round(z*100),'%')) +
  labs(title='B. A budget of one: different objectives',
       subtitle='A, B, C: singletons. AB lottery: uniform over A and B.',
       x='Expected selected target value',y='Probability of selecting the best unit') + base
draw <- function() {
  grid.newpage()
  pushViewport(viewport(layout=grid.layout(1,2,widths=unit(c(.56,.44),'null'))))
  print(p1,vp=viewport(layout.pos.row=1,layout.pos.col=1))
  print(p2,vp=viewport(layout.pos.row=1,layout.pos.col=2))
}
out <- file.path(root,'assets/figures')
svglite::svglite(file.path(out,'objective-contrast.svg'),width=12,height=5.4)
draw();dev.off()
png(file.path(out,'objective-contrast.png'),width=1800,height=810,res=150)
draw();dev.off()
cat('Saved SVG and PNG from fixtures/objective-contrast.json\n')
