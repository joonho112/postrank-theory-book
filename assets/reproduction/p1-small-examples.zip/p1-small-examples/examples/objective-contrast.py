#!/usr/bin/env python3
# Author: JoonHo Lee (jlee296@ua.edu)
"""One three-unit conditional-uncertainty and objective contrast, exactly.

Extend the earlier two-unit high-mean/low-top-probability illustration by one
fixed unit. No fitted precision model, Monte Carlo, optimizer or parameter sweep.
The companion R figure reads the saved rational results, without new estimation.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import argparse
import json

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'fixtures/objective-contrast.json'
STATES = [(F(3,10),((20,20),(4,4),(3,3))),
          (F(7,10),((0,0),(4,4),(3,3)))]
W = (F(3,5), F(2,5))
A = (F(3,4), F(1,4))
TAU = F(1,4)


def lower_hull(rows):
    minima = {}
    for row in rows:
        n, e = row['N'], F(row['A'])
        minima[n] = min(minima.get(n,e),e)
    hull=[]
    for point in sorted(minima.items()):
        while len(hull)>=2:
            x,y=hull[-2:]
            if (y[1]-x[1])*(point[0]-y[0]) < (point[1]-y[1])*(y[0]-x[0]):
                break
            hull.pop()
        hull.append(point)
    return hull


def build():
    scalar=[(p,[sum(a*x for a,x in zip(A,row)) for row in t]) for p,t in STATES]
    means=[sum(p*c[i] for p,c in scalar) for i in range(3)]
    variances=[sum(p*(c[i]-means[i])**2 for p,c in scalar) for i in range(3)]
    top=[sum(p*(c[i]==max(c)) for p,c in scalar) for i in range(3)]
    assert all(len(set(c))==3 for p,c in scalar)
    assert sum(top)==1 and means==[F(6),F(4),F(3)]
    errors={(i,j):sum(p*(c[i]<=c[j]) for p,c in scalar)
            for i in range(3) for j in range(3) if i!=j}
    rows=[]
    for g in product(range(1,4),repeat=3):
        if set(g)!=set(range(1,max(g)+1)):
            continue
        pairs=[(i,j) for i,j in errors if g[i]<g[j]]
        n=len(pairs)
        e=sum((errors[i,j] for i,j in pairs),F(0))
        dw=sum(p*sum(w*sum(t[i][k]<=t[j][k] for i,j in pairs)
                      for k,w in enumerate(W)) for p,t in STATES)
        da=sum(p*sum(c[i]<=c[j] for i,j in pairs) for p,c in scalar)
        assert e==dw==da
        highest=[i for i in range(3) if g[i]==1]
        rows.append({'g':list(g),'N':n,'G':max(g),'A':str(e),
                     'risk':str((e+TAU*(3-n))/3),
                     'fraction':str(e/n) if n else None,
                     'added_top_grade_uniform_allocation':{
                         'units':['ABC'[i] for i in highest],
                         'expected_value':str(sum(means[i] for i in highest)/len(highest)),
                         'probability_select_best':str(sum(top[i] for i in highest)/len(highest))}})
    fixed=[r for r in rows if r['g']==sorted(r['g'])]
    assert len(rows)==13 and len(fixed)==4
    families={}
    for label,selected in [('unrestricted',rows),('mean_order_ABC',fixed)]:
        hull=lower_hull(selected)
        best=min(F(r['risk']) for r in selected)
        at_two=min(F(r['A']) for r in selected if r['N']==2)
        families[label]={'reports':len(selected),'hull':[[n,str(e)] for n,e in hull],
                         'minimum_risk':str(best),
                         'optimal_reports':[r['g'] for r in selected if F(r['risk'])==best],
                         'matched_N2_minimum_A':str(at_two),
                         'matched_N2_reports':[r['g'] for r in selected if r['N']==2 and F(r['A'])==at_two]}
    return {'schema_version':1,'design':'One synthetic three-unit conditional law',
            'provenance':'Extends the accepted Step8.6 two-unit mean/top-membership contrast by a fixed third unit and two perfectly dependent identical criteria. This is one new finite design, not a sweep.',
            'units':list('ABC'),'n':3,'K':2,'M':3,'w':list(map(str,W)),
            'a':list(map(str,A)),'tau':str(TAU),
            'states':[{'probability':str(p),'theta':[list(row) for row in t]} for p,t in STATES],
            'moments':[{'unit':'ABC'[i],'mean':str(means[i]),'variance':str(variances[i]),
                        'top1_probability':str(top[i])} for i in range(3)],
            'forward_errors':{'AB':str(errors[0,1]),'AC':str(errors[0,2]),'BC':str(errors[1,2])},
            'all_reports':rows,'families':families,
            'selected_reports':[next(r for r in rows if r['g']==g) for g in
                                [[1,1,1],[1,1,2],[2,1,2],[3,1,2],[1,2,3]]],
            'native_budget1':{'mean_utility_maximizers':['ABC'[i] for i in range(3) if means[i]==max(means)],
                              'top1_probability_maximizers':['ABC'[i] for i in range(3) if top[i]==max(top)]},
            'checks':{'canonical_reports_13':True,'mean_order_reports_4':True,
                      'all_report_co_primary_direct_and_pair_counts_equal':True,
                      'latent_comparisons_strict':True,'all_checks_passed':True},
            'limits':['Heterogeneous conditional target uncertainty, not a sampling-SE experiment or a fitted EB model',
                      'Both criteria coincide; no new criterion-conflict mechanism is claimed',
                      'Mean-order restriction is deliberately imposed; expected rank order is not substituted',
                      'Frontier interpolations mix whole reports at expected disclosure, not individual pair arrows',
                      'Top-grade lottery is an explicitly added selection rule; not intrinsic to a grade',
                      'Expected utility concerns target values, not a causal treatment effect',
                      'No fitted model, simulation, postrank package or historical data execution']}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--check',action='store_true');args=p.parse_args()
    result=build()
    if args.check:
        assert result==json.loads(OUTPUT.read_text()),'Saved contrast mismatch'
    else:
        OUTPUT.parent.mkdir(exist_ok=True);OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['moments','families','selected_reports','native_budget1','checks']},indent=2))
