#!/usr/bin/env python3
# Author: JoonHo Lee (jlee296@ua.edu)
"""One exact four-unit frontier, reusing the accepted Step 7.2 joint law.

No posterior simulation, fitting, package or optimization backend is used.
All canonical reports are enumerated with rational arithmetic. Plotting only
converts the final exact coordinates to floating point. --check compares the
saved result without rewriting it. The companion R script generates the figure.
"""
from pathlib import Path
from itertools import product
from fractions import Fraction as F
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / 'examples/fixed-order-dp-results.json'
OUTPUT = ROOT / 'examples/matched-disclosure-results.json'


def lower_hull(rows):
    minima = {}
    for r in rows:
        n, a = r['N'], F(r['A'])
        minima[n] = min(minima.get(n, a), a)
    hull = []
    for point in sorted(minima.items()):
        while len(hull) >= 2:
            x, y = hull[-2], hull[-1]
            # Remove collinear interior points and decreasing slopes.
            if (y[1]-x[1])*(point[0]-y[0]) < (point[1]-y[1])*(y[0]-x[0]):
                break
            hull.pop()
        hull.append(point)
    return hull


def interpolate(hull, n):
    if len(hull) == 1:
        assert n == hull[0][0]
        return hull[0][1]
    for left, right in zip(hull, hull[1:]):
        if left[0] <= n <= right[0]:
            p = F(n-left[0], right[0]-left[0])
            return (1-p)*left[1]+p*right[1]
    raise ValueError('Outside the attainable disclosure interval')


def build():
    old = json.loads(INPUT.read_text())
    states = [(F(s['probability']), s['theta_unit_by_criterion'])
              for s in old['joint_belief']]
    weights = list(map(F, old['weights']))
    assert old['n'] == 4 and old['M'] == 6
    assert sum(p for p, _ in states) == sum(weights) == 1
    errors = {(i, j): sum((p*sum((w*(theta[i][k] <= theta[j][k])
                                  for k, w in enumerate(weights)), F(0))
                          for p, theta in states), F(0))
              for i in range(4) for j in range(4) if i != j}
    assert all(errors[i, j]+errors[j, i] == 1 for i, j in errors)
    rows = []
    for g in product(range(1, 5), repeat=4):
        if set(g) != set(range(1, max(g)+1)):
            continue
        pairs = [(i, j) for i, j in errors if g[i] < g[j]]
        a = sum((errors[i, j] for i, j in pairs), F(0))
        direct = sum((p*sum((w*sum(theta[i][k] <= theta[j][k]
                                    for i, j in pairs)
                              for k, w in enumerate(weights)), F(0))
                      for p, theta in states), F(0))
        assert a == direct
        rows.append(dict(g=list(g), G=max(g), N=len(pairs), A=str(a)))
    forward = [r for r in rows if r['g'] == sorted(r['g'])]
    reverse = [r for r in rows if r['g'] == sorted(r['g'], reverse=True)]
    assert len(rows) == 75 and len(forward) == len(reverse) == 8
    assert all(any(r['g'] == oldr['g'] and r['N'] == oldr['N'] and
                   r['A'] == oldr['weighted_expected_error_count'] for r in forward)
               for oldr in old['all_contiguous_partitions'])
    full = lower_hull(rows)
    assert full == [(0,F(0)),(3,F(3,10)),(5,F(13,20)),(6,F(21,20))]
    assert lower_hull(forward) == full
    sparse = [r for r in rows if r['g'] in [[1,1,1,1],[1,2,3,4]]]
    families = {'unrestricted':rows,'order_ABCD':forward,
                'order_DCBA':reverse,'sparse_endpoints':sparse}
    summary = {}
    for name, selected in families.items():
        hull = lower_hull(selected)
        assert all(F(r['A']) >= interpolate(hull,r['N']) for r in selected)
        slopes = [(y[1]-x[1])/F(y[0]-x[0]) for x,y in zip(hull,hull[1:])]
        # Verify each breakpoint and one point between consecutive breakpoints.
        tau_checks = sorted(set([F(0),F(1,2),F(1)] + slopes +
                           [(x+y)/2 for x,y in zip(slopes,slopes[1:])]))
        previous = None
        for tau in tau_checks:
            best = min(F(r['A'])-tau*r['N'] for r in selected)
            minimizers = [r for r in selected if F(r['A'])-tau*r['N'] == best]
            assert all(F(r['A']) == interpolate(hull,r['N']) for r in minimizers)
            if previous is not None:
                assert max(previous) <= min(r['N'] for r in minimizers)
            previous = [r['N'] for r in minimizers]
        summary[name] = {'reports':len(selected),
                         'vertices':[[n,str(a)] for n,a in hull],
                         'slopes':[str(s) for s in slopes],
                         'checked_tau_values':[str(t) for t in tau_checks],
                         'minimum_at_tau_half':str(min(F(r['A'])-F(1,2)*r['N'] for r in selected)),
                         'optimal_disclosure_at_tau_half':sorted(set(r['N'] for r in selected
                             if F(r['A'])-F(1,2)*r['N'] == min(F(q['A'])-F(1,2)*q['N'] for q in selected)))}
    n = 4
    h = interpolate(full,n)
    deterministic = min(F(r['A']) for r in rows if r['N'] == n)
    assert h == F(19,40) and deterministic == F(7,10)
    assert {r['N'] for r in rows if r['G'] == 2} == {3,4}
    return {'schema_version':1,'fixture':'One exact four-unit matched-disclosure construction',
            'input_path':'examples/fixed-order-dp-results.json',
            'input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),
            'provenance':'Reuses the accepted Step7.2 two-state, two-criterion joint law and weights; newly enumerates all75 canonical reports and exact lower hulls. No new probability family.',
            'n':4,'M':6,'weights':old['weights'],'joint_belief':old['joint_belief'],
            'all_reports':rows,'families':summary,
            'matched_N4':{'left_grade':[1,1,1,2],'left_N':3,'left_A':'3/10',
                          'right_grade':[1,2,2,3],'right_N':5,'right_A':'13/20',
                          'right_action_probability':'1/2','mean_N':4,'mean_A':str(h),
                          'ratio_expected_counts':str(h/n),
                          'mean_fraction':str((F(3,10)/3+F(13,20)/5)/2),
                          'best_deterministic_A_at_N4':str(deterministic),
                          'best_deterministic_fraction_at_N4':str(deterministic/n)},
            'sparse_N5':{'A':str(interpolate(lower_hull(sparse),5)),
                         'exact_H':str(interpolate(full,5)),
                         'gap':str(interpolate(lower_hull(sparse),5)-interpolate(full,5))},
            'same_G2_possible_N':[3,4],
            'checks':{'all75_direct_state_counts_equal_pair_coefficient_counts':True,
                      'forward_eight_rows_match_accepted7_2':True,
                      'all_points_above_family_hull':True,
                      'support_points_on_hull':True,
                      'optimal_N_monotone_at_checked_tau_values':True,
                      'all_checks_passed':True},
            'limits':['Finite exact illustration, not a proof for arbitrary n.',
                      'The reversed order is deliberately imposed, not produced by expected-rank ordering.',
                      'Original fixed order matches unrestricted hull in this instance only.',
                      'Interpolation randomizes complete reports; its fraction is a ratio of expected counts.',
                      'This tie-free instance does not independently test every assumption-failure case.',
                      'No fitted posterior, Monte Carlo, package call, solver, or historical campaign rerun.']}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args();result=build()
    if args.check:
        assert result == json.loads(OUTPUT.read_text()),'Saved result mismatch'
    else:
        OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'pass','reports':75,'families':result['families'],
                      'matched_N4':result['matched_N4'],'sparse_N5':result['sparse_N5']},indent=2))


if __name__ == '__main__':main()
