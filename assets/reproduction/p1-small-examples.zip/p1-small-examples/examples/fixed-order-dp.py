#!/usr/bin/env python3
# Author: JoonHo Lee (jlee296@ua.edu)
"""One exact four-unit fixed-order segmentation example.

Regenerate adjacent results JSON, or use --check to compare without writing.
The two-state joint belief is an author construction, not fitted or simulated.
This tiny verification enumerates all optimal paths; that enumeration is not
part of a general O(G*n^2) value-computation complexity assertion.
"""
import argparse
from fractions import Fraction as F
from itertools import combinations, product
import json
from pathlib import Path

UNITS = ('A', 'B', 'C', 'D')
N_UNITS = len(UNITS)
PAIRS = tuple(combinations(range(N_UNITS), 2))
M = len(PAIRS)
WEIGHTS = (F(3, 5), F(2, 5))
TAU = F(1, 4)
ORDER_STATES = ((F(3, 4), ('ABCD', 'ACBD')),
                (F(1, 4), ('BACD', 'DCBA')))


def target_array(orders):
    return tuple(tuple(N_UNITS - order.index(unit) for order in orders)
                 for unit in UNITS)


STATES = tuple((p, target_array(orders)) for p, orders in ORDER_STATES)


def pair_error(i, j, k):
    return sum((p for p, theta in STATES if theta[i][k] <= theta[j][k]), F(0))


def endpoints_to_grade(endpoints):
    return tuple(h for h, (a, b) in enumerate(
        zip((0,) + endpoints[:-1], endpoints), 1) for _ in range(a, b))


def enumerate_endpoints(r):
    if r == 0:
        return ((),)
    return tuple(tuple(i + 1 for i, bit in enumerate(bits) if bit) + (r,)
                 for bits in product((0, 1), repeat=r - 1))


def block_savings(errors, a, b):
    """One-based inclusive interval; code block(a,b)=mathematical W(a-1,b)."""
    return sum((errors[i, j] - TAU for i, j in PAIRS
                if a - 1 <= i < j <= b - 1), F(0))


def inspect(endpoints, errors, blocks):
    g = endpoints_to_grade(endpoints)
    disclosed = tuple((i, j) for i, j in PAIRS if g[i] < g[j])
    expected_errors = tuple(sum((p * sum(theta[i][k] <= theta[j][k]
                                        for i, j in disclosed)
                                for p, theta in STATES), F(0))
                            for k in range(len(WEIGHTS)))
    weighted_error = sum((w * e for w, e in zip(WEIGHTS, expected_errors)), F(0))
    assert weighted_error == sum((errors[pair] for pair in disclosed), F(0))
    withholding = TAU * (M - len(disclosed))
    risk = (weighted_error + withholding) / M
    saving = sum((blocks[a + 1, b]
                  for a, b in zip((0,) + endpoints[:-1], endpoints)), F(0))
    full_cost = sum(errors.values(), F(0))
    assert risk == (full_cost - saving) / M
    assert risk == TAU + (sum((e - TAU for e in errors.values()), F(0)) - saving) / M
    return {'g': list(g), 'endpoints': list(endpoints), 'G': len(endpoints),
            'blocks': [list(UNITS[a:b]) for a, b in
                       zip((0,) + endpoints[:-1], endpoints)],
            'N': len(disclosed),
            'expected_error_counts_by_criterion': [str(e) for e in expected_errors],
            'weighted_expected_error_count': str(weighted_error),
            'withholding_cost': str(withholding),
            'total_unnormalized_cost': str(weighted_error + withholding),
            'total_signed_withholding_saving': str(saving), 'risk': str(risk),
            'weighted_disclosed_error_fraction': str(weighted_error / len(disclosed))
            if disclosed else None}


def dynamic_program(blocks):
    # F(h,r) maximizes W over h nonempty contiguous blocks of the first r units.
    # None denotes an infeasible state, not a numerical approximation to -infinity.
    value = {(h, r): None for h in range(N_UNITS + 1)
             for r in range(N_UNITS + 1)}
    paths = {(h, r): () for h in range(N_UNITS + 1)
             for r in range(N_UNITS + 1)}
    predecessors = {}
    value[0, 0] = F(0)
    paths[0, 0] = ((),)
    candidates_checked = 0
    for h in range(1, N_UNITS + 1):
        for r in range(h, N_UNITS + 1):
            candidates = [(t, value[h - 1, t] + blocks[t + 1, r])
                          for t in range(h - 1, r)
                          if value[h - 1, t] is not None]
            candidates_checked += len(candidates)
            best = max(v for _, v in candidates)
            ts = tuple(t for t, v in candidates if v == best)
            value[h, r] = best
            predecessors[h, r] = ts
            paths[h, r] = tuple(sorted(p + (r,) for t in ts for p in paths[h - 1, t]))
    # Independent cut enumeration verifies every prefix state, not only n=4.
    for h in range(N_UNITS + 1):
        for r in range(N_UNITS + 1):
            options = [p for p in enumerate_endpoints(r) if len(p) == h]
            scored = [(p, sum((blocks[a + 1, b] for a, b in
                              zip((0,) + p[:-1], p)), F(0))) for p in options]
            if not scored:
                assert value[h, r] is None and paths[h, r] == ()
            else:
                best = max(v for _, v in scored)
                assert value[h, r] == best
                assert paths[h, r] == tuple(sorted(p for p, v in scored if v == best))
    table = [{'h': h, 'r': r,
              'maximum_saving': str(value[h, r]) if value[h, r] is not None else None,
              'optimal_predecessor_endpoints': list(predecessors.get((h, r), ())),
              'all_optimal_block_endpoints': [list(p) for p in paths[h, r]]}
             for h in range(N_UNITS + 1) for r in range(N_UNITS + 1)]
    return value, paths, table, candidates_checked


def build_results():
    assert sum((p for p, _ in STATES), F(0)) == 1 and sum(WEIGHTS, F(0)) == 1
    assert all(len({theta[i][k] for i in range(N_UNITS)}) == N_UNITS
               for _, theta in STATES for k in range(len(WEIGHTS)))
    criterion_errors = {pair: tuple(pair_error(*pair, k) for k in range(len(WEIGHTS)))
                        for pair in PAIRS}
    errors = {pair: sum((w * e for w, e in zip(WEIGHTS, es)), F(0))
              for pair, es in criterion_errors.items()}
    assert tuple(errors.values()) == (F(1, 4), F(1, 10), F(1, 10),
                                     F(2, 5), F(1, 10), F(1, 10))
    blocks = {(a, b): block_savings(errors, a, b)
              for a in range(1, N_UNITS + 1) for b in range(a, N_UNITS + 1)}
    rows = [inspect(p, errors, blocks) for p in enumerate_endpoints(N_UNITS)]
    rows.sort(key=lambda row: (row['G'], row['g']))
    assert len(rows) == 2 ** (N_UNITS - 1) == 8
    assert [sum(row['G'] == h for row in rows) for h in range(1, 5)] == [1, 3, 3, 1]
    values, paths, dp_table, transitions = dynamic_program(blocks)
    full_cost = sum(errors.values(), F(0))
    assert full_cost == F(21, 20) and full_cost / M == F(7, 40)
    summaries = []
    for cap in range(1, N_UNITS + 1):
        exact_risk = (full_cost - values[cap, N_UNITS]) / M
        cap_saving = max(values[h, N_UNITS] for h in range(1, cap + 1))
        cap_risk = (full_cost - cap_saving) / M
        exact_opts = sorted(list(endpoints_to_grade(p)) for p in paths[cap, N_UNITS])
        cap_opts = sorted(list(endpoints_to_grade(p)) for h in range(1, cap + 1)
                          if values[h, N_UNITS] == cap_saving for p in paths[h, N_UNITS])
        exact_rows = [row for row in rows if row['G'] == cap]
        cap_rows = [row for row in rows if row['G'] <= cap]
        assert exact_risk == min(F(row['risk']) for row in exact_rows)
        assert cap_risk == min(F(row['risk']) for row in cap_rows)
        assert exact_opts == sorted(row['g'] for row in exact_rows if F(row['risk']) == exact_risk)
        assert cap_opts == sorted(row['g'] for row in cap_rows if F(row['risk']) == cap_risk)
        summaries.append({'G_or_cap': cap, 'exact_minimum_risk': str(exact_risk),
                          'exact_all_minimizers': exact_opts,
                          'at_most_minimum_risk': str(cap_risk),
                          'at_most_all_minimizers': cap_opts})
    assert [s['exact_minimum_risk'] for s in summaries] == ['1/4', '7/40', '3/20', '7/40']
    assert [s['at_most_minimum_risk'] for s in summaries] == ['1/4', '7/40', '3/20', '3/20']
    assert summaries[2]['exact_all_minimizers'] == [[1, 2, 2, 3]]
    assert summaries[3]['at_most_all_minimizers'] == [[1, 2, 2, 3]]
    return {'schema_version': 1, 'fixture': 'one exact fixed-order DP example',
            'provenance': 'Author-constructed two-state joint law. Arithmetic frozen without reading the Step7.2 proof/public draft; recurrence notation W supplied by the author, independent enumeration and risk evaluation here.',
            'units_and_fixed_order': list(UNITS), 'n': N_UNITS, 'K': len(WEIGHTS),
            'M': M, 'weights': [str(w) for w in WEIGHTS], 'tau': str(TAU),
            'joint_belief': [{'probability': str(p), 'descending_criterion_orders': list(orders),
                              'theta_unit_by_criterion': [list(row) for row in theta]}
                             for (p, orders), (_, theta) in zip(ORDER_STATES, STATES)],
            'pair_costs': [{'above': UNITS[i], 'below': UNITS[j],
                            'criterion_errors': [str(e) for e in criterion_errors[i, j]],
                            'weighted_error': str(errors[i, j]),
                            'eta_error_minus_tau': str(errors[i, j] - TAU)} for i, j in PAIRS],
            'block_savings': [{'a': a, 'b': b, 'interval': list(UNITS[a - 1:b]),
                               'W': str(w), 'merge_risk_adjustment_unnormalized': str(-w)}
                              for (a, b), w in blocks.items()],
            'full_disclosure_cost': str(full_cost), 'full_disclosure_risk': str(full_cost / M),
            'T_rho': str(full_cost - M * TAU),
            'block_indexing': 'Code blocks[a,b] use one-based inclusive endpoints; code block(a,b)=mathematical W(a-1,b), where W(a,b)=sum_{a<i<j<=b}(e_ij-tau). Block table a,b are code endpoints.',
            'recurrence': 'Mathematical: F(h,r)=max_{h-1<=t<r}[F(h-1,t)+W(t,r)]; implementation uses blocks[t+1,r]. F(0,0)=0; infeasible states=-infinity (JSON null).',
            'risk_identity': 'R=tau+(T_rho-sum_blocks W)/M=R(singletons)-sum_blocks W/M.',
            'all_contiguous_partitions': rows, 'dp_states': dp_table,
            'exact_and_capped_optima': summaries,
            'checks': {'full_partition_count': len(rows), 'interval_count': len(blocks),
                       'prefix_state_count_including_infeasible': len(dp_table),
                       'finite_predecessor_transitions': transitions,
                       'joint_law_risk_equals_pair_cost_risk_equals_block_identity': True,
                       'all_prefix_dp_values_and_all_argmins_equal_enumeration': True,
                       'all_exact_and_capped_optima_equal_enumeration': True,
                       'all_checks_passed': True},
            'limits': ['Only the fixed order ABCD is optimized; no unrestricted optimizer claim.',
                       'No protected-criterion rows, minimax objective, minimum block sizes, or other side constraints.',
                       'No posterior fitting, Monte Carlo sampling, numerical solver, runtime benchmark, or production implementation.',
                       'Exact rational arithmetic validates this instance, not a general complexity proof.',
                       'All optimal paths are retained solely for this tiny check; their enumeration can grow exponentially.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    result = build_results()
    out = Path(__file__).with_name('fixed-order-dp-results.json')
    if args.check:
        assert json.loads(out.read_text()) == result, 'Saved exact results differ.'
    else:
        out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    print('PASS: 8 contiguous partitions, 10 intervals, 25 prefix states; exact and capped DP optima match enumeration. Cap4 selects A|BC|D at risk3/20; exact4 has risk7/40.')


if __name__ == '__main__':
    main()
