#!/usr/bin/env python3
# Author: JoonHo Lee (jlee296@ua.edu)
"""One exact worked instance for both co-primary targets; no model fitting.

Reuse the accepted four-unit joint law. Enumerate every canonical ordered
partition, evaluate statewise losses and pair-coefficient losses independently,
and save rational values. --check verifies, without rewriting, the saved fixture.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / 'examples/fixed-order-dp-results.json'
OUTPUT = ROOT / 'fixtures/exact-example.json'
LABELS = 'ABCD'
W = (F(3, 5), F(2, 5))
A = (F(3, 4), F(1, 4))
TAU = F(1, 5)


def build():
    old = json.loads(INPUT.read_text())
    states = [(F(x['probability']), x['theta_unit_by_criterion'])
              for x in old['joint_belief']]
    assert sum(p for p, _ in states) == 1
    assert old['n'] == 4 and old['K'] == 2
    assert tuple(map(F, old['weights'])) == W
    cstates = [(p, [sum(a*x for a, x in zip(A, row)) for row in t])
               for p, t in states]
    pair = {}
    for i in range(4):
        for j in range(4):
            if i == j:
                continue
            e = [sum((p*(t[i][k] <= t[j][k]) for p, t in states), F(0))
                 for k in range(2)]
            pair[i, j] = {'criterion_errors':e,
                          'directional':sum(w*x for w, x in zip(W, e)),
                          'composite':sum((p*(c[i] <= c[j]) for p, c in cstates), F(0))}
    assert all(pair[i, j]['directional'] + pair[j, i]['directional'] == 1
               and pair[i, j]['composite'] + pair[j, i]['composite'] == 1
               for i, j in pair)
    rows = []
    for g in product(range(1, 5), repeat=4):
        if set(g) != set(range(1, max(g)+1)):
            continue
        disclosed = [(i, j) for i, j in pair if g[i] < g[j]]
        n = len(disclosed)
        counts = {'directional':sum((pair[i, j]['directional'] for i,j in disclosed),F(0)),
                  'composite':sum((pair[i, j]['composite'] for i,j in disclosed),F(0))}
        direct = {
            'directional':sum((p*sum((w*sum(t[i][k] <= t[j][k] for i,j in disclosed)
                                      for k,w in enumerate(W)),F(0)) for p,t in states),F(0)),
            'composite':sum((p*sum(c[i] <= c[j] for i,j in disclosed) for p,c in cstates),F(0))}
        assert counts == direct
        criterion_counts = [sum((pair[i,j]['criterion_errors'][k] for i,j in disclosed),F(0))
                            for k in range(2)]
        state_counts = [{'criterion_wrong_counts':[
                            sum(t[i][k] <= t[j][k] for i,j in disclosed) for k in range(2)],
                         'composite_wrong_count':sum(c[i] <= c[j] for i,j in disclosed)}
                        for (_,t),(_,c) in zip(states,cstates)]
        rows.append({'g':list(g),'G':max(g),'N':n,'disclosure_fraction':str(F(n,6)),
                     'state_counts':state_counts,
                     'criterion_expected_wrong_counts':list(map(str,criterion_counts)),
                     **{target:{'A':str(count),'R':str((count+TAU*(6-n))/6),
                                'disclosed_error':str(count/n) if n else None}
                        for target,count in counts.items()}})
    assert len(rows) == 75 and len({tuple(r['g']) for r in rows}) == 75
    optima = {}
    for target in ['directional','composite']:
        best = min(F(r[target]['R']) for r in rows)
        optima[target] = {'R':str(best),'actions':[r['g'] for r in rows if F(r[target]['R'])==best]}
    selected = [[1,1,1,1],[1,2,3,4],[1,1,2,3],[1,2,2,3],[1,1,1,2]]
    forward = [{'pair':LABELS[i]+LABELS[j],
                'criterion_strict_superiority':list(map(str,[1-x for x in pair[i,j]['criterion_errors']])),
                'criterion_errors':list(map(str,pair[i,j]['criterion_errors'])),
                'directional_error':str(pair[i,j]['directional']),
                'composite_error':str(pair[i,j]['composite'])}
               for i in range(4) for j in range(i+1,4)]
    return {'schema_version':1,'design':'One exact synthetic conditional law, reused from Step7.2/8.3',
            'input':str(INPUT.relative_to(ROOT)),
            'input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),
            'n':4,'K':2,'M':6,'units':list(LABELS),'w':list(map(str,W)),
            'a':list(map(str,A)),'tau':str(TAU),
            'joint_belief':old['joint_belief'],
            'composite_by_state':[list(map(str,c)) for _,c in cstates],
            'pair_probabilities_and_errors':forward,'all_actions':rows,
            'selected_actions':[next(r for r in rows if r['g']==g) for g in selected],
            'optima':optima,'all_checks_passed':True,
            'checks':['75 distinct canonical ordered partitions',
                      'For all75actions, direct-state and pair-coefficient counts agree for both targets',
                      'Sixpair reverse errors complement toone for both targets in this tie-free instance',
                      'All optimal actions retained; no arbitrary optimizer tie-breaking'],
            'limits':['Exactly specified conditional law, not fitted/calibrated empirical posterior',
                      'Scalar coefficients a differ from criterion weights w by explicit design',
                      'Reportties withhold comparisons; no latent equalities in this fixture',
                      'Fraction undefined forN0; posterior expectations are not realized error rates',
                      'No package, optimization backend, Monte Carlo or parameter sweep']}


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    result=build()
    if args.check:
        assert result == json.loads(OUTPUT.read_text()),'Saved fixture mismatch'
    else:
        OUTPUT.parent.mkdir(exist_ok=True)
        OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['composite_by_state','pair_probabilities_and_errors',
                                          'selected_actions','optima','all_checks_passed']},indent=2))
