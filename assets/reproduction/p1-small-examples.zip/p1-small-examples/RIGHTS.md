# Rights status

Copyright © 2026 JoonHo Lee (jlee296@ua.edu).

This is an author-review candidate. A project-wide reuse license for these original scripts, fixtures and documentation has not yet been selected. Packaging is not a license grant. A published release should replace this notice with the author's agreed license terms. No third-party original article, textbook or empirical dataset is included.
